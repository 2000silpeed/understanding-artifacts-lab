# 강의 16 — B+ 트리: 리프 연결과 범위 탐색 (source package)

data_structures 트랙 16강. 한국어 내레이션 강의, 16:9, 추정 245.4초. 흐름은 **핵심 개념 요약 → 구체적인 사용 상황 → 본 강의**다.

상태: **source only**. 녹음·음악·렌더·업로드는 하지 않았다. 기술 검사 통과는 미감 승인이 아니다.

## 파일

| 경로 | 역할 |
|---|---|
| `code/python/bplustree.py` | B+ 트리(삽입·분할, 점 탐색, `range_search`, 비교용 `range_search_without_links`). 표준 라이브러리만 사용 |
| `code/python/demo.py` | `fixtures/input.txt` 실행 → 표준 출력 + `runs/lesson-data.json`(영상·대본이 읽는 유일한 수치 원천) |
| `code/cpp/bplustree.cpp` | 같은 알고리즘의 C++17 판. 출력이 Python과 줄 단위로 같다 |
| `fixtures/input.txt` · `fixtures/expected.json` | 입력(가격 14개, 범위 [20, 40], 10만 개 규모 실험)과 기대값(손 계산 · 전수 비교 · 회귀 고정) |
| `run_examples.py` → `runs/` | 실행 기록: `python-stdout.txt`, `cpp-stdout.txt`, `lesson-data.json`, `run-log.json`(명령·exit·컴파일러·sha256) |
| `voice/script.json` | 내레이션 원본. 장면마다 `say`(자막 표기)와 `tts`(녹음용 한글 읽기), `{큐}` 위치, 승인할 읽기 목록 |
| `plan.py` → `shots.json`, `voice/tts-lines.json` | 대본 → 장면 길이·큐 시각(녹음 전 추정) → 샷 계획. `shotlist.md`는 shotlint가 만든다 |
| `film.js` | 연출 파일(장면 12개). `shots.json`, `runs/lesson-data.json`, `voice/script.json`만 읽는다 |
| `scenario.md` | 비트 시트와 연출 규칙 |
| `practice/` | 실습: `exercise_range_count.py`(빈칸), `check_practice.py`(채점기), `solution_range_count.py`, `README.md` |
| `tests/test_lesson.py` | source tests 19개: 알고리즘, 기대값, 실행 기록 최신 여부, C++17 = Python, 화면 코드 = 소스, 대본 수치 = 실행 결과, 계획 최신·shotlint, 실습 채점기, film smoke·번들 |
| `tests/film_smoke.mjs` · `tests/bundle_check.cjs` | 브라우저 없이 film.js 전 장면 호출(예외·넘침·GPU 구조·대본 표시·안전 영역 근사) / 실제 build 설정으로 메모리 번들(파일 기록 없음) |
| `source-manifest.json` · `qa/author-result.json` | 파일별 sha256·역할 / 작성 결과·명령·exit·다음 단계 |

## 검증 명령 (프로젝트 루트에서)

```sh
python3 films/b-plus-tree-20261109/run_examples.py          # Python·C++17 실행, runs/ 갱신, 출력 비교
python3 films/b-plus-tree-20261109/plan.py                  # shots.json · voice/tts-lines.json
python3 pipeline/shotlint.py b-plus-tree-20261109           # 계획 검사, shotlist.md
python3 films/b-plus-tree-20261109/tests/test_lesson.py     # source tests (c++, node 필요)
python3 films/b-plus-tree-20261109/practice/check_practice.py films/b-plus-tree-20261109/practice/solution_range_count.py
python3 films/b-plus-tree-20261109/manifest.py              # source-manifest.json + qa/author-result.json
```

## 다음 단계 (부모 검수 후, 순서대로)

1. **source 검수**: 대본·예제·`voice/script.json`의 `readingsToApprove`(B+ 트리, L2~L5, C++17, lo/hi, next, range_count, 2,049 읽기)를 확인한다.
2. **녹음(유료, 승인 필요)**: 목소리를 고르고 `voice/tts-lines.json`의 장면별 `text`를 `voice/v1/seg-NN-<scene>.mp3`로 녹음한다(12파일, 1,803자). 사람이 듣고 확인한다.
3. **단어 시각**: Scribe로 큐 단어의 시각을 재서 `voice/timings.json`(`{"<scene>": {"len": …, "cues": {…}}}`)에 넣는다. 그다음 `python3 films/b-plus-tree-20261109/plan.py` → `python3 pipeline/shotlint.py b-plus-tree-20261109` → `tests/test_lesson.py`를 실행한다.
4. **스틸 게이트(사람 확인)**: `node pipeline/build.cjs b-plus-tree-20261109 && node pipeline/render.cjs b-plus-tree-20261109 --format 16x9 --stills`, 그다음 `contact.py`로 접촉 시트를 만든다.
5. **제작**: `sh pipeline/make.sh b-plus-tree-20261109 16x9`(16:9만). 오디오 단계는 2번의 녹음 파일이 있어야 한다. 이어서 `verify.py` PASS, `shotlint.py --video 16x9`, `REVIEW.md` 기록.
6. 음악은 넣지 않았다. 배경음이 필요하면 별도 승인을 받아 만든다(장면 길이는 100 BPM 격자에 맞춰 두었다).

## 알려진 한계

- 큐 시각과 영상 길이는 음절 수로 추정했다(`timing: estimated`). 실제 녹음 뒤 다시 맞춰야 한다.
- `film_smoke.mjs`의 글자 폭은 근사치다. 안전 영역·겹침의 최종 판단은 실제 렌더와 `verify.py`가 한다.
- 실제 렌더, 청취, 스틸 확인은 하지 않았다. 9:16 배치는 작성하지 않았다.
