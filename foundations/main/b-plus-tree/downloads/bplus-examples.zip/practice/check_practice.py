"""실습 채점기 — range_count(tree, lo, hi) -> (개수, 읽은 리프 수).

usage: python3 practice/check_practice.py practice/exercise_range_count.py
       python3 practice/check_practice.py practice/solution_range_count.py
검사: 강의 예제(가격 14개, [20, 40] → 7개, 리프 4개) + 시드 고정 무작위 트리 120개(max_keys 3~8, 범위 끝이 키
사이·키 위·전체 밖인 경우 포함). 개수는 정렬 후 걸러 센 값과, 읽은 리프 수는 리프 링크로 걸었을 때의 수와 같아야 한다.
리프를 처음부터 모두 훑으면 읽은 리프 수가 달라 실패한다.
"""
import importlib.util
import random
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'code' / 'python'))
from bplustree import build  # noqa: E402


def load(path):
    spec = importlib.util.spec_from_file_location('student', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.range_count


def expected(tree, lo, hi):
    _, _, walked = tree.range_search(lo, hi)
    keys = [k for leaf in tree.leaf_chain() for k in leaf.keys]
    return sum(lo <= k <= hi for k in keys), len(walked)


def cases():
    lesson = build([12, 31, 8, 45, 19, 27, 52, 15, 36, 21, 41, 24, 33, 30], 3)
    yield 'lesson [20, 40]', lesson, 20, 40
    yield 'lesson [22, 22] (빈 범위)', lesson, 22, 22
    yield 'lesson [0, 100] (전체)', lesson, 0, 100
    rnd = random.Random(16)
    for i in range(120):
        n = rnd.randint(1, 300)
        keys = rnd.sample(range(1000), n)
        t = build(keys, rnd.randint(3, 8))
        lo = rnd.choice([rnd.randint(-50, 1050), rnd.choice(keys)])
        hi = rnd.choice([lo + rnd.randint(0, 400), rnd.choice(keys), lo - 1])
        yield f'random #{i} n={n} [{lo}, {hi}]', t, lo, hi


def main():
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    fn = load(sys.argv[1])
    failed = 0
    total = 0
    for name, tree, lo, hi in cases():
        total += 1
        want = expected(tree, lo, hi)
        try:
            got = tuple(fn(tree, lo, hi))
        except Exception as e:  # noqa: BLE001 — report any student error as a failed case
            got = f'{type(e).__name__}: {e}'
        if got != want:
            failed += 1
            if failed <= 5:
                print(f'FAIL {name}: got {got}, want {want}')
    print(f'{"PASS" if not failed else "FAIL"} {total - failed}/{total}')
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
