"""실습 정답 예시 — range_count (강의 16). 먼저 exercise_range_count.py를 직접 풀어 본 뒤에 연다."""
from bisect import bisect_right


def range_count(tree, lo, hi):
    node = tree.root
    while not node.leaf:                       # 1) 한 번만 내려간다
        node = node.children[bisect_right(node.keys, lo)]
    count = leaves = 0
    while node is not None:                    # 2) 리프 링크를 따라 걷는다
        leaves += 1
        for k in node.keys:
            if k > hi:                         # 3) hi를 넘으면 멈춘다
                return count, leaves
            if k >= lo:
                count += 1
        node = node.next
    return count, leaves
