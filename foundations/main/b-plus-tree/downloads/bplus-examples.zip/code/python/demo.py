"""강의 16 예제 실행: fixtures/input.txt → 표준 출력(C++ 판과 같은 줄) + 영상용 데이터 JSON.

usage:
  python3 code/python/demo.py fixtures/input.txt                       # 표준 출력만
  python3 code/python/demo.py fixtures/input.txt --json runs/lesson-data.json
영상(film.js)과 대본 수치는 --json 결과만 읽는다. 손으로 옮겨 적지 않는다.
"""
import json
import sys
from pathlib import Path

from bplustree import build

HERE = Path(__file__).resolve().parent


def read_input(path):
    spec = {}
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        line = line.split('#', 1)[0].strip()
        if not line:
            continue
        name, *vals = line.split()
        spec[name] = [int(v) for v in vals]
    return spec


def excerpt(name):
    """bplustree.py에서 [excerpt:name] … [/excerpt] 사이 줄을 그대로 꺼낸다(영상의 코드 화면용)."""
    lines = (HERE / 'bplustree.py').read_text(encoding='utf-8').splitlines()
    a = lines.index(f'    # [excerpt:{name}]') + 1
    b = lines.index('    # [/excerpt]', a)
    body = lines[a:b]
    return [l[4:] if l.startswith('    ') else l for l in body], a + 1  # 1-based first line


def run(spec):
    mk = spec['max_keys'][0]
    keys = spec['keys']
    t = build(keys, mk)
    out, data = [], {}
    levels = t.levels()
    out.append(f'tree max_keys={mk} n={len(keys)} height={t.height()}')
    for d, lv in enumerate(levels):
        out.append(f'level {d}: ' + ' '.join(f"{n.name}[{','.join(map(str, n.keys))}]" for n in lv))
    chain = [n.name for n in t.leaf_chain()]
    out.append('chain ' + ' '.join(chain))
    sk = spec['search'][0]
    found, path = t.search(sk)
    out.append(f'search {sk}: found={int(found)} path={" ".join(path)}')
    lo, hi = spec['range']
    res, descent, walked = t.range_search(lo, hi)
    route = descent + walked
    nres, nroute = t.range_search_without_links(lo, hi)
    assert nres == res
    out.append(f'range {lo} {hi}: found={" ".join(map(str, res))}')
    out.append('range.descent ' + ' '.join(descent))
    out.append('range.walked ' + ' '.join(walked))
    out.append(f'range.moves {len(route) - 1}')
    out.append('nolink.route ' + ' '.join(nroute))
    out.append(f'nolink.moves {len(nroute) - 1}')

    n, step, smk, slo, shi = spec['scale']
    big = build([(i * step) % n for i in range(n)], smk)
    bres, bdesc, bwalk = big.range_search(slo, shi)
    bnres, bnroute = big.range_search_without_links(slo, shi)
    assert bnres == bres == list(range(slo, shi + 1))
    nleaves = len(big.leaf_chain())
    out.append(f'scale n={n} max_keys={smk} height={big.height()} leaves={nleaves}')
    out.append(f'scale range {slo} {shi}: found={len(bres)} leaves_read={len(bwalk)} moves_links={len(bdesc) + len(bwalk) - 1} moves_nolinks={len(bnroute) - 1} fullscan_leaves={nleaves}')

    code, first_line = excerpt('range_search')
    data = {
        'source': 'code/python/demo.py fixtures/input.txt --json runs/lesson-data.json',
        'maxKeys': mk, 'insertOrder': keys, 'sortedKeys': sorted(keys), 'height': t.height(),
        'levels': [[{'name': nd.name, 'keys': nd.keys, 'leaf': nd.leaf,
                     'children': [c.name for c in nd.children] if not nd.leaf else [],
                     'next': nd.next.name if nd.leaf and nd.next else None} for nd in lv] for lv in levels],
        'chain': chain,
        'search': {'key': sk, 'found': found, 'path': path},
        'range': {'lo': lo, 'hi': hi, 'found': res, 'descent': descent, 'walked': walked, 'route': route,
                  'moves': len(route) - 1, 'stopKey': next(k for nd in t.leaf_chain() for k in nd.keys if k > hi)},
        'noLinks': {'route': nroute, 'moves': len(nroute) - 1},
        'scale': {'n': n, 'step': step, 'maxKeys': smk, 'height': big.height(), 'leaves': nleaves, 'lo': slo, 'hi': shi,
                  'found': len(bres), 'descent': len(bdesc), 'leavesRead': len(bwalk), 'movesLinks': len(bdesc) + len(bwalk) - 1,
                  'movesNoLinks': len(bnroute) - 1, 'fullScanLeaves': nleaves},
        'code': {'file': 'code/python/bplustree.py', 'firstLine': first_line, 'lines': code},
        'stdout': out,
    }
    return out, data


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    out, data = run(read_input(sys.argv[1]))
    print('\n'.join(out))
    if '--json' in sys.argv:
        dst = Path(sys.argv[sys.argv.index('--json') + 1])
        dst.write_text(json.dumps(data, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
