"""Runs the Python and C++17 examples for real and keeps what they printed.

  python3 films/learning-rate-20261103/examples/run_examples.py        # exit 0 when every check holds

For each fixture (input.txt = the film, practice.txt = lesson.md exercises, random-input.txt = seeded, make_random.py):
  python3 learning_rate.py <fixture>          → results/py-<name>.txt
  <c++ -std=c++17 build> <fixture>            → results/cpp-<name>.txt   (must equal the Python bytes)
and three independent checks of the Python run:
  gradMatchesNumeric   grad = p - target equals a central finite difference of loss(z) at every visited z (< 1e-6; h = 1e-6, so rounding in ln(1 - p) at large z sets the floor)
  lossFromSentences    loss(z) equals the mean cross-entropy computed sentence by sentence (< 1e-12)
  stepsFollowRule      z(k+1) = z(k) - lr * grad(k) for every printed row (re-read from the printed text, 4 decimals)
Then python3 learning_rate.py input.txt --json → ../trace.json (the only number source of the film), the terminal lines
of the film's code scene copied from results/py-input.txt → ../screen-excerpt.json, and results/run-receipt.json
(commands, exit codes, compiler, sha256 of every output). The C++ binary is built in a temporary directory outside the
repository and removed afterwards.
"""
import hashlib
import json
import math
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILM = HERE.parent
RES = HERE / 'results'
FIXTURES = ['input.txt', 'practice.txt', 'random-input.txt']
CXX = os.environ.get('CXX') or shutil.which('c++') or shutil.which('g++') or shutil.which('clang++')
FLAGS = ['-std=c++17', '-O2', '-Wall', '-Wextra', '-pedantic', '-Werror', '-ffp-contract=off']
ROW = re.compile(r'^  step +(\d+)  z ([+-]\d+\.\d{4})  p (\d\.\d{4})  loss (\d+\.\d{4})  grad ([+-]\d\.\d{4})  move ([+-]\d+\.\d{4})$')

sys.path.insert(0, str(HERE))
sys.dont_write_bytecode = True
import learning_rate as lr  # noqa: E402


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def run(cmd, out=None):
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=HERE)
    if out is not None:
        out.write_text(r.stdout)
    return {'cmd': ' '.join(str(c) for c in cmd), 'exit': r.returncode, 'stderr': r.stderr.strip()[-400:]}


def independent(fixture, text):
    """The three checks above, on one fixture and its printed Python output."""
    cfg = lr.read_input(HERE / fixture)
    s = lr.solve(cfg)
    q, h = s['target'], 1e-6
    worst_grad, worst_loss = 0.0, 0.0
    for r in s['runs']:
        for row in r['rows']:
            z = row['z']
            num = (lr.loss(z + h, q) - lr.loss(z - h, q)) / (2 * h)
            worst_grad = max(worst_grad, abs(num - row['grad']))
            p = lr.prob(z)
            direct = sum(-math.log(p if b == cfg['word'] else 1 - p) for _, b in cfg['sentences']) / len(cfg['sentences'])
            worst_loss = max(worst_loss, abs(direct - row['loss']))
    # the printed rows follow z <- z - lr * grad (4-decimal print: allow 2e-4)
    blocks = re.split(r'^run lr ', text, flags=re.M)[1:]
    follow = len(blocks) == len(cfg['runs'])
    for blk, rate in zip(blocks, cfg['runs']):
        rows = [ROW.match(x) for x in blk.splitlines() if x.startswith('  step')]
        follow &= len(rows) == cfg['steps'] + 1 and all(rows)
        for a, b in zip(rows, rows[1:]):
            follow &= abs(float(b[2]) - (float(a[2]) - rate * float(a[5]))) <= 2e-4 + abs(rate) * 1e-4
    return {'gradMatchesNumeric': worst_grad < 1e-6, 'lossFromSentences': worst_loss < 1e-12, 'stepsFollowRule': bool(follow)}, \
           {'maxGradDiff': worst_grad, 'maxLossDiff': worst_loss}


def main():
    RES.mkdir(exist_ok=True)
    steps, checks, numbers = [], {}, {}
    tmp = Path(tempfile.mkdtemp(prefix='learning-rate-build-'))
    try:
        binary = tmp / 'learning_rate'
        comp = run([CXX, *FLAGS, '-o', str(binary), 'learning_rate.cpp'])
        comp['cmd'] = comp['cmd'].replace(str(binary), '<tmp>/learning_rate')
        steps.append(comp)
        for fx in FIXTURES:
            name = fx.rsplit('.', 1)[0]
            py, cpp = RES / f'py-{name}.txt', RES / f'cpp-{name}.txt'
            steps.append(run([sys.executable, 'learning_rate.py', fx], py))
            if comp['exit'] == 0:
                s = run([str(binary), fx], cpp)
                s['cmd'] = s['cmd'].replace(str(binary), '<tmp>/learning_rate')
                steps.append(s)
            ind, nums = independent(fx, py.read_text())
            checks[fx] = {'pythonEqualsCpp': comp['exit'] == 0 and cpp.exists() and py.read_bytes() == cpp.read_bytes(), **ind}
            numbers[fx] = nums
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    steps.append(run([sys.executable, 'learning_rate.py', 'input.txt', '--json'], FILM / 'trace.json'))
    # the terminal panel of the film's code scene: lines copied from the real Python run, never retyped
    out_lines = (RES / 'py-input.txt').read_text().splitlines()
    excerpt = {'source': 'examples/results/py-input.txt (= cpp-input.txt)', 'command': 'python3 learning_rate.py input.txt',
               'head': out_lines[:6],
               'results': [ln for ln in out_lines if ln.startswith('  result ')],
               'sweep': [ln for ln in out_lines if ln.startswith('  lr ') or ln.startswith('  within ')]}
    (FILM / 'screen-excerpt.json').write_text(json.dumps(excerpt, ensure_ascii=False, indent=1) + '\n')
    cxx_version = subprocess.run([CXX, '--version'], capture_output=True, text=True).stdout.splitlines()[:1]
    ok = all(s['exit'] == 0 for s in steps) and all(all(c.values()) for c in checks.values())
    outputs = sorted(RES.glob('*.txt')) + [FILM / 'trace.json', FILM / 'screen-excerpt.json']
    receipt = {
        'ok': ok,
        'host': {'system': platform.system(), 'machine': platform.machine(), 'python': platform.python_version(), 'cxx': cxx_version},
        'cwd': 'films/learning-rate-20261103/examples',
        'flags': ' '.join(FLAGS),
        'steps': steps,
        'checks': checks,
        'numbers': numbers,
        'inputs': {fx: sha(HERE / fx) for fx in FIXTURES},
        'outputs': {str(p.relative_to(FILM)): sha(p) for p in outputs},
    }
    (RES / 'run-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=1) + '\n')
    print(json.dumps({'ok': ok, 'checks': checks, 'exits': [s['exit'] for s in steps]}, ensure_ascii=False))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
