"""Writes random-input.txt: a seeded, larger input that checks Python = C++17 on many learning rates and steps.

  python3 films/learning-rate-20261103/examples/make_random.py      # rewrites random-input.txt (same bytes every time)

Seed 20261103: 37 sentences (23 of one next word), a non-zero start, 30 steps, 12 run learning rates and 16 sweep rates
drawn from 0.05–20 with two decimals. test_source.py checks the file equals text().
"""
import random
from pathlib import Path

HERE = Path(__file__).resolve().parent


def text(seed=20261103):
    rng = random.Random(seed)
    n, k = 37, 23
    nexts = ['우산'] * k + ['모자'] * (n - k)
    rng.shuffle(nexts)
    lrs = lambda m: ' '.join(f'{rng.uniform(0.05, 20):.2f}' for _ in range(m))
    out = ['# make_random.py (seed 20261103) — Python = C++17 대조용 입력. 영상에는 쓰지 않는다.',
           'word 우산', f'start {rng.uniform(-1, 1):.3f}', 'steps 30', f'runs {lrs(12)}', f'sweep {lrs(16)}']
    out += [f'sentence 비가오면 {w}' for w in nexts]
    return '\n'.join(out) + '\n'


if __name__ == '__main__':
    (HERE / 'random-input.txt').write_text(text())
