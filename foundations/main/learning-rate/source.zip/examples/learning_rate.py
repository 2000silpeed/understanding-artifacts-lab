"""학습률 예제: 같은 기울기에 서로 다른 학습률을 곱해 한 걸음씩 움직여 본다.

가장 작은 다음 단어 모델: 앞말(예: "점심은") 다음에 올 후보가 둘(예: 김밥, 라면)이고, 배우는 값은 김밥의 점수 z 하나다.
라면의 점수는 0으로 고정한다. 그러면 p = P(김밥) = 1 / (1 + e^-z) 이고, 데이터에서 김밥이 나온 비율을 target이라 할 때

  loss(z) = -(target * ln p + (1 - target) * ln(1 - p))      (데이터 문장 전체의 평균 교차 엔트로피)
  grad(z) = p - target                                       (loss를 z로 미분한 값)
  z <- z - lr * grad                                         (경사 하강 한 걸음; lr = 학습률)

같은 시작점에서 학습률만 바꿔 steps 걸음을 가 보고(runs), 여러 학습률의 마지막 손실을 비교한다(sweep: 바닥 손실 + REACH
이하로 내려온 학습률을 고른다).

  python3 learning_rate.py input.txt            # 사람이 읽는 실행 기록 (C++17 예제와 바이트 하나까지 같다)
  python3 learning_rate.py input.txt --json     # 영상이 읽는 trace (같은 계산, 숫자 + 화면용 문자열)

입력 형식은 input.txt의 주석을 본다.
"""
import json
import math
import sys

REACH = 0.001   # sweep: '바닥 손실에 닿았다' = 마지막 손실이 best loss + 0.001 이하


def read_input(path):
    """word / start / steps / runs / sweep / sentence 줄을 읽는다. '#' 뒤는 주석."""
    cfg = {'word': None, 'start': 0.0, 'steps': 10, 'runs': [], 'sweep': [], 'sentences': []}
    with open(path, encoding='utf-8') as f:
        for raw in f:
            line = raw.split('#', 1)[0].split()
            if not line:
                continue
            key, rest = line[0], line[1:]
            if key == 'word':
                cfg['word'] = rest[0]
            elif key == 'start':
                cfg['start'] = float(rest[0])
            elif key == 'steps':
                cfg['steps'] = int(rest[0])
            elif key == 'runs':
                cfg['runs'] = [float(x) for x in rest]
            elif key == 'sweep':
                cfg['sweep'] = [float(x) for x in rest]
            elif key == 'sentence':
                cfg['sentences'].append((rest[0], rest[1]))
            else:
                raise ValueError(f'unknown line: {raw.strip()}')
    return cfg


def stats(cfg):
    """(n, k, other, target): 문장 수, word가 다음 말인 문장 수, 다른 후보, 목표 확률 k / n."""
    nexts = [b for _, b in cfg['sentences']]
    words = sorted(set(nexts))
    if cfg['word'] not in words or len(words) != 2:
        raise ValueError('need exactly two next words, one of them = word')
    other = words[0] if words[1] == cfg['word'] else words[1]
    n, k = len(nexts), nexts.count(cfg['word'])
    return n, k, other, k / n


def prob(z):
    return 1.0 / (1.0 + math.exp(-z))


def loss(z, target):
    p = prob(z)
    return -(target * math.log(p) + (1.0 - target) * math.log(1.0 - p))


def grad(z, target):
    return prob(z) - target


def run(target, start, lr, steps):
    """steps 걸음의 기록: 걸음마다 z, p, loss, grad, 다음 이동량 move = -lr * grad."""
    rows, z = [], start
    for k in range(steps + 1):
        g = grad(z, target)
        rows.append({'step': k, 'z': z, 'p': prob(z), 'loss': loss(z, target), 'grad': g, 'move': -lr * g})
        z = z - lr * g
    return rows


def summary(rows, best_z):
    """바닥(best_z)을 넘었는지, 손실이 오른 걸음 수, 마지막 손실."""
    side = [r['z'] - best_z for r in rows]
    crossed = any(a * b < 0 for a, b in zip(side, side[1:]))
    ups = sum(1 for a, b in zip(rows, rows[1:]) if b['loss'] > a['loss'])
    return {'overshoot': crossed, 'lossUpSteps': ups, 'final': rows[-1]['loss']}


def solve(cfg):
    n, k, other, target = stats(cfg)
    best_z = math.log(target / (1.0 - target))
    curv = prob(best_z) * (1.0 - prob(best_z))
    runs = []
    for lr in cfg['runs']:
        rows = run(target, cfg['start'], lr, cfg['steps'])
        runs.append({'lr': lr, 'rows': rows, **summary(rows, best_z)})
    sweep = [{'lr': lr, 'final': run(target, cfg['start'], lr, cfg['steps'])[-1]['loss']} for lr in cfg['sweep']]
    reached = [sw['lr'] for sw in sweep if sw['final'] <= loss(best_z, target) + REACH]
    return {'n': n, 'k': k, 'other': other, 'target': target, 'bestZ': best_z, 'bestLoss': loss(best_z, target),
            'curv': curv, 'overshootLr': 1.0 / curv, 'unstableLr': 2.0 / curv, 'runs': runs, 'sweep': sweep, 'reached': reached}


def g(x):
    """학습률 표기 (C++ printf %g와 같다)."""
    return f'{x:g}'


def report(cfg):
    """사람이 읽는 실행 기록 줄들 (learning_rate.cpp가 같은 바이트를 낸다)."""
    s, w = solve(cfg), cfg['word']
    st = cfg['start']
    out = [f"data: {s['n']} sentences, {w} {s['k']}, {s['other']} {s['n'] - s['k']}",
           f"target p({w}) = {s['k']}/{s['n']} = {s['target']:.4f}",
           f"best z = {s['bestZ']:.4f}, best loss = {s['bestLoss']:.4f}",
           f"start z = {st:.4f}, p = {prob(st):.4f}, loss = {loss(st, s['target']):.4f}, grad = {grad(st, s['target']):+.4f}",
           f"curvature at best = {s['curv']:.4f}",
           f"near best: lr > {s['overshootLr']:.4f} overshoots, lr > {s['unstableLr']:.4f} does not settle"]
    for r in s['runs']:
        out.append(f"run lr {g(r['lr'])}")
        for row in r['rows']:
            out.append(f"  step {row['step']:2d}  z {row['z']:+.4f}  p {row['p']:.4f}  loss {row['loss']:.4f}  grad {row['grad']:+.4f}  move {row['move']:+.4f}")
        out.append(f"  result lr {g(r['lr'])}: overshoot {'yes' if r['overshoot'] else 'no'}, loss up {r['lossUpSteps']} steps, final loss {r['final']:.4f}")
    if s['sweep']:
        out.append(f"sweep after {cfg['steps']} steps")
        for sw in s['sweep']:
            out.append(f"  lr {g(sw['lr']):>5s}  final loss {sw['final']:.4f}")
        out.append(f"  within {REACH:g} of best loss: lr {', '.join(g(x) for x in s['reached']) or 'none'}")
    return out


def trace(cfg, z_lo=-0.4, z_hi=3.4, z_step=0.05):
    """영상이 읽는 값: 실행 결과 숫자와, 화면·자막이 그대로 쓰는 반올림 문자열(f2 / f3)."""
    s = solve(cfg)
    f2, f3 = (lambda x: f'{x:.2f}'), (lambda x: f'{x:.3f}')
    n_pts = int(round((z_hi - z_lo) / z_step))
    curve = [[round(z_lo + i * z_step, 4), loss(z_lo + i * z_step, s['target'])] for i in range(n_pts + 1)]
    st = cfg['start']
    return {
     'source': 'examples/learning_rate.py input.txt --json',
     'word': cfg['word'], 'other': s['other'], 'context': cfg['sentences'][0][0],
     'sentences': [list(x) for x in cfg['sentences']],
     'n': s['n'], 'k': s['k'], 'target': s['target'], 'steps': cfg['steps'],
     'bestZ': s['bestZ'], 'bestLoss': s['bestLoss'], 'curv': s['curv'], 'overshootLr': s['overshootLr'], 'unstableLr': s['unstableLr'],
     'start': {'z': st, 'p': prob(st), 'loss': loss(st, s['target']), 'grad': grad(st, s['target'])},
     'runs': [{'lr': r['lr'], 'overshoot': r['overshoot'], 'lossUpSteps': r['lossUpSteps'], 'final': r['final'],
               'rows': [{k: row[k] for k in ('step', 'z', 'p', 'loss', 'grad', 'move')} for row in r['rows']]} for r in s['runs']],
     'sweep': s['sweep'], 'reach': REACH, 'reached': s['reached'],
     'curve': curve, 'curveRange': [z_lo, z_hi],
     'fmt': {
      'target': f2(s['target']), 'bestZ': f2(s['bestZ']), 'bestLoss': f3(s['bestLoss']), 'curv': f2(s['curv']), 'curv4': f'{s["curv"]:.4f}',
      'overshootLr': f2(s['overshootLr']), 'unstableLr': f2(s['unstableLr']),
      'start': {'z': f2(st), 'p': f2(prob(st)), 'loss': f3(loss(st, s['target'])), 'grad': f2(grad(st, s['target']))},
      'runs': [{'lr': g(r['lr']), 'final': f3(r['final']),
                'z': [f2(row['z']) for row in r['rows']], 'p': [f2(row['p']) for row in r['rows']],
                'loss': [f3(row['loss']) for row in r['rows']], 'move': [f'{row["move"]:+.3f}' for row in r['rows']]} for r in s['runs']],
      'sweep': [{'lr': g(sw['lr']), 'final': f3(sw['final'])} for sw in s['sweep']],
      'reached': [g(x) for x in s['reached']],
     },
    }


def main(argv):
    if len(argv) < 2:
        print('usage: python3 learning_rate.py input.txt [--json]', file=sys.stderr)
        return 2
    cfg = read_input(argv[1])
    if '--json' in argv:
        json.dump(trace(cfg), sys.stdout, ensure_ascii=False, indent=1)
        sys.stdout.write('\n')
    else:
        sys.stdout.write('\n'.join(report(cfg)) + '\n')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
