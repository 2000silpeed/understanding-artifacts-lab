// 학습률 예제 (C++17): learning_rate.py와 같은 계산, 같은 출력 바이트.
//
// 가장 작은 다음 단어 모델: 앞말 다음 후보 둘(word, other), 배우는 값은 word의 점수 z 하나(other 점수는 0 고정).
//   p = 1 / (1 + e^-z),  loss = -(target ln p + (1 - target) ln(1 - p)),  grad = p - target,  z <- z - lr * grad
//
//   c++ -std=c++17 -O2 -Wall -Wextra -pedantic -Werror -ffp-contract=off -o learning_rate learning_rate.cpp
//   ./learning_rate input.txt
//
// -ffp-contract=off: z - lr * grad를 FMA 한 번으로 합치지 않게 해서 Python과 반올림이 같게 한다.
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

namespace {

const double REACH = 0.001;  // sweep: 마지막 손실이 best loss + 0.001 이하면 '바닥에 닿았다'

struct Config {
    std::string word;
    double start = 0.0;
    int steps = 10;
    std::vector<double> runs, sweep;
    std::vector<std::pair<std::string, std::string>> sentences;
};

struct Row {
    int step;
    double z, p, loss, grad, move;
};

bool readInput(const char* path, Config& cfg) {
    std::ifstream in(path);
    if (!in) return false;
    std::string raw;
    while (std::getline(in, raw)) {
        std::string line = raw.substr(0, raw.find('#'));
        std::istringstream ss(line);
        std::string key;
        if (!(ss >> key)) continue;
        if (key == "word") {
            ss >> cfg.word;
        } else if (key == "start") {
            std::string v; ss >> v; cfg.start = std::stod(v);
        } else if (key == "steps") {
            ss >> cfg.steps;
        } else if (key == "runs" || key == "sweep") {
            std::vector<double>& dst = key == "runs" ? cfg.runs : cfg.sweep;
            std::string v;
            while (ss >> v) dst.push_back(std::stod(v));
        } else if (key == "sentence") {
            std::string a, b; ss >> a >> b;
            cfg.sentences.emplace_back(a, b);
        } else {
            std::cerr << "unknown line: " << raw << "\n";
            return false;
        }
    }
    return true;
}

double prob(double z) { return 1.0 / (1.0 + std::exp(-z)); }

double lossAt(double z, double target) {
    double p = prob(z);
    return -(target * std::log(p) + (1.0 - target) * std::log(1.0 - p));
}

double gradAt(double z, double target) { return prob(z) - target; }

std::vector<Row> run(double target, double start, double lr, int steps) {
    std::vector<Row> rows;
    double z = start;
    for (int k = 0; k <= steps; ++k) {
        double g = gradAt(z, target);
        rows.push_back({k, z, prob(z), lossAt(z, target), g, -lr * g});
        z = z - lr * g;
    }
    return rows;
}

std::string fmtG(double x) {
    char buf[64];
    std::snprintf(buf, sizeof buf, "%g", x);
    return buf;
}

}  // namespace

int main(int argc, char** argv) {
    if (argc < 2) {
        std::fprintf(stderr, "usage: ./learning_rate input.txt\n");
        return 2;
    }
    Config cfg;
    if (!readInput(argv[1], cfg)) return 1;

    std::set<std::string> words;
    int n = 0, k = 0;
    for (const auto& s : cfg.sentences) {
        words.insert(s.second);
        ++n;
        if (s.second == cfg.word) ++k;
    }
    if (words.size() != 2 || !words.count(cfg.word)) {
        std::fprintf(stderr, "need exactly two next words, one of them = word\n");
        return 1;
    }
    std::string other = *words.begin() == cfg.word ? *words.rbegin() : *words.begin();
    double target = static_cast<double>(k) / n;
    double bestZ = std::log(target / (1.0 - target));
    double bestLoss = lossAt(bestZ, target);
    double curv = prob(bestZ) * (1.0 - prob(bestZ));
    const char* w = cfg.word.c_str();
    double st = cfg.start;

    std::printf("data: %d sentences, %s %d, %s %d\n", n, w, k, other.c_str(), n - k);
    std::printf("target p(%s) = %d/%d = %.4f\n", w, k, n, target);
    std::printf("best z = %.4f, best loss = %.4f\n", bestZ, bestLoss);
    std::printf("start z = %.4f, p = %.4f, loss = %.4f, grad = %+.4f\n", st, prob(st), lossAt(st, target), gradAt(st, target));
    std::printf("curvature at best = %.4f\n", curv);
    std::printf("near best: lr > %.4f overshoots, lr > %.4f does not settle\n", 1.0 / curv, 2.0 / curv);

    for (double lr : cfg.runs) {
        std::vector<Row> rows = run(target, st, lr, cfg.steps);
        std::string lrs = fmtG(lr);
        std::printf("run lr %s\n", lrs.c_str());
        bool crossed = false;
        int ups = 0;
        for (size_t i = 0; i < rows.size(); ++i) {
            const Row& r = rows[i];
            std::printf("  step %2d  z %+.4f  p %.4f  loss %.4f  grad %+.4f  move %+.4f\n", r.step, r.z, r.p, r.loss, r.grad, r.move);
            if (i > 0) {
                if ((rows[i - 1].z - bestZ) * (r.z - bestZ) < 0) crossed = true;
                if (r.loss > rows[i - 1].loss) ++ups;
            }
        }
        std::printf("  result lr %s: overshoot %s, loss up %d steps, final loss %.4f\n", lrs.c_str(), crossed ? "yes" : "no", ups, rows.back().loss);
    }
    if (!cfg.sweep.empty()) {
        std::printf("sweep after %d steps\n", cfg.steps);
        std::string reached;
        for (double lr : cfg.sweep) {
            double fin = run(target, st, lr, cfg.steps).back().loss;
            std::printf("  lr %5s  final loss %.4f\n", fmtG(lr).c_str(), fin);
            if (fin <= bestLoss + REACH) reached += (reached.empty() ? "" : ", ") + fmtG(lr);
        }
        std::printf("  within %s of best loss: lr %s\n", fmtG(REACH).c_str(), reached.empty() ? "none" : reached.c_str());
    }
    return 0;
}
