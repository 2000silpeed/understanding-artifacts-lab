# adam-20261108 — Adam 교육영상 source package

주제: **Adam — 기울기의 평균과 제곱 평균으로 학습 보폭 조절하기** (한국어 AI 기본기 강의, 16:9 + 9:16)

현재 상태: **소스만 있음.** 녹음·음악·렌더·업로드는 하지 않았다. 내레이션 시각은 추정값이다. 미감 승인은 대기 중이다.

## 들어 있는 것

| 경로 | 무엇 |
|---|---|
| `scenario.md` | 기획: 왜 이 예제인지, 비트 시트, 연출 규칙, 승인할 발음 |
| `voice/script.json` | 내레이션 원문(`text`), TTS 읽기(`tts`, `{cue}` 표시), 숫자 출처(`numbers`) |
| `plan.py` → `shots.json` → `shotlist.md` | 샷 계획(21샷). 내레이션 단어 시각과 박 격자를 쓴다. `shotlist.md`는 `pipeline/shotlint.py`가 만든다 |
| `film.js` | 실제 드로잉(엔진 `engine/*`, `system/components/type.js`·`diagram.js`, 토큰 레시피 cerulean·paper·orange) |
| `example/adam.py`, `example/adam.cpp`, `example/adam_core.hpp` | 실행 예제 Python / C++17 (표준 라이브러리만) |
| `example/fixtures/houses.csv` | 입력 fixture(예시 데이터 8행) |
| `example/run_examples.py` → `example/results/` | 두 구현을 모두 돌린 결과, 명령·exit·hash 기록(`run-log.json`), 영상이 읽는 숫자(`film_numbers.json`) |
| `practice/` | 실습: `adam_practice.py`, `adam_practice.cpp`(TODO 4곳), `check_practice.py`, `solutions/` |
| `tests/` | `test_adam.py`(예제 성질), `test_package.py`(발화·그림·계획·실습의 일치), `film_smoke.mjs`(모의 캔버스로 전 프레임 드로잉), `bundle_check.mjs`(메모리에서 실제 번들 빌드) |
| `tools/` | `voicelib.py`, `voice_lines.py`(녹음할 문장·명령 출력), `voice_cues.py`(녹음 + Scribe → `voice/timings.json`) |
| `qa/` | `author-result.json`(작성 기록), `smoke-report.json`, `smoke-texts.json`, `shotlint.json` |

## 확인 명령 (저장소 루트에서)

```sh
python3 films/adam-20261108/example/run_examples.py --check        # 결과가 새 실행과 같은지 (C++ 빌드 포함)
node films/adam-20261108/tests/film_smoke.mjs                      # 전 프레임 드로잉: 예외·위반·안전 영역·대본 표시·겹침
node films/adam-20261108/tests/bundle_check.mjs                    # 브라우저 번들 빌드 (쓰지 않음)
.venv/bin/python -m unittest discover -s films/adam-20261108/tests # 27개 (fontTools가 없으면 글리프 검사만 건너뜀)
.venv/bin/python pipeline/shotlint.py adam-20261108                # 계획 lint + shotlist.md
python3 films/adam-20261108/practice/check_practice.py             # 실습 확인 (TODO가 남아 있으면 FAIL)
```

## 다음 단계 (부모 단계, 승인 필요)

1. **발음 승인:** `voice/script.json`의 `readingsToApprove`.
2. **목소리 고르기와 녹음(유료):** 샘플 3–5개 중에서 고른다. 그다음 `python3 films/adam-20261108/tools/voice_lines.py --voice <voice_id>`가 출력한 `pipeline/elevenlabs.py tts …` 명령 11개를 실행한다. 녹음은 `voice/v1/seg-*.mp3`에 둔다.
3. **단어 시각 재기:** 각 녹음에 ElevenLabs Scribe를 돌려 `voice/v1/<같은 이름>.json`(`words` 배열)으로 저장한다. 이어서 `python3 films/adam-20261108/tools/voice_cues.py films/adam-20261108/voice/v1` → `python3 films/adam-20261108/plan.py` → `.venv/bin/python pipeline/shotlint.py adam-20261108`를 실행한다.
4. **음악(유료, 선택):** `shots.json`의 `music.brief`대로 만든다. `pipeline/measure_music.py`로 잰 뒤 `plan.py`의 `BPM`·`B`와 `music.offset`·`measured`를 고치고, 파일을 `music/score.mp3`에 둔다. 음악이 없으면 내레이션만으로 오디오를 만든다(`score.source: 'library'`, 음성 큐는 `src` 샘플).
5. **네이티브 스틸 게이트(사람 확인):** `node pipeline/build.cjs adam-20261108 && node pipeline/render.cjs adam-20261108 --format 16x9 --stills`. 9:16도 같은 방법으로 본다.
6. **제작과 검수:** `sh pipeline/make.sh adam-20261108 16x9 9x16` → `verify.py` PASS → `shotlint.py adam-20261108 --video 16x9 9x16` → `REVIEW.md` 기록.

## 알려 둘 한계

- 스모크 테스트의 글자 폭은 Pretendard의 실제 advance를 조금 넉넉하게 잡은 근사다. 실제 줄바꿈과 겹침은 스틸 게이트에서 확인해야 한다. 글자가 아닌 도형(막대·선)과 글자가 겹치는지는 자동으로 검사하지 않는다.
- 장면 길이(304.8초)는 녹음 전 추정이다. 녹음 뒤 `plan.py`를 다시 돌리면 바뀐다. 영상 안 모든 시각은 `shots.json`에서 읽으므로 `film.js`는 고치지 않아도 된다.
- 엔진·토큰·공유 컴포넌트는 고치지 않았다. 그래서 차트와 표 같은 보조 그리기는 `film.js` 안에 있다. 다른 강의에서도 쓰게 되면 `system/components`로 옮길 후보다.
