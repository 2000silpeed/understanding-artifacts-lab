"""Writes films/adam-20261108/shots.json — Adam: 기울기의 평균과 제곱 평균으로 학습 보폭 조절하기 (AI 기본기 강의).

Script first (docs: motion-movie-director skill, "Narrated films"). The narration lives in voice/script.json with {cue}
markers on the words that bring in a picture element. Until the recordings exist, word times are a placeholder estimate
(tools/voicelib.estimate, 6 syllables/s) and the plan says so (`voice.<scene>.estimated: true`). After recording and
Scribe, `tools/voice_cues.py <dir>` writes voice/timings.json; re-run this file and every cut moves to the real words.
Scene lengths round up to whole music bars (4 beats); the grid is a 100 BPM placeholder until the music is measured.

usage: python3 films/adam-20261108/plan.py && .venv/bin/python pipeline/shotlint.py adam-20261108
"""
import json
import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'tools'))
import voicelib  # noqa: E402

OUT = HERE / 'shots.json'
BPM, B, BAR = 100, 0.6, 4          # placeholder grid until music.measured; 1 beat = 18 frames at 30 fps
LEAD, TAIL = 0.6, 0.9              # picture before the voice starts / after it ends, seconds
END_BEATS = 8                      # silent end card: 4.8 s (≥ 3 s final read hold)
script = voicelib.load_script()
measured = json.loads(voicelib.TIMINGS.read_text(encoding='utf-8'))['scenes'] if voicelib.TIMINGS.exists() else {}

VO, SCENE_BEATS = {}, {}
for s in script['scenes']:
    if s['id'] in measured:
        m = measured[s['id']]
        VO[s['id']] = {'file': s['file'], 'len': m['len'], 'lead': LEAD, 'cues': m['cues'], 'estimated': False}
    else:
        length, cues = voicelib.estimate(s['tts'])
        VO[s['id']] = {'file': s['file'], 'len': length, 'lead': LEAD, 'cues': cues, 'estimated': True}
    SCENE_BEATS[s['id']] = BAR * math.ceil((LEAD + VO[s['id']]['len'] + TAIL) / B / BAR)
SCENE_BEATS['end'] = END_BEATS

start, starts = 0, {}
for k, n in SCENE_BEATS.items():
    starts[k] = start
    start += n
for k, v in VO.items():
    v['at'] = round(starts[k] * B + v['lead'], 3)  # film time the recording starts
    assert v['lead'] + v['len'] < SCENE_BEATS[k] * B, k


def beat(scene, cue):
    """Absolute (fractional) beat of a spoken cue."""
    return round(starts[scene] + (VO[scene]['lead'] + VO[scene]['cues'][cue]) / B, 3)


def ev(scene, *cues):
    return [{'beat': beat(scene, c), 'what': f'"{c}" 큐'} for c in cues]


ESTIMATED = any(v['estimated'] for v in VO.values())
plan = {
 'film': 'adam-20261108', 'title': 'Adam — 기울기의 평균과 제곱 평균으로 학습 보폭 조절하기', 'version': 'v1 (대본 먼저, 녹음 전 소스, 2026-11-08)',
 'format': ['16x9', '9x16'], 'fps': 30, 'durationBeats': start,
 'music': {'file': 'music/score.mp3', 'bpm': BPM, 'beatSeconds': B, 'offset': 0.0,
   'brief': '강의 배경음(보컬 없음). 차분한 로파이·앰비언트 피아노, 100 BPM 근처, 4박 마디. 영상 길이만큼 이어지거나 짧은 곡을 이음매 없이 반복. 장 경계(요약 → 사용 상황 → 본 강의 → 정리)에서 마디가 바뀌면 좋지만 필수 아님. 내레이션 아래 0.6배, 12 dB 덕킹. 끝 카드에서 마지막 코드.',
   'measured': '미측정 — 음악 생성(유료, 승인 필요) 후 pipeline/measure_music.py로 BPM·위상·구간을 재고 bpm/beatSeconds/offset을 고친다. 지금 박 격자는 100 BPM 가정.'},
 'voice': VO,
 'vision': '말하는 순간 보인다 — 숫자 하나하나가 실제로 돌린 예제에서 나오고, 내레이션이 그 숫자를 부르는 순간 화면에 놓인다. 끝에 남는 것은 "평균은 방향, 제곱 평균은 크기, 둘을 나누면 파라미터마다의 보폭".',
 'principles': [
  '대본 먼저: voice/script.json → 녹음 → Scribe 단어 시각(tools/voice_cues.py) → 이 계획 → 렌더. 지금 시각은 ' + ('추정값(6음절/초)이다.' if ESTIMATED else '녹음에서 잰 값이다.'),
  '구성: 제목 → 핵심 요약(세 줄) → 구체적 사용 상황(집값 예측, 경사하강법 vs Adam) → 본 강의 4단계(m · v · 편향 보정 · 보폭) + 기본값 → 정리 → 끝 카드.',
  '숫자: 화면과 내레이션의 모든 수치는 example/results/film_numbers.json(실제 실행 결과)에서 온다. 데이터가 예시라 수치 곁에 "예시 값"을 붙인다.',
  '색: 요약·정리 = cerulean(개념), 사용 상황 = paper(데이터·작업지), 본 강의 = orange(계산). 장면 안에서 레시피를 섞지 않는다. 강의 색 약속: 기울기 g = ink, m = accent, v = muted.',
  '움직임: 등장은 위치 이동(rise)과 선 그리기만. 도형과 글자는 같은 변환으로 함께 움직인다. 장면 첫 프레임에 헤드라인이 이미 오르기 시작한다(컷 프레임이 가장 큰 변화).',
  '시간 기준: 장면 경계는 음악 마디(2.4초), 장면 안 등장은 단어 시각(rules.voiceScenes).',
  '유일한 사치: 첫 걸음 보폭이 두 파라미터 모두 1이 되는 순간(C09-01) — 기울기가 40배 다른데 같은 보폭.',
  '9:16: 표·차트는 무대 위아래로 다시 쌓고, 카드 셋은 세로 3단.'],
 'vocabulary': {
  'size': {'FULL': '화면 가득', 'CARD-L': '주인공 폭이 화면 폭의 55–65%', 'CARD-M': '30–50%', 'CARD-S': '30% 미만', 'GRID': '같은 크기 여러 개가 한 판', 'TYPE': '글자·수식 단독', 'LOCKUP': '제목 묶음'},
  'comp': {'C': '중앙', 'T': '위 제목 + 아래 무대', 'L3': '왼쪽 1/3 카피 + 오른쪽 무대'},
  'light': {'cerulean': '개념(요약·정리·제목)', 'paper': '데이터와 실험(사용 상황)', 'orange': '계산(본 강의)'}},
 'rules': {'maxSameSize': 2, 'halfBeatScenes': [], 'voiceScenes': [s['id'] for s in script['scenes']]},
 'motifs': [
  {'id': 'M1', 'name': '발자국 줄', 'shots': ['C01-01', 'C09-02', 'C11-01'], 'note': 'Adam이 거리 가중치를 0에서 −50으로 옮긴 100걸음을 점으로 찍는다. 간격 = 그 걸음의 보폭. 제목에서 심고, 보폭 차트에서 이유를 보이고, 정리에서 회수.'},
  {'id': 'M2', 'name': '같은 축의 두 곡선', 'shots': ['C04-02', 'C05-01'], 'note': '거리 가중치 vs 걸음. 경사하강법 곡선이 남은 자리에 Adam 곡선이 겹친다.'},
  {'id': 'M3', 'name': '면적 기울기 막대', 'shots': ['C06-02', 'C07-02'], 'note': '같은 12걸음 막대: m에서는 부호째, v에서는 제곱(위로 뒤집힘).'},
  {'id': 'M4', 'name': '40배', 'shots': ['C03-02', 'C09-01'], 'note': '기울기 40배 차이 → 같은 보폭 1.'}],
 'shots': [],
}


def S(id, scene, b0, nb, cut, size, comp, move, vocab, subject, action, audio, light, purpose, transition, callback='', copy='', **kw):
    plan['shots'].append(dict(id=id, scene=scene, startBeat=b0, beats=round(nb, 3), cut=cut, size=size, comp=comp, move=move, vocab=vocab, subject=subject,
                              action=action, audio=audio, light=light, purpose=purpose, transition=transition, callback=callback, copy=copy, **kw))


def one(no, scene, cut, size, comp, move, vocab, subject, action, light, purpose, callback='', copy='', events=()):
    b0 = starts[scene]
    S(f'C{no:02d}-01', scene, b0, SCENE_BEATS[scene], cut, size, comp, move, vocab, subject, action, f'내레이션 {VO[scene]["file"]}' if scene in VO else '음악 끝 코드',
      light, purpose, '다음 장면 마디 하드컷', callback, copy, events=list(events))


def two(no, scene, cue, a, b, cut2='hard'):
    """Scene split at a spoken cue into two shots; a, b = dicts of the remaining fields."""
    b0, b1, bE = starts[scene], beat(scene, cue), starts[scene] + SCENE_BEATS[scene]
    S(f'C{no:02d}-01', scene, b0, b1 - b0, 'hard', audio=f'내레이션 {VO[scene]["file"]}', transition=f'"{cue}" 큐에서 {cut2}', **a)
    S(f'C{no:02d}-02', scene, b1, bE - b1, cut2, audio='내레이션 계속', transition='다음 장면 마디 하드컷', **b)


N = json.loads((HERE / 'example/results/film_numbers.json').read_text(encoding='utf-8'))

one(1, 'open', 'hard', 'TYPE', 'C', '"Adam" rise, 부제는 "sub" 큐에 rise, 발자국 점이 왼쪽에서 오른쪽으로 찍힘', '대형 제목 + 발자국 줄', 'Adam',
    '제목과 부제, 아래에 Adam이 실제로 걸은 100걸음이 점으로 찍힌다.', 'cerulean', '무엇을 배우는지 한 줄로.', 'M1 시작',
    'Adam / 기울기의 평균과 제곱 평균으로 / 학습 보폭 조절하기', ev('open', 'sub'))
two(2, 'summary', 'note1',
    dict(size='GRID', comp='T', move='헤드라인 rise, 카드 셋이 "첫째·둘째·셋째"에 하나씩 rise', vocab='개념 카드 3장(m · v · 보폭)', subject='핵심 세 가지',
         action='m = 기울기의 평균(방향), v = 기울기 제곱의 평균(크기), 보폭 = α·m̂ ÷ √v̂.', light='cerulean', purpose='영상 전체를 30초에 먼저 준다.',
         copy='m 기울기의 평균 → 방향 / v 기울기 제곱의 평균 → 크기 / α·m̂ ÷ (√v̂ + ε) → 파라미터마다 보폭', events=ev('summary', 'c1', 'c2', 'c3')),
    dict(size='GRID', comp='T', move='카드 아래 두 줄이 "그래서"·"방향이"에 rise', vocab='결론 두 줄', subject='무엇이 달라지나',
         action='크든 작든 비슷한 보폭으로 출발 / 방향이 흔들리면 보폭이 준다.', light='cerulean', purpose='요약의 결론.', copy='기울기가 크든 작든 → 비슷한 보폭으로 출발 / 방향이 오락가락 → 보폭이 줄어든다',
         events=ev('summary', 'note2')), cut2='pop')
two(3, 'case', 'gA',
    dict(size='CARD-L', comp='L3', move='데이터 표가 컷 프레임에 rise, "면적은"·"거리는"에 해당 열 강조', vocab='예시 데이터 표 8행', subject='집값 예측',
         action=f'면적 {int(N["data"]["rows"][0][0])}–{int(N["data"]["rows"][-1][0])}㎡, 거리 0.5·2.5km, 가격(백만원). 평균을 뺀 차이로 학습.', light='paper', purpose='어디에 쓰는지 — 단위가 다른 입력.',
         copy='면적과 역까지 거리로 집값 예측 / 면적 차이 ±30㎡ · 거리 차이 ±1km', events=ev('case', 'table', 'area', 'station')),
    dict(size='CARD-L', comp='L3', move='첫 기울기 막대 두 개가 공통 기준선에서 자람, "사십 배"에 배수 표시', vocab='compare 막대', subject='첫 기울기',
         action=f'∂L/∂w면적 = {N["init"]["g"][0]:g}, ∂L/∂w거리 = {N["init"]["g"][1]:g}.', light='paper', purpose='문제의 핵심: 40배.', callback='M4 시작',
         copy='첫 기울기 / 면적 −2000 · 거리 50 / 40배', events=ev('case', 'gS', 'ratio')), cut2='pop')
two(4, 'sgd', 'lrLow',
    dict(size='CARD-M', comp='T', move='"영 점 영영사오"에 면적 가중치 값이 한 칸씩 튀는 지그재그, "영 점 영영사"에 한계선', vocab='지그재그 꺾은선 + 값 칩', subject='학습률 0.0045',
         action='w면적: 9 → −2.25 → 11.81 → … 발산.', light='paper', purpose='같은 학습률의 위험: 큰 기울기 쪽이 튄다.',
         copy='경사하강법: 모든 파라미터에 같은 학습률 / 학습률 0.0045 → 발산 / 안정 한계 0.004', events=ev('sgd', 'lrHigh', 'bounce', 'limit')),
    dict(size='CARD-L', comp='T', move='새 무대: 거리 가중치 곡선이 100걸음 그려지고 진행 막대 두 개', vocab='꺾은선(w거리 vs 걸음) + 정답선', subject='학습률 0.0035',
         action='면적 4.00 도착, 거리 −14.79(정답 −50).', light='paper', purpose='작은 학습률의 문제: 작은 기울기 쪽이 느리다.', callback='M2 시작',
         copy='학습률 0.0035 · 100걸음 / 면적 4.00 · 거리 −14.79 / 정답 −50', events=ev('sgd', 'area4', 'station', 'target')))
two(5, 'adamcase', 'loss',
    dict(size='CARD-L', comp='T', move='같은 축에 Adam 곡선이 그려짐(경사하강법 곡선은 흐리게 남음)', vocab='같은 축의 두 곡선', subject='Adam 100걸음',
         action='Adam: 면적 3.99, 거리 −50.39.', light='paper', purpose='해결을 먼저 보여 준다.', callback='M2 회수',
         copy='Adam · 학습률 1 · 100걸음 / 면적 3.99 · 거리 −50.39', events=ev('adamcase', 'run', 'area', 'station')),
    dict(size='CARD-L', comp='T', move='결과 표의 손실 열이 rise, "어떻게"에 본 강의 예고', vocab='결과 표', subject='손실 비교',
         action='100걸음 손실: 경사하강법 619.97, Adam 0.11.', light='paper', purpose='차이를 숫자로 확정하고 강의로 넘긴다.',
         copy='손실 619.97 vs 0.11 / 어떻게? → 한 단계씩', events=ev('adamcase', 'lossAdam', 'bridge')), cut2='pop')
two(6, 'lec1', 'chart',
    dict(size='TYPE', comp='C', move='수식 rise, "십 퍼센트"·"베타 원"에 계수 강조', vocab='수식 카드', subject='m의 갱신식',
         action='m ← β₁·m + (1 − β₁)·g, β₁ = 0.9.', light='orange', purpose='m이 무엇인지 식으로.', copy='m ← β₁·m + (1 − β₁)·g / 새 기울기 10% + 지난 m 90%', events=ev('lec1', 'formula', 'beta')),
    dict(size='CARD-L', comp='T', move='면적 기울기 막대 12개가 걸음 순서로 자람, "여섯 번째"에 부호 바뀐 막대 강조, "엠은 천천히"에 m 선이 그려짐', vocab='막대(g) + 선(m)', subject='면적 가중치의 12걸음',
         action='g: −2000 → … 6번째에 +; m은 −412에서 0 근처로.', light='orange', purpose='m = 방향의 평균, 흔들리면 상쇄.', callback='M3 시작',
         copy='면적 가중치: 기울기 g와 m (1–12걸음) / 6번째 걸음: 부호가 바뀜', events=ev('lec1', 'flip', 'mline', 'sum')))
two(7, 'lec2', 'sq',
    dict(size='TYPE', comp='C', move='수식 rise, "베타 투"에 0.999 강조', vocab='수식 카드', subject='v의 갱신식', action='v ← β₂·v + (1 − β₂)·g², β₂ = 0.999.',
         light='orange', purpose='v가 무엇인지 식으로.', copy='v ← β₂·v + (1 − β₂)·g² / β₂ = 0.999: 훨씬 오래 기억', events=ev('lec2', 'formula', 'beta')),
    dict(size='CARD-L', comp='T', move='같은 막대가 제곱되어 모두 위로 뒤집힘(transform), √v̂ 선이 그려짐, 오른쪽에 거리 쪽 값', vocab='막대(|g|) + 선(√v̂)', subject='면적과 거리의 √v̂',
         action='면적 √v̂: 2000 → 976, 거리: 50 → 44.65.', light='orange', purpose='v = 부호 없는 크기의 기억.', callback='M3 회수',
         copy='제곱하면 부호가 사라진다 / 면적 √v̂ 2000 → 976 · 거리 √v̂ 50 → 44.65', events=ev('lec2', 'area', 'station', 'sum')))
two(8, 'lec3', 'nobc',
    dict(size='GRID', comp='T', move='계산 두 줄(m, v)이 단어마다 한 칸씩 채워짐', vocab='계산표 2행 × 4칸', subject='첫 걸음의 m, v',
         action='m₁ = −200 → ÷0.1 → m̂₁ = −2000 / v₁ = 4000 → ÷0.001 → √v̂₁ = 2000.', light='orange', purpose='0에서 출발한 평균을 원래 크기로 되돌린다.',
         copy='m̂ = m ÷ (1 − β₁ᵗ) · v̂ = v ÷ (1 − β₂ᵗ) / m₁ = −200 → m̂₁ = −2000 / v₁ = 4,000 → √v̂₁ = 2000', events=ev('lec3', 'zero', 'm1', 'v1', 'formula', 'fix', 'hat')),
    dict(size='GRID', comp='T', move='아래에 비교 칩 두 개 rise', vocab='비교 칩', subject='보정 유무', action='보정 없음: 첫 걸음 3.16 / 보정: 1.00.', light='orange',
         purpose='보정이 왜 필요한지 숫자로.', copy='보정 없이 첫 걸음 3.16 · 보정하면 1.00'), cut2='pop')
two(9, 'lec4', 't20',
    dict(size='TYPE', comp='C', move='보폭 식 rise, "첫 걸음에서"·"거리는"에 계산 두 줄, "둘 다 일"에 결과 강조', vocab='수식 + 계산 두 줄', subject='첫 걸음의 보폭',
         action='면적: 1 × (−2000) ÷ 2000 = −1, 거리: 1 × 50 ÷ 50 = 1.', light='orange', purpose='유일한 사치: 40배 다른 기울기가 같은 보폭 1.', callback='M4 회수',
         copy='Δw = α · m̂ ÷ (√v̂ + ε) / 면적 −2000 ÷ 2000 · 거리 50 ÷ 50 / 둘 다 보폭 1', events=ev('lec4', 'formula', 't1', 't1s', 'one')),
    dict(size='CARD-L', comp='T', move='100걸음 보폭 꺾은선 두 개가 그려지고 20번째 걸음에 표시', vocab='꺾은선(|Δw| vs 걸음)', subject='걸음마다의 보폭',
         action='20번째: 면적 0.07, 거리 0.91.', light='orange', purpose='보폭이 파라미터마다 따로 조절된다.', callback='M1 이유',
         copy='걸음마다의 보폭 |Δw| / 20번째 걸음: 면적 0.07 · 거리 0.91', events=ev('lec4', 'area', 'station', 'sum')))
two(10, 'defaults', 'ours',
    dict(size='GRID', comp='T', move='기본값 칩 넷이 이름을 부를 때 하나씩 rise', vocab='값 칩 4개', subject='기본값', action='α 0.001 · β₁ 0.9 · β₂ 0.999 · ε 10⁻⁸.', light='orange',
         purpose='실무 출발점.', copy='α 0.001 · β₁ 0.9 · β₂ 0.999 · ε 10⁻⁸', events=ev('defaults', 'lr', 'b1', 'b2', 'eps')),
    dict(size='GRID', comp='T', move='아래 두 줄 rise', vocab='주의 문장', subject='학습률은 여전히 정한다', action='이 예제 α = 1, 최대 보폭 1.00.', light='orange',
         purpose='오해 방지: Adam도 학습률이 필요하다.', copy='이 예제: α = 1 (가중치가 수십 단위) / 한 걸음 ≈ α 이하 → 학습률은 직접 정한다', events=ev('defaults', 'bound', 'choose')), cut2='pop')
one(11, 'recap', 'hard', 'GRID', 'T', '세 줄이 m·v·보폭을 부를 때 rise, 아래 발자국 줄', '요약 3행 + 발자국 줄', '정리',
    'm = 방향, v = 크기, 보폭 = 둘을 나눈 값 × 학습률.', 'cerulean', '기억할 한 장.', 'M1 회수',
    'm 평균 → 방향 / v 제곱 평균 → 크기 / α·m̂ ÷ √v̂ → 파라미터마다 보폭 / 예제·실습: example/ · practice/', ev('recap', 'm', 'v', 'step', 'practice'))
S('C12-01', 'end', starts['end'], END_BEATS, 'hard', 'LOCKUP', 'C', '제목 정착, 움직임 없음(읽기 홀드)', '제목 묶음', 'Adam', '제목과 부제, 시리즈 이름.', '음악 마지막 코드',
  'cerulean', '이름을 남긴다.', '— (끝)', '', 'Adam / 기울기의 평균과 제곱 평균으로 학습 보폭 조절하기 / AI 기본기')
OUT.write_text(json.dumps(plan, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print('shots', len(plan['shots']), 'beats', start, 'seconds', round(start * B, 1), 'voice', 'ESTIMATED' if ESTIMATED else 'measured')
