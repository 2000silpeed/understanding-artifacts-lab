// The browser bundle builds exactly as pipeline/build.cjs builds it (engine/main.js + typegpu plugin + @film alias),
// but in memory: nothing is written to public/bundles. Use it before the native render stage.
// usage: node films/adam-20261108/tests/bundle_check.mjs        (exit 0 = bundle builds)
import { createRequire } from 'module';
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const FILM = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ROOT = path.resolve(FILM, '../..');
const mods = [ROOT, path.resolve(ROOT, '../../..')].map(p => path.join(p, 'node_modules')).find(p => fs.existsSync(path.join(p, 'esbuild')) && fs.existsSync(path.join(p, 'unplugin-typegpu')));
if (!mods) { console.error('esbuild / unplugin-typegpu not found: run npm ci in the repo root'); process.exit(2); }
const esbuild = createRequire(import.meta.url)(path.join(mods, 'esbuild'));
const typegpuEntry = createRequire(path.join(mods, 'x.js')).resolve('unplugin-typegpu/esbuild');
const tgMod = await import(pathToFileURL(typegpuEntry).href);
const typegpu = typeof tgMod.default === 'function' ? tgMod.default : tgMod.default.default; // CJS entry wraps the default
const res = await esbuild.build({
  entryPoints: [path.join(ROOT, 'engine/main.js')],
  bundle: true, format: 'iife', platform: 'browser', write: false, logLevel: 'warning',
  plugins: [typegpu()],
  alias: { '@coreroot': path.join(ROOT, 'vendor/shaders-core/src'), '@film': path.join(FILM, 'film.js') },
  define: { __SHADERS_VERSION__: '"pinned-9ea3bf5"', 'process.env.NODE_ENV': '"production"' },
  nodePaths: [mods],
});
const bytes = res.outputFiles[0].contents.length;
console.log(`BUNDLE OK ${bytes} bytes, ${res.warnings.length} warnings (not written)`);
