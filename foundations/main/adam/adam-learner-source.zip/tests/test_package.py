"""Package consistency: narration, picture, plan and practice agree with the example run.

run: python3 -m unittest discover -s films/adam-20261108/tests -v
Checks that need the repo's .venv (fontTools) or node+esbuild skip with a reason when those are missing.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

FILM = Path(__file__).resolve().parents[1]
ROOT = FILM.parents[1]
sys.path.insert(0, str(FILM / 'tools'))
import voicelib  # noqa: E402

N = json.loads((FILM / 'example' / 'results' / 'film_numbers.json').read_text(encoding='utf-8'))
SCRIPT = json.loads((FILM / 'voice' / 'script.json').read_text(encoding='utf-8'))
PLAN = json.loads((FILM / 'shots.json').read_text(encoding='utf-8'))
ORD = {6: '여섯 번째', 20: '스무 번째'}
NUMS = re.compile(r'\d+(?:[.,]\d+)*')


def at(path):
    v = N
    for k in path.split('.'):
        v = v[int(k)] if isinstance(v, list) else v[k]
    return v


def fmt(v, kind):
    if kind == 'int':
        return str(int(round(v)))
    if kind == 'g':
        return repr(v).rstrip('0').rstrip('.') if isinstance(v, float) else str(v)
    if kind == 'f2':
        return f'{v:.2f}'
    if kind == 'signed_ko':
        return ('마이너스 ' if v < 0 else '') + str(int(round(abs(v))))
    if kind == 'signed_ko_f2':
        return ('마이너스 ' if v < 0 else '') + f'{abs(v):.2f}'
    if kind == 'pct':
        return str(int(round(v * 100)))
    if kind == 'pct_complement':
        return str(int(round((1 - v) * 100)))
    if kind == 'ordinal_ko':
        return ORD[int(v)]
    if kind == 'frac_ko':
        return {0.1: '10분의 1', 0.001: '천분의 1'}[round(v, 12)]
    if kind == 'man':
        assert v % 10000 == 0
        return f'{int(v // 10000)}만'
    if kind == 'round_thousand':
        return str(int(round(v, -3)))
    if kind == 'pow10_ko':
        import math
        return f'10의 마이너스 {abs(round(math.log10(v)))}제곱'
    raise ValueError(kind)


class Narration(unittest.TestCase):
    def test_every_spoken_number_comes_from_the_run(self):
        for sc in SCRIPT['scenes']:
            plain, _, _ = voicelib.parse(sc['tts'])
            for n in sc['numbers']:
                with self.subTest(scene=sc['id'], number=n['text']):
                    shown = n.get('prefix', '') + fmt(at(n['source']), n['fmt']) + n.get('suffix', '')
                    self.assertEqual(shown, n['text'])
                    self.assertIn(n['text'], sc['text'])
                    self.assertIn(n['reading'], plain)

    def test_no_unlisted_digits_in_the_narration(self):
        allow = SCRIPT['whitelistTokens']
        for sc in SCRIPT['scenes']:
            text = sc['text']
            for n in sorted(sc['numbers'] + [{'text': w} for w in allow], key=lambda n: -len(n['text'])):
                text = text.replace(n['text'], ' ')
            with self.subTest(scene=sc['id']):
                self.assertEqual(NUMS.findall(text), [], 'digits in `text` without a `numbers` entry')

    def test_tts_has_no_digits_or_latin(self):
        for sc in SCRIPT['scenes']:
            plain, _, _ = voicelib.parse(sc['tts'])
            with self.subTest(scene=sc['id']):
                self.assertIsNone(re.search(r'[0-9A-Za-z]', plain), plain)

    def test_text_and_tts_have_the_same_sentences(self):
        for sc in SCRIPT['scenes']:
            plain, _, _ = voicelib.parse(sc['tts'])
            with self.subTest(scene=sc['id']):
                self.assertEqual(len(re.findall(r'[.?!](?=\s|$)', sc['text'])), len(re.findall(r'[.?!](?=\s|$)', plain)))

    def test_claims_in_words_hold(self):
        a = N['adam']
        self.assertLess(a['areaFirst12']['mMinAbs'], 0.1 * a['areaFirst12']['mMaxAbs'])   # "m은 0 근처로 줄어듭니다"
        self.assertEqual(a['firstAreaPassAnswer'] + 1, a['firstAreaSignFlip'])             # "정답 4를 지나쳤기 때문"
        self.assertLess(a['areaFirst12']['sqrtVHatLast'], a['areaFirst12']['sqrtVHat'][0])   # "천천히 줄 뿐"
        self.assertGreater(a['areaFirst12']['sqrtVHatLast'], 0.45 * a['areaFirst12']['sqrtVHat'][0])
        s = a['stationFirst12']['sqrtVHat']
        self.assertTrue(all(x > y for x, y in zip(s, s[1:])))                                # "50에서 조금씩 줄어듭니다"
        self.assertGreater(s[-1], 0.85 * s[0])
        self.assertLessEqual(a['maxStepAbs'], a['lr'])                                       # "대략 학습률 안쪽"
        self.assertEqual(N['init']['ratio'], 40.0)


class Plan(unittest.TestCase):
    def test_plan_matches_the_script(self):
        measured = voicelib.TIMINGS.exists()
        for sc in SCRIPT['scenes']:
            v = PLAN['voice'][sc['id']]
            with self.subTest(scene=sc['id']):
                self.assertEqual(v['file'], sc['file'])
                self.assertEqual(v['estimated'], not measured)
                if not measured:
                    length, cues = voicelib.estimate(sc['tts'])
                    self.assertEqual((v['len'], v['cues']), (length, cues), 'shots.json is stale: run plan.py')
                self.assertLess(v['lead'] + v['len'], sum(s['beats'] for s in PLAN['shots'] if s['scene'] == sc['id']) * PLAN['music']['beatSeconds'])

    def test_shotlint_plan_passes(self):
        py = next((p for p in [ROOT / '.venv/bin/python', ROOT.parents[2] / '.venv/bin/python'] if p.exists()), Path(sys.executable))
        with tempfile.TemporaryDirectory() as tmp:  # shotlint writes shotlist.md + qa/shotlint.json; run it on a copy
            film = Path(tmp) / 'films' / PLAN['film']
            (film / 'qa').mkdir(parents=True)
            shutil.copy(FILM / 'shots.json', film / 'shots.json')
            (Path(tmp) / 'pipeline').mkdir()
            for f in ('shotlint.py', 'tools.py'):
                shutil.copy(ROOT / 'pipeline' / f, Path(tmp) / 'pipeline' / f)
            r = subprocess.run([str(py), str(Path(tmp) / 'pipeline' / 'shotlint.py'), PLAN['film']], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
            self.assertEqual((film / 'shotlist.md').read_text(encoding='utf-8'), (FILM / 'shotlist.md').read_text(encoding='utf-8'), 'shotlist.md is stale')

    def test_voice_alignment_tool(self):
        # a fake Scribe transcript: numbers written as digits, one word dropped — cues still land on their words
        sc = next(s for s in SCRIPT['scenes'] if s['id'] == 'case')
        _, words, cues = voicelib.parse(sc['tts'])
        heard, t = [], 0.0
        for i, w in enumerate(words):
            text = {'이천,': '2000,', '오십.': '50.', '사십': '40'}.get(w, w)
            if i != 3:
                heard.append({'text': text, 'start': round(t, 3), 'end': round(t + 0.3, 3), 'type': 'word'})
            t += 0.4
        got, rep = voicelib.align(sc['tts'], heard)
        for cue, i in cues.items():
            with self.subTest(cue=cue):
                self.assertAlmostEqual(got[cue], 0.4 * i, places=3)
        self.assertIn('ratio', rep['interpolatedCues'])


class Picture(unittest.TestCase):
    TEXTS = FILM / 'qa' / 'smoke-texts.json'

    def test_every_number_on_screen_comes_from_the_run(self):
        if not self.TEXTS.exists():
            self.skipTest('run node films/adam-20261108/tests/film_smoke.mjs first')
        vals = set()

        def walk(v):
            if isinstance(v, bool):
                return
            if isinstance(v, (int, float)):
                for x in (v, -v, abs(v), v / 2, v * 100, (1 - v) * 100, v * v):
                    vals.add(round(x, 6))
            elif isinstance(v, list):
                [walk(x) for x in v]
            elif isinstance(v, dict):
                [walk(x) for x in v.values()]
        walk(N)
        structural = set(range(0, 13)) | {20, 25, 50, 100}  # step indices, axis ticks, kicker numbers
        bad = []
        for text in json.loads(self.TEXTS.read_text(encoding='utf-8')):
            for tok in NUMS.findall(text.replace('−', '-')):
                v = float(tok.replace(',', ''))
                d = len(tok.split('.')[1]) if '.' in tok else 0
                if v in structural or any(abs(v - abs(x)) < 0.5 * 10 ** -d + 1e-9 for x in vals):
                    continue
                bad.append((text, tok))
        self.assertEqual(bad, [])

    def test_glyphs_are_in_the_font(self):
        try:
            from fontTools.ttLib import TTFont
        except ImportError:
            self.skipTest('fontTools not installed (use the repo .venv)')
        if not self.TEXTS.exists():
            self.skipTest('run film_smoke.mjs first')
        cmap = TTFont(str(ROOT / 'public/fonts/Pretendard.woff2')).getBestCmap()
        chars = {ch for t in json.loads(self.TEXTS.read_text(encoding='utf-8')) for ch in t if not ch.isspace()}
        self.assertEqual(sorted(ch for ch in chars if ord(ch) not in cmap), [])

    @unittest.skipUnless(shutil.which('node'), 'node not installed')
    def test_film_smoke(self):
        r = subprocess.run(['node', str(FILM / 'tests' / 'film_smoke.mjs')], capture_output=True, text=True)
        if r.returncode == 2:
            self.skipTest(r.stderr.strip())
        self.assertEqual(r.returncode, 0, r.stdout[-3000:] + r.stderr[-2000:])


class Practice(unittest.TestCase):
    CHECK = FILM / 'practice' / 'check_practice.py'

    def run_check(self, *args):
        return subprocess.run([sys.executable, str(self.CHECK), *args], capture_output=True, text=True)

    def test_untouched_practice_fails_with_a_hint(self):
        r = self.run_check()
        self.assertEqual(r.returncode, 1)
        self.assertIn('TODO', r.stdout)

    def test_solution_passes(self):
        r = self.run_check(str(FILM / 'practice' / 'solutions' / 'adam_practice_solved.py'))
        self.assertEqual(r.returncode, 0, r.stdout)

    def test_missing_bias_correction_is_named(self):
        src = (FILM / 'practice' / 'solutions' / 'adam_practice_solved.py').read_text(encoding='utf-8')
        src = src.replace('/ (1 - self.b1 ** self.t)', '').replace('/ (1 - self.b2 ** self.t)', '')
        src = src.replace("Path(__file__).resolve().parents[1]", repr(str(FILM / 'practice')))
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'no_bias.py'
            p.write_text(src, encoding='utf-8')
            r = self.run_check(str(p))
        self.assertEqual(r.returncode, 1)
        self.assertIn('편향 보정', r.stdout)

    @unittest.skipUnless(shutil.which('c++') or shutil.which('clang++') or shutil.which('g++'), 'no C++ compiler')
    def test_cpp_practice(self):
        self.assertEqual(self.run_check('--cpp').returncode, 1)
        r = self.run_check('--cpp', str(FILM / 'practice' / 'solutions' / 'adam_practice_solved.cpp'))
        self.assertEqual(r.returncode, 0, r.stdout)


if __name__ == '__main__':
    os.chdir(ROOT)
    unittest.main()
