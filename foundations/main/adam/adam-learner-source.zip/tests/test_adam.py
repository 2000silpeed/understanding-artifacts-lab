"""Tests for the example: what the film claims about Adam must hold in the code that produced its numbers.

run: python3 -m unittest discover -s films/adam-20261108/tests -v
"""
import json
import math
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

FILM = Path(__file__).resolve().parents[1]
EX = FILM / 'example'
sys.path.insert(0, str(EX))
import adam  # noqa: E402

FIX = EX / 'fixtures' / 'houses.csv'
ANSWER = (4.0, -50.0)


class AdamRule(unittest.TestCase):
    def test_first_step_is_lr_for_every_parameter(self):
        # gradients differ 40×, the first step is α for both (bias-corrected m̂/√v̂ = g/|g|)
        r = adam.fit(FIX, 'adam', 1.0, 1)
        g, step = r['trace'][0]['g'], r['trace'][0]['step']
        self.assertAlmostEqual(abs(g[0] / g[1]), 40.0, places=9)
        for s in step:
            self.assertAlmostEqual(abs(s), 1.0, places=9)

    def test_bias_correction_restores_the_gradient(self):
        row = adam.fit(FIX, 'adam', 1.0, 1)['trace'][0]
        for i in range(2):
            self.assertAlmostEqual(row['m'][i], 0.1 * row['g'][i], places=9)           # m starts at 0 → a tenth
            self.assertAlmostEqual(row['m_hat'][i], row['g'][i], places=9)            # ÷ (1 − 0.9)
            self.assertAlmostEqual(row['v_hat'][i] / row['g'][i] ** 2, 1.0, places=9)  # ÷ (1 − 0.999)

    def test_without_bias_correction_the_first_step_is_3_16(self):
        row = adam.fit(FIX, 'adam', 1.0, 1, bias_correction=False)['trace'][0]
        expected = 0.1 / math.sqrt(0.001)
        for s in row['step']:
            self.assertAlmostEqual(abs(s), expected, places=6)
        self.assertEqual(round(expected, 2), 3.16)

    def test_update_does_not_depend_on_gradient_scale(self):
        seq = [3.0, 2.5, -1.0, 4.0, 0.5, -2.0, 1.5, 1.0]
        a, b = adam.Adam(0.1), adam.Adam(0.1)
        wa, wb = [0.0, 0.0], [0.0, 0.0]
        for x in seq:
            wa, sa = a.step(wa, [x, x])
            wb, sb = b.step(wb, [x * 1e4, x * 1e-3])  # same direction, very different sizes
            for i in range(2):
                self.assertAlmostEqual(sa[i]['step'], sb[i]['step'], delta=1e-5)

    def test_flipping_gradient_shrinks_the_step(self):
        o = adam.Adam(1.0)
        w = [0.0, 0.0]
        for k in range(30):
            w, seen = o.step(w, [1.0, 1.0 if k % 2 == 0 else -1.0])  # [steady, flipping], same size
        self.assertGreater(abs(seen[0]['step']), 0.99)
        self.assertLess(abs(seen[1]['step']), 0.2)


class HouseExample(unittest.TestCase):
    def test_inputs_are_independent_and_answer_is_exact(self):
        d = adam.load(FIX)
        cov = sum(x0 * x1 for x0, x1 in d['X']) / d['n']
        self.assertEqual(cov, 0.0)
        loss, g = adam.loss_and_grad(list(ANSWER), d['X'], d['Y'])
        self.assertEqual((loss, g), (0.0, [0.0, 0.0]))

    def test_sgd_limit_is_two_over_largest_curvature(self):
        d = adam.load(FIX)
        limit = 2 / (sum(x0 * x0 for x0, _ in d['X']) / d['n'])
        self.assertAlmostEqual(limit, 0.004, places=12)
        stable, unstable = adam.fit(FIX, 'sgd', 0.0035, 100), adam.fit(FIX, 'sgd', 0.0045, 100)
        self.assertAlmostEqual(stable['final']['w'][0], ANSWER[0], places=6)
        self.assertGreater(abs(unstable['final']['w'][0]), 1e6)
        self.assertGreater(stable['final']['w'][1], -20)  # the small-gradient weight crawls

    def test_adam_reaches_the_answer_in_100_steps(self):
        a, s = adam.fit(FIX, 'adam', 1.0, 100), adam.fit(FIX, 'sgd', 0.0035, 100)
        self.assertLess(abs(a['final']['w'][0] - ANSWER[0]), 0.05)
        self.assertLess(abs(a['final']['w'][1] - ANSWER[1]), 0.5)
        self.assertLess(a['final']['loss'], 0.2)
        self.assertGreater(s['final']['loss'], 600)

    def test_every_step_stays_within_lr(self):
        r = adam.fit(FIX, 'adam', 1.0, 100)
        self.assertLessEqual(max(abs(x) for t in r['trace'] for x in t['step']), 1.0)

    def test_area_gradient_flips_after_passing_the_answer(self):
        tr = adam.fit(FIX, 'adam', 1.0, 12)['trace']
        flip = next(t['t'] for t in tr if t['g'][0] > 0)
        passed = next(t['t'] for t in tr if t['w'][0] > ANSWER[0])
        self.assertEqual((passed, flip), (5, 6))
        self.assertTrue(all(t['g'][1] > 0 for t in tr))  # the distance gradient keeps its sign


@unittest.skipUnless(shutil.which('c++') or shutil.which('clang++') or shutil.which('g++'), 'no C++ compiler')
class CppParity(unittest.TestCase):
    def test_cpp_matches_python_step_by_step(self):
        cxx = shutil.which('c++') or shutil.which('clang++') or shutil.which('g++')
        with tempfile.TemporaryDirectory() as tmp:
            exe = Path(tmp) / 'adam'
            subprocess.run([cxx, '-std=c++17', '-O2', '-ffp-contract=off', '-Wall', '-Wextra', '-Werror', '-o', str(exe), str(EX / 'adam.cpp')], check=True)
            for args in (['--opt', 'adam', '--lr', '1'], ['--opt', 'adam', '--lr', '1', '--no-bias-correction'], ['--opt', 'sgd', '--lr', '0.0035']):
                c = json.loads(subprocess.run([str(exe), 'fit', '--data', str(FIX), '--steps', '100'] + args, check=True, capture_output=True, text=True).stdout)
                bc = '--no-bias-correction' not in args
                p = adam.fit(FIX, args[1], float(args[3]), 100, bias_correction=bc)
                for rc, rp in zip(c['trace'], p['trace']):
                    for key in rp:
                        if isinstance(rp[key], list):
                            for x, y in zip(rc[key], rp[key]):
                                self.assertLessEqual(abs(x - y), 1e-12 * max(1.0, abs(y)), f'{args} t={rp["t"]} {key}')


class CommittedResults(unittest.TestCase):
    def test_results_match_a_fresh_run(self):
        r = subprocess.run([sys.executable, str(EX / 'run_examples.py'), '--check'], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)


if __name__ == '__main__':
    unittest.main()
