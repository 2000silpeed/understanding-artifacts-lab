// Source smoke test for film.js — no browser, no WebGPU, no frames written.
// Bundles film.js with esbuild (in memory), then calls every scene's draw() and the overlay for every frame of both
// formats against a mock Canvas2D whose measureText uses Pretendard's real advance widths (rounded up). It catches what a
// render would fail on before any render is spent: exceptions, layout violations, copy outside the safe area, script
// lines that never reach the screen, missing voice cues, plan/film length drift. It also writes the distinct drawn
// strings to qa/smoke-texts.json (tests/test_package.py checks every number in them against film_numbers.json) and
// likely text collisions (settled boxes overlapping at reading moments) to qa/smoke-report.json.
// usage: node films/adam-20261108/tests/film_smoke.mjs [--every N]     (exit 1 on failure)
// esbuild comes from the repo's node_modules (npm ci); in a worktree without it, the main checkout's is used.
import { createRequire } from 'module';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const FILM = path.resolve(HERE, '..');
const ROOT = path.resolve(FILM, '../..');
const every = Number(process.argv.includes('--every') ? process.argv[process.argv.indexOf('--every') + 1] : 1);
const require = createRequire(import.meta.url);
const esbuildPath = [ROOT, path.resolve(ROOT, '../../..')].map(p => path.join(p, 'node_modules', 'esbuild')).find(p => fs.existsSync(p));
if (!esbuildPath) { console.error('esbuild not found: run npm ci in the repo root'); process.exit(2); }
const esbuild = require(esbuildPath);

const bundle = await esbuild.build({ entryPoints: [path.join(FILM, 'film.js')], bundle: true, format: 'esm', platform: 'node', write: false, logLevel: 'error' });
const film = (await import('data:text/javascript;base64,' + Buffer.from(bundle.outputFiles[0].text).toString('base64'))).default;
const tokens = JSON.parse(fs.readFileSync(path.join(ROOT, 'system/tokens.json'), 'utf8'));
const plan = JSON.parse(fs.readFileSync(path.join(FILM, 'shots.json'), 'utf8'));

// Pretendard advances (em) at the default instance, rounded up a little for weight 700–900.
const ADV = { ' ': 0.26, '.': 0.27, ',': 0.27, '·': 0.27, '1': 0.46, '(': 0.36, ')': 0.36, '/': 0.35, '|': 0.3, ':': 0.27, '²': 0.42, '%': 0.9, '㎡': 1.24, 'm': 0.88, 'M': 0.9, 'W': 0.96, 'w': 0.8 };
function adv(ch) {
  if (ch in ADV) return ADV[ch];
  const c = ch.codePointAt(0);
  if (c >= 0xac00 && c <= 0xd7a3) return 0.9;              // Hangul syllables (0.864 at 400)
  if (c >= 0x300 && c <= 0x36f) return 0;                   // combining marks (the hat)
  if (/[0-9]/.test(ch)) return 0.64;
  if (/[a-z]/.test(ch)) return 0.58;
  if (/[A-Z]/.test(ch)) return 0.7;
  if ('−+=×÷±≤√'.includes(ch)) return 0.66;
  if ('₀₁₂ᵗ⁻⁰¹²³⁴⁵⁶⁷⁸⁹'.includes(ch)) return 0.42;
  if ('αβεΔ'.includes(ch)) return 0.66;
  return 1.0;                                               // arrows and anything else: wide on purpose
}
function mockCtx() {
  const st = { font: '10px Pretendard', letterSpacing: '0px', globalAlpha: 1 };
  const measureText = str => {
    const size = Number((/(\d+(?:\.\d+)?)px/.exec(st.font) || [0, 10])[1]);
    const ls = parseFloat(st.letterSpacing) || 0;
    const chars = [...str];
    return { width: chars.reduce((a, ch) => a + adv(ch) * size, 0) + ls * chars.length, actualBoundingBoxLeft: 0, actualBoundingBoxRight: size, actualBoundingBoxAscent: size * 0.8, actualBoundingBoxDescent: size * 0.2 };
  };
  return new Proxy(st, {
    get: (o, k) => (k === 'measureText' ? measureText : k in o ? o[k] : () => {}),
    set: (o, k, v) => { o[k] = v; return true; },
  });
}

const fails = [], report = { formats: {} }, texts = new Set();
const fps = tokens.format.fps;
const planSeconds = plan.durationBeats * plan.music.beatSeconds;
for (const fmtKey of film.formats) {
  const fmt = tokens.format[fmtKey], W = fmt.w, H = fmt.h, portrait = fmt.orientation === 'portrait';
  const zones = tokens.layout[portrait ? 'portrait' : 'landscape'];
  let acc = 0;
  const scenes = film.scenes.map(sc => { const durF = Math.round(sc.dur * fps); const o = { ...sc, startF: acc, durF, start: acc / fps }; acc += durF; return o; });
  if (Math.abs(acc / fps - planSeconds) > 1.01 / fps) fails.push(`${fmtKey}: film ${acc / fps}s ≠ plan ${planSeconds}s`);
  const startOf = id => scenes.find(x => x.id === id).start;
  const g = mockCtx();
  const sx = fmt.safe.x * W, sy = fmt.safe.y * H;
  const out = { frames: acc, outside: [], violations: [], errors: [], overlaps: [] };
  // reading moments: 35 / 70 / 97 % of every shot (stills-gate positions), checked for overlapping settled copy
  const moments = new Set(plan.shots.flatMap(sh => [0.35, 0.7, 0.97].map(k => Math.round((sh.startBeat + sh.beats * k) * plan.music.beatSeconds * fps))));
  for (let f = 0; f < acc; f++) {
    if (f % every && !moments.has(f)) continue;
    let i = scenes.length - 1;
    while (i > 0 && f < scenes[i].startF) i--;
    const sc = scenes[i], t = (f - sc.startF) / fps, T = f / fps;
    const receipts = [];
    const s = {
      g, W, H, fps, fmt, formatKey: fmtKey, portrait, tok: tokens, film, scene: sc, t, T, f, dur: sc.dur, c: tokens.color.recipe[sc.recipe], img: {}, at: startOf,
      zone: n => { const z = zones[n]; return { x: z.x * W, y: z.y * H, w: z.w * W, h: z.h * H }; },
      exit: (d = tokens.motion.hold.sceneTail) => (sc.holdLast ? 0 : Math.min(1, Math.max(0, (t - (sc.dur - d)) / d))),
      receipt: r => receipts.push({ scene: sc.id, ...r }),
    };
    try {
      sc.draw(s);
      if (film.overlay) film.overlay(s);
    } catch (e) {
      out.errors.push({ f, scene: sc.id, error: String(e.stack || e).split('\n').slice(0, 3).join(' | ') });
      if (out.errors.length > 20) break;
      continue;
    }
    for (const r of receipts) {
      if (r.kind === 'violation') out.violations.push({ f, ...r });
      if (r.kind !== 'text' && r.kind !== 'label') continue;
      texts.add(r.text);
      const box = { minX: r.x, minY: r.y, maxX: r.x + r.w, maxY: r.y + r.h };
      if (box.minX < sx - 1 || box.maxX > W - sx + 1 || box.minY < sy - 1 || box.maxY > H - sy + 1) out.outside.push({ f, scene: sc.id, text: r.text, ...box });
    }
    if (moments.has(f)) {
      const lab = receipts.filter(r => (r.kind === 'label' || r.kind === 'text') && r.w > 0);
      for (let a = 0; a < lab.length; a++) for (let b = a + 1; b < lab.length; b++) {
        const A = lab[a], B = lab[b];
        const ix = Math.min(A.x + A.w, B.x + B.w) - Math.max(A.x, B.x), iy = Math.min(A.y + A.h, B.y + B.h) - Math.max(A.y, B.y);
        if (ix > 2 && iy > 2 && ix * iy > 0.12 * Math.min(A.w * A.h, B.w * B.h)) out.overlaps.push({ f, scene: sc.id, a: A.text, b: B.text });
      }
    }
  }
  const dedupe = list => [...new Map(list.map(o => [`${o.scene}|${o.text || o.a}|${o.b || ''}|${o.rule || ''}`, o])).values()];
  out.outside = dedupe(out.outside); out.overlaps = dedupe(out.overlaps); out.violations = dedupe(out.violations);
  if (out.errors.length) fails.push(`${fmtKey}: ${out.errors.length} draw errors, first: ${out.errors[0].error}`);
  if (out.violations.length) fails.push(`${fmtKey}: layout violations ${JSON.stringify(out.violations.slice(0, 3))}`);
  if (out.outside.length) fails.push(`${fmtKey}: copy outside safe area ${JSON.stringify(out.outside.slice(0, 4))}`);
  if (out.overlaps.length) fails.push(`${fmtKey}: overlapping copy at reading moments ${JSON.stringify(out.overlaps.slice(0, 4))}`);
  report.formats[fmtKey] = out;
}
// verify.py's copy rule: every eojeol of every script line is inside some drawn text
const norm = x => x.replace(/\*/g, '').replace(/\s+/g, '');
const corpus = [...texts].map(norm);
const missing = film.script.map(line => ({ line, lost: line.split(/\s+/).filter(w => !corpus.some(c => c.includes(norm(w)))) })).filter(m => m.lost.length);
if (missing.length) fails.push(`script lines not on screen: ${JSON.stringify(missing.slice(0, 4))}`);
// audio cues point at the planned recordings
const cues = film.cues({});
const voiceFiles = cues.map(c => c.src);
const missingAudio = voiceFiles.filter(p => !fs.existsSync(path.join(ROOT, p)));
report.voice = { cues: cues.length, planned: Object.keys(plan.voice).length, notRecordedYet: missingAudio };
if (cues.length !== Object.keys(plan.voice).length) fails.push('voice cue count differs from plan.voice');
report.fails = fails;
fs.mkdirSync(path.join(FILM, 'qa'), { recursive: true });
fs.writeFileSync(path.join(FILM, 'qa', 'smoke-texts.json'), JSON.stringify([...texts].sort(), null, 1) + '\n');
fs.writeFileSync(path.join(FILM, 'qa', 'smoke-report.json'), JSON.stringify(report, null, 1) + '\n');
for (const [k, o] of Object.entries(report.formats)) console.log(`${k}: frames ${o.frames}, errors ${o.errors.length}, violations ${o.violations.length}, outside ${o.outside.length}, overlaps ${o.overlaps.length}`);
console.log(`texts ${texts.size}, script lines ${film.script.length} (missing ${missing.length}), voice cues ${cues.length} (recordings missing: ${missingAudio.length} — expected before recording)`);
console.log(fails.length ? 'SMOKE FAIL\n- ' + fails.join('\n- ') : 'SMOKE PASS');
process.exit(fails.length ? 1 : 0);
