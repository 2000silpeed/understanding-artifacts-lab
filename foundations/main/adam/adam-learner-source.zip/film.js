// Adam — 기울기의 평균과 제곱 평균으로 학습 보폭 조절하기. A Korean AI-basics lecture in three parts: the core idea in
// three lines → where it is used (house prices from two inputs in different units: SGD vs Adam) → the lecture (m, v,
// bias correction, step size, defaults) → recap.
// Script first: the narration (voice/script.json) is the timeline; every element below appears on the word that names
// it (word times in shots.json `voice`, estimated until the recordings are measured — see plan.py). Every number on
// screen is read from example/results/film_numbers.json, written by example/run_examples.py from real runs of
// example/adam.py (and checked against example/adam.cpp). The data is an example, so the numbers carry "예시 값".
// No scene fades out at its tail (holdLast on every scene): the next scene's cut frame is the biggest change.
import tokens from '../../system/tokens.json';
import { tween, lerp, clamp01 } from '../../engine/ease.js';
import { rgba } from '../../engine/color.js';
import { label, measure, tabular } from '../../engine/text.js';
import { headline, kicker, exampleTag } from '../../system/components/type.js';
import { rule } from '../../system/components/diagram.js';
import { shotPlan } from '../../engine/shots.js';
import plan from './shots.json';
import N from './example/results/film_numbers.json';

const P = shotPlan(plan);
const SC = tokens.type.scale;
const RAD = tokens.layout.radius;
const ST = tokens.layout.stroke;
const FPS = tokens.format.fps;
const DUR = k => tokens.motion.durationF[k] / FPS; // duration token → seconds
const EASE = tokens.motion.ease;
const ID = 'adam-20261108';
const SERIES = 'AI 기본기 · Adam';
/** Scene-relative time (s) of a spoken cue: the recording's lead-in plus the word's time inside the recording. */
const V = (scene, cue) => {
  const v = plan.voice[scene];
  if (!v || !(cue in v.cues)) throw Error(`No voice cue ${scene}.${cue} in shots.json (voice/script.json markers)`);
  return v.lead + v.cues[cue];
};

// ---------- numbers (all from the example run) ----------
const MINUS = '−';
const sign = v => (v < 0 ? MINUS : '');
const group = str => str.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const f = (v, d = 2) => { const a = Math.abs(v).toFixed(d), [i, frac] = a.split('.'); return (Number(a) === 0 ? '' : sign(v)) + group(i) + (frac ? '.' + frac : ''); };
const fi = v => f(Math.round(v), 0);
const short = v => String(v); // 0.0045, 0.9, 0.999 as written
const pow10 = v => { const e = Math.round(Math.log10(v)); return '10' + (e < 0 ? '⁻' : '') + String(Math.abs(e)).split('').map(d => '⁰¹²³⁴⁵⁶⁷⁸⁹'[d]).join(''); };
const ANS = N.data.answer;
const G0 = N.init.g;
const RATIO = fi(N.init.ratio);
const STEPS = N.steps;
const A = N.adam;
const SGD = N.sgd;

// ---------- copy (verbatim; `script` below lists what QA must find on screen) ----------
const TXT = {
  openKicker: 'AI 기본기 · 옵티마이저',
  sub1: '기울기의 평균과 제곱 평균으로',
  sub2: '학습 보폭 조절하기',
  feet: '점 하나 = Adam의 한 걸음 (거리 가중치, 예시 데이터)',
  sumHead: '기울기의 *평균*과 *제곱 평균*으로 보폭을 정합니다',
  cards: [
    { sym: 'm', title: '기울기의 평균', what: '→ 방향' },
    { sym: 'v', title: '기울기 제곱의 평균', what: '→ 크기' },
    { sym: 'α·m̂ ÷ √v̂', title: '한 걸음의 크기', what: '→ 파라미터마다 따로' },
  ],
  note1: '기울기가 크든 작든 → 비슷한 보폭으로 출발',
  note2: '방향이 오락가락하면 → 보폭이 줄어든다',
  caseHead: ['*면적*과 *역까지 거리*로 집값을 예측합니다', `첫 기울기가 *${RATIO}배* 다릅니다`],
  cols: ['면적(㎡)', '역까지(km)', '가격(백만원)'],
  devArea: `면적 차이 ±${fi(N.data.devArea)}㎡`,
  devStation: `거리 차이 ±${fi(N.data.devStation)}km`,
  gTitle: '첫 걸음의 기울기',
  gRows: ['면적 쪽', '거리 쪽'],
  ratio: `${RATIO}배 차이`,
  sgdHead: ['경사하강법: 모든 파라미터에 *같은 학습률*', '작게 잡으면 거리 쪽이 *느립니다*'],
  lrHigh: `학습률 ${short(SGD.diverge.lr)}`,
  zigTitle: '면적 가중치',
  diverge: '발산',
  limit: `안정 한계: 학습률 < ${short(SGD.limit)}`,
  lrLow: `학습률 ${short(SGD.safe.lr)} · ${STEPS}걸음`,
  chartTitle: '거리 가중치',
  target: `정답 ${f(ANS[1], 0)}`,
  stepAxis: '걸음',
  bars: ['면적', '거리'],
  far: '정답까지 한참',
  adamHead: [`같은 문제, *Adam*으로 ${STEPS}걸음`, `${STEPS}걸음 뒤 손실: 경사하강법 *${f(SGD.safe.loss100)}*, Adam *${f(A.loss100)}*`],
  adamChip: `Adam · 학습률 ${short(A.lr)} · ${STEPS}걸음`,
  legendSgd: '경사하강법',
  legendAdam: 'Adam',
  resCols: ['', '면적 w', '거리 w', '손실'],
  resRows: ['정답', '경사하강법', 'Adam'],
  bridge1: '어떻게?',
  bridge2: '→ 본 강의: m · v · 편향 보정 · 보폭',
  l1Head: ['*m*: 기울기의 평균', '부호가 바뀌면 *m*은 0 근처로'],
  l1Kick: 'm · 기울기의 평균',
  l1Notes: [`지난 m의 ${fi(A.beta1 * 100)}%`, `새 기울기의 ${fi((1 - A.beta1) * 100)}%`],
  l1Beta: `β₁ = ${short(A.beta1)}`,
  l1Chart: '면적 가중치 · 1–12걸음',
  legendG: '막대 = 기울기 g',
  legendM: '선 = m',
  flip: `${A.firstAreaSignFlip}번째: 부호가 바뀜`,
  l2Head: ['*v*: 기울기 제곱의 평균', '제곱하면 *부호*가 사라집니다'],
  l2Kick: 'v · 기울기 제곱의 평균',
  l2Notes: [`지난 v의 ${f(A.beta2 * 100, 1)}%`, `새 기울기²의 ${f((1 - A.beta2) * 100, 1)}%`],
  l2Beta: `β₂ = ${short(A.beta2)} → 훨씬 오래 기억`,
  legendAbs: '막대 = |g|',
  legendV: '선 = √v̂',
  stationV: '거리 쪽 √v̂',
  stationVal: `${f(A.stationFirst12.sqrtVHat[0])} → ${f(A.stationFirst12.sqrtVHat[11])}`,
  l2Sum: ['v는 방향이 아니라', '크기를 기억합니다'],
  l3Head: ['*편향 보정*: 0에서 출발한 평균을 원래 크기로'],
  l3Kick: '편향 보정',
  zero: 'm₀ = 0, v₀ = 0 에서 출발',
  nobc: `보정 없이: 첫 걸음 ${f(N.noBiasCorrection.step1Abs[0])}`,
  bc: `보정하면: 첫 걸음 ${f(A.t1.stepAbs[0])}`,
  l4Head: ['*보폭*: 평균 방향을 크기로 나눕니다', '방향이 흔들리면 *보폭이 줄어듭니다*'],
  l4Kick: '보폭',
  calc: [
    `면적   ${short(A.lr)} × (${f(A.t1.mHat[0], 0)}) ÷ ${f(A.t1.sqrtVHat[0], 0)} = ${f(-A.t1.w[0], 0)}   →   w: 0 → ${f(A.t1.w[0], 0)}`,
    `거리   ${short(A.lr)} × ${f(A.t1.mHat[1], 0)} ÷ ${f(A.t1.sqrtVHat[1], 0)} = ${f(-A.t1.w[1], 0)}   →   w: 0 → ${f(A.t1.w[1], 0)}`,
  ],
  one: `보폭 크기: 둘 다 ${f(A.t1.stepAbs[0], 0)}  ·  기울기는 ${RATIO}배 차이`,
  stepChart: '걸음마다의 보폭 |Δw|',
  t20: n => `${A.t20.t}번째 ${n}`,
  defHead: ['실제로 쓸 때의 *기본값*', '학습률은 여전히 *직접 정합니다*'],
  chips: [
    { sym: 'α', name: '학습률', val: short(N.defaults.lr) },
    { sym: 'β₁', name: 'm을 기억하는 비율', val: short(N.defaults.beta1) },
    { sym: 'β₂', name: 'v를 기억하는 비율', val: short(N.defaults.beta2) },
    { sym: 'ε', name: '0으로 나누기 방지', val: pow10(N.defaults.eps) },
  ],
  ours: `이 예제: α = ${short(A.lr)} (가중치가 수십 단위)`,
  bound: `이 예제의 가장 큰 보폭 = ${f(A.maxStepAbs)} ≤ α`,
  recapHead: ['*평균*은 방향, *제곱 평균*은 크기'],
  recap: [
    { sym: 'm', text: '기울기의 평균 → 방향' },
    { sym: 'v', text: '기울기 제곱의 평균 → 크기' },
    { sym: 'α·m̂ ÷ √v̂', text: '→ 파라미터마다 맞춘 보폭' },
  ],
  practice: '예제 example/adam.py · adam.cpp   실습 practice/adam_practice.py',
  endSub: '기울기의 평균과 제곱 평균으로 학습 보폭 조절하기',
  endSubLines: ['기울기의 평균과 제곱 평균으로', '학습 보폭 조절하기'],
};
const plainHead = h => h.replace(/\*/g, '');

// ---------- helpers ----------
const fill = (s, color) => { s.g.fillStyle = color; s.g.fillRect(0, 0, s.W, s.H); };
const up = (t, at, d = DUR('slow')) => tween(t, at, d, EASE.enter);
/** Copy that rises into a clip at a FIXED font size (a per-frame font px breaks seek determinism). */
function rise(s, str, x, y, p, { size = SC.h3, role = 'display', weight, align = 'left', color, alpha = 1, tracking = 0 } = {}) {
  if (p <= 0) return null;
  const g = s.g, w = measure(g, str, role, size, weight, tracking), left = align === 'center' ? x - w / 2 : align === 'right' ? x - w : x;
  g.save(); g.beginPath(); g.rect(left - size * 0.3, y - size * 1.1, w + size * 0.6, size * 1.5); g.clip();
  g.translate(0, (1 - p) * size * 0.9);
  const box = label(s, str, x, y, { role, size, weight, color: color ?? s.c.ink, align, alpha, tracking });
  g.restore();
  return box;
}
/** Shape and words move as one: everything drawn in fn shares the same offset. */
function lift(s, p, dist, fn) {
  if (p <= 0) return;
  s.g.save(); s.g.translate(0, (1 - p) * dist); fn(); s.g.restore();
}
function panel(s, r, { fillA = 0.07, strokeA = 0.28, color, radius = RAD.panel, lw = ST.hair } = {}) {
  const g = s.g, c = color ?? s.c.ink;
  g.save(); g.beginPath(); g.roundRect(r.x, r.y, r.w, r.h, radius);
  g.fillStyle = rgba(c, fillA); g.fill();
  if (strokeA > 0) { g.strokeStyle = rgba(c, strokeA); g.lineWidth = lw; g.stroke(); }
  g.restore();
}
/** Section tag where a numbered kicker does not apply (same place and size as kicker). */
function tag(s, text) {
  const z = s.zone('headline'), y = z.y - SC.label * 1.1, g = s.g;
  g.save(); g.fillStyle = s.c.accent; g.fillRect(z.x, y - SC.label * 0.42, SC.label * 1.6, ST.line); g.restore();
  label(s, text, z.x + SC.label * 2.2, y, { size: SC.label, color: s.c.muted, weight: 600 });
}
/** A run of text in coloured parts; returns each part's [x0, x1]. */
function parts(s, list, x, y, { size, role = 'display', weight = 800, align = 'left', alpha = 1 }) {
  const ws = list.map(([t]) => measure(s.g, t, role, size, weight, 0)), total = ws.reduce((a, b) => a + b, 0);
  let cx = align === 'center' ? x - total / 2 : x;
  return list.map(([t, color], i) => { label(s, t, cx, y, { role, size, weight, color, alpha, tracking: 0 }); const span = [cx, cx + ws[i]]; cx += ws[i]; return span; });
}
function dashed(s, x0, y0, x1, y1, { color, width = ST.hair, alpha = 1 } = {}) {
  const g = s.g;
  g.save(); g.globalAlpha = alpha; g.setLineDash([10, 10]); g.strokeStyle = color ?? s.c.muted; g.lineWidth = width;
  g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke(); g.restore();
}
/** Polyline through pts, drawn to progress p (0..1) along its points. Returns the head point. */
function poly(s, pts, p, { color, width = ST.line, alpha = 1, dots = 0 } = {}) {
  if (p <= 0 || pts.length < 2) return pts[0];
  const g = s.g, n = pts.length - 1, upto = p * n, k = Math.floor(upto), fr = upto - k;
  const head = k >= n ? pts[n] : { x: lerp(pts[k].x, pts[k + 1].x, fr), y: lerp(pts[k].y, pts[k + 1].y, fr) };
  g.save(); g.globalAlpha = alpha; g.strokeStyle = color; g.lineWidth = width; g.lineJoin = 'round'; g.lineCap = 'round';
  g.beginPath(); g.moveTo(pts[0].x, pts[0].y);
  for (let i = 1; i <= Math.min(k, n); i++) g.lineTo(pts[i].x, pts[i].y);
  if (k < n) g.lineTo(head.x, head.y);
  g.stroke();
  if (dots) { g.fillStyle = color; for (let i = 0; i <= Math.min(k, n); i++) { g.beginPath(); g.arc(pts[i].x, pts[i].y, dots, 0, Math.PI * 2); g.fill(); } }
  g.restore();
  return head;
}
const scaler = (r, x0, x1, y0, y1) => ({ X: v => r.x + ((v - x0) / (x1 - x0)) * r.w, Y: v => r.y + r.h - ((v - y0) / (y1 - y0)) * r.h });
/** Axis frame: baseline + y ticks (value, text) + x ticks; micro labels in muted. */
function axes(s, r, M, { yTicks = [], xTicks = [], xLabel, alpha = 1 }) {
  const g = s.g;
  g.save(); g.globalAlpha = alpha; g.strokeStyle = rgba(s.c.muted, 0.5); g.lineWidth = ST.hair;
  g.beginPath(); g.moveTo(r.x, r.y); g.lineTo(r.x, r.y + r.h); g.lineTo(r.x + r.w, r.y + r.h); g.stroke(); g.restore();
  yTicks.forEach(([v, text]) => label(s, text, r.x - 12, M.Y(v) + SC.micro * 0.35, { size: SC.micro, color: s.c.muted, align: 'right', alpha, weight: 600, tracking: 0 }));
  xTicks.forEach(([v, text]) => label(s, text, M.X(v), r.y + r.h + SC.micro * 1.5, { size: SC.micro, color: s.c.muted, align: 'center', alpha, weight: 600, tracking: 0 }));
  // the axis name sits right of the last tick, so every chart keeps CHART_RIGHT px free inside the safe area
  if (xLabel) label(s, xLabel, r.x + r.w + 22, r.y + r.h + SC.micro * 1.5, { size: SC.micro, color: s.c.muted, alpha, weight: 700, tracking: 0 });
}
const CHART_LEFT = 100, CHART_RIGHT = 80; // room for y tick labels / the x axis name
function legend(s, x, y, items, { alpha = 1 } = {}) { // items: [text, color, 'bar' | 'line']; right-aligned at x
  const g = s.g;
  let cx = x;
  [...items].reverse().forEach(([text, color, kind]) => {
    const w = measure(g, text, 'text', SC.caption, 600, 0);
    label(s, text, cx, y, { size: SC.caption, color: s.c.ink, align: 'right', alpha, weight: 600, tracking: 0 });
    cx -= w + 14;
    g.save(); g.globalAlpha = alpha; g.fillStyle = color;
    if (kind === 'line') g.fillRect(cx - 34, y - SC.caption * 0.4, 34, ST.bold); else g.fillRect(cx - 22, y - SC.caption * 0.75, 22, 22);
    g.restore();
    cx -= 34 + 34;
  });
}
const TOTAL = ['open', 'summary', 'case', 'sgd', 'adamcase', 'lec1', 'lec2', 'lec3', 'lec4', 'defaults', 'recap', 'end'].reduce((a, id) => a + P.dur(id), 0);
/** Series title + progress rail, same place on every lecture frame. */
function foot(s) {
  const z = s.zone('footer'), g = s.g, y = z.y + z.h * 0.5;
  label(s, SERIES, z.x, y + SC.micro * 0.35, { size: SC.micro, color: s.c.muted, weight: 600, alpha: 0.9 });
  const railX = z.x + z.w * (s.portrait ? 0.55 : 0.7), railW = z.x + z.w - railX;
  g.save(); g.fillStyle = rgba(s.c.muted, 0.35); g.fillRect(railX, y - 1, railW, 2);
  g.fillStyle = s.c.accent; g.fillRect(railX, y - 1, railW * clamp01(s.T / TOTAL), 2); g.restore();
}
/** Motif M1: Adam's 100 steps on the distance weight (0 → −50) as dots; spacing is that step's size. */
function footprints(s, x0, x1, y, n, { alpha = 1 } = {}) {
  const g = s.g, path = [0, ...A.stationPath], X = w => x0 + (w / ANS[1]) * (x1 - x0);
  g.save(); g.globalAlpha = alpha;
  g.strokeStyle = rgba(s.c.muted, 0.45); g.lineWidth = ST.hair; g.beginPath(); g.moveTo(x0, y); g.lineTo(X(ANS[1]), y); g.stroke();
  g.fillStyle = s.c.ink; g.fillRect(X(ANS[1]) - 1.5, y - 16, 3, 32);
  g.fillStyle = s.c.accent;
  for (let k = 0; k < Math.min(n, path.length); k++) { g.beginPath(); g.arc(X(path[k]), y, k === 0 ? 7 : 5, 0, Math.PI * 2); g.fill(); }
  g.restore();
}

// ---------- scenes ----------
const open = {
  id: 'open', dur: P.dur('open'), recipe: 'cerulean', holdLast: true,
  draw: s => {
    const { W, H, t } = s, port = s.portrait, big = port ? 264 : 280; // fixed px over 256 (glyph-atlas rule)
    fill(s, s.c.ground);
    const y = H * (port ? 0.42 : 0.44);
    rise(s, TXT.openKicker, W / 2, y - big * 1.1, up(t, 0), { size: SC.label, role: 'text', weight: 700, color: s.c.muted, align: 'center' });
    rise(s, 'Adam', W / 2, y, up(t, 0), { size: big, role: 'hero', color: s.c.ink, align: 'center' }); // on the first frame; the voice says it at V('open', 'title')
    const subSize = port ? SC.h3 : SC.h2;
    rise(s, TXT.sub1, W / 2, y + subSize * 2.0, up(t, V('open', 'sub')), { size: subSize, color: s.c.ink, align: 'center' });
    rise(s, TXT.sub2, W / 2, y + subSize * 3.3, up(t, V('open', 'sub') + 0.25), { size: subSize, color: s.c.accent, align: 'center' });
    const fy = H * (port ? 0.76 : 0.82), n = Math.floor(clamp01((t - 0.6) / Math.max(1, s.dur - 2.4)) * (STEPS + 1));
    footprints(s, W * (port ? 0.12 : 0.15), W * (port ? 0.88 : 0.85), fy, n);
    label(s, TXT.feet, W / 2, fy + SC.micro * 2.4, { size: SC.micro, color: s.c.muted, align: 'center', weight: 600, alpha: up(t, 0.6, 0.5) });
  },
};

const summary = {
  id: 'summary', dur: P.dur('summary'), recipe: 'cerulean', holdLast: true,
  draw: s => {
    const { t } = s, Z = s.zone('stage'), port = s.portrait;
    tag(s, '핵심 요약');
    headline(s, [{ text: TXT.sumHead, at: 0 }]);
    const cueAt = ['c1', 'c2', 'c3'].map(c => V('summary', c));
    TXT.cards.forEach((c, i) => {
      const r = port ? { x: Z.x, y: Z.y + i * 212, w: Z.w, h: 190 } : { x: Z.x + i * ((Z.w - 80) / 3 + 40), y: Z.y, w: (Z.w - 80) / 3, h: 300 };
      lift(s, up(t, cueAt[i], 0.5), 60, () => {
        panel(s, r);
        const symSize = i === 2 ? (port ? SC.h3 : SC.h2) : SC.h1;
        if (!port) {
          label(s, c.sym, r.x + 36, r.y + 112, { role: 'display', size: symSize, weight: 800, color: i === 2 ? s.c.ink : s.c.accent, tracking: 0 });
          label(s, c.title, r.x + 36, r.y + 196, { role: 'display', size: SC.h3, weight: 800, color: s.c.ink, tracking: 0 });
          label(s, c.what, r.x + 36, r.y + 254, { role: 'display', size: SC.body, weight: 700, color: s.c.accent, tracking: 0 });
        } else {
          label(s, c.sym, r.x + 32, r.y + (i === 2 ? 110 : 128), { role: 'display', size: symSize, weight: 800, color: i === 2 ? s.c.ink : s.c.accent, tracking: 0 });
          label(s, c.title, r.x + 290, r.y + 84, { role: 'display', size: SC.h3, weight: 800, color: s.c.ink, tracking: 0 });
          label(s, c.what, r.x + 290, r.y + 146, { role: 'display', size: SC.body, weight: 700, color: s.c.accent, tracking: 0 });
        }
      });
    });
    const ny = port ? Z.y + 3 * 212 + 70 : Z.y + 300 + 84;
    rise(s, TXT.note1, Z.x, ny, up(t, V('summary', 'note1'), 0.5), { size: SC.body, weight: 700, color: s.c.ink });
    rise(s, TXT.note2, Z.x, ny + SC.body * 1.9, up(t, V('summary', 'note2'), 0.5), { size: SC.body, weight: 700, color: s.c.ink });
  },
};

function caseGeo(s) {
  const Z = s.zone('stage'), port = s.portrait;
  const rowH = port ? 44 : 50;
  const table = port ? { x: Z.x, y: Z.y, w: Z.w, h: rowH * 9 } : { x: Z.x, y: Z.y, w: Z.w * 0.42, h: rowH * 9 };
  const right = port ? { x: Z.x, y: Z.y + rowH * 9 + 80, w: Z.w, h: Z.h - rowH * 9 - 80 } : { x: Z.x + Z.w * 0.5, y: Z.y, w: Z.w * 0.5, h: Z.h };
  return { Z, rowH, table, right };
}
const caseScene = {
  id: 'case', dur: P.dur('case'), recipe: 'paper', holdLast: true,
  draw: s => {
    const { t, g } = s, port = s.portrait, { rowH, table: T, right: R } = caseGeo(s);
    tag(s, '사용 상황');
    headline(s, [{ text: TXT.caseHead[0], at: 0 }, { text: TXT.caseHead[1], at: V('case', 'gA') }]);
    // the example data, on the cut frame
    lift(s, up(t, 0, 0.6), 40, () => {
      const cx = k => T.x + (T.w * (2 * k + 1)) / 6;
      [['area', 0], ['station', 1]].forEach(([cue, k]) => {
        const a = up(t, V('case', cue), 0.3);
        if (a > 0) { g.save(); g.globalAlpha = a; g.fillStyle = rgba(s.c.accent, 0.12); g.fillRect(T.x + (T.w * k) / 3 + 4, T.y, T.w / 3 - 8, T.h); g.restore(); }
      });
      TXT.cols.forEach((c, k) => label(s, c, cx(k), T.y + rowH * 0.66, { size: SC.label, color: s.c.muted, align: 'center', weight: 700, tracking: 0 }));
      g.save(); g.fillStyle = rgba(s.c.ink, 0.3); g.fillRect(T.x, T.y + rowH - 1, T.w, 2); g.restore();
      N.data.rows.forEach((row, i) => {
        const y = T.y + rowH * (i + 1) + rowH * 0.66;
        [fi(row[0]), f(row[1], 1), fi(row[2])].forEach((v, k) => label(s, v, cx(k), y, { size: SC.caption, color: s.c.ink, align: 'center', weight: 600, tracking: 0 }));
      });
      const tw = exampleTag(s, T.x, T.y + T.h + 14, 1);
      const dy = T.y + T.h + 14 + SC.micro + 12;
      rise(s, TXT.devArea, T.x + tw + 24, dy, up(t, V('case', 'area'), 0.5), { size: SC.caption, weight: 700, color: s.c.accent });
      const daw = measure(g, TXT.devArea, 'display', SC.caption, 700, 0);
      rise(s, TXT.devStation, T.x + tw + 24 + daw + 28, dy, up(t, V('case', 'station'), 0.5), { size: SC.caption, weight: 700, color: s.c.accent });
    });
    // first gradients: two bars from one baseline (compare)
    const L = Math.min(R.w - 260 - 190, 560), bx = R.x + 230;
    label(s, TXT.gTitle, R.x, R.y + (port ? 30 : 34), { size: SC.caption, color: s.c.muted, weight: 700, alpha: up(t, V('case', 'gA'), 0.3) });
    G0.forEach((gv, k) => {
      const at = V('case', k ? 'gS' : 'gA'), p = up(t, at, 0.7), y = R.y + (port ? 70 : 90) + k * (port ? 96 : 110);
      lift(s, up(t, at, 0.4), 30, () => {
        label(s, TXT.gRows[k], R.x, y + 42, { role: 'display', size: SC.h3, weight: 800, color: s.c.ink, tracking: 0 });
        const len = Math.max(4, (L * Math.abs(gv) * p) / Math.abs(G0[0]));
        g.save(); g.fillStyle = k ? s.c.accent : s.c.ink; g.fillRect(bx, y, len, 56); g.restore();
        label(s, f(gv, 0), bx + len + 18, y + 42, { role: 'display', size: SC.h3, weight: 800, color: k ? s.c.accent : s.c.ink, tracking: 0 });
      });
    });
    const ry = R.y + (port ? 70 : 90) + 2 * (port ? 96 : 110) + (port ? 90 : 110);
    rise(s, TXT.ratio, bx, ry, up(t, V('case', 'ratio'), 0.5), { size: SC.h1, weight: 800, color: s.c.accent });
  },
};

/** Motif M2: distance weight vs step, the same axes for SGD and Adam. */
function distGeo(s) {
  const Z = s.zone('stage'), port = s.portrait;
  const chart = port ? { x: Z.x + CHART_LEFT, y: Z.y + 70, w: Z.w - CHART_LEFT - CHART_RIGHT, h: 460 } : { x: Z.x + CHART_LEFT, y: Z.y + 70, w: Z.w * 0.58 - CHART_LEFT, h: Z.h - 150 };
  const side = port ? { x: Z.x, y: chart.y + chart.h + 90, w: Z.w } : { x: Z.x + Z.w * 0.64, y: Z.y + 70, w: Z.w * 0.36 };
  return { Z, chart, side, M: scaler(chart, 0, STEPS, ANS[1] * 1.2, -ANS[1] * 0.1) };
}
function distChart(s, { sgdP = 0, adamP = 0, sgdAlpha = 1, ends = {} }) {
  const { chart: r, M } = distGeo(s);
  axes(s, r, M, { yTicks: [[0, '0'], [ANS[1] / 2, f(ANS[1] / 2, 0)], [ANS[1], f(ANS[1], 0)]], xTicks: [[0, '0'], [STEPS / 2, String(STEPS / 2)], [STEPS, String(STEPS)]], xLabel: TXT.stepAxis });
  dashed(s, r.x, M.Y(ANS[1]), r.x + r.w, M.Y(ANS[1]), { color: s.c.ink, alpha: 0.6 });
  label(s, TXT.target, r.x + r.w, M.Y(ANS[1]) - 12, { size: SC.caption, color: s.c.ink, align: 'right', weight: 700, tracking: 0 });
  label(s, TXT.chartTitle, r.x + 8, r.y - 18, { size: SC.caption, color: s.c.muted, weight: 700, tracking: 0 });
  const pts = path => [0, ...path].map((v, i) => ({ x: M.X(i), y: M.Y(v) }));
  const hs = poly(s, pts(SGD.safe.stationPath), sgdP, { color: s.c.ink, width: ST.line, alpha: sgdAlpha });
  const ha = poly(s, pts(A.stationPath), adamP, { color: s.c.accent, width: ST.bold });
  if (ends.sgd > 0) label(s, f(SGD.safe.w100[1]), hs.x - 10, hs.y - 16, { role: 'display', size: SC.body, weight: 800, color: s.c.ink, align: 'right', alpha: ends.sgd * sgdAlpha, tracking: 0 });
  if (ends.adam > 0) label(s, f(A.w100[1]), ha.x - 10, ha.y + 44, { role: 'display', size: SC.body, weight: 800, color: s.c.accent, align: 'right', alpha: ends.adam, tracking: 0 });
  return { hs, ha };
}

const sgd = {
  id: 'sgd', dur: P.dur('sgd'), recipe: 'paper', holdLast: true,
  draw: s => {
    const { t, g, W } = s, port = s.portrait, Z = s.zone('stage'), tB = P.at('C04-02');
    tag(s, '사용 상황 · 경사하강법');
    headline(s, [{ text: TXT.sgdHead[0], at: 0 }, { text: TXT.sgdHead[1], at: V('sgd', 'station') }]);
    if (t < tB) { // learning rate above the limit: the large-gradient weight bounces and grows
      rise(s, TXT.lrHigh, Z.x, Z.y + 4, up(t, V('sgd', 'lrHigh'), 0.5), { size: SC.h3, weight: 800, color: s.c.accent });
      const r = port ? { x: Z.x + CHART_LEFT, y: Z.y + 120, w: Z.w - CHART_LEFT - CHART_RIGHT, h: 440 } : { x: W / 2 - 400, y: Z.y + 100, w: 800, h: 300 };
      const vals = [0, ...SGD.diverge.areaFirst], top = Math.ceil(Math.max(...vals.map(Math.abs)) / 5) * 5, M = scaler(r, 0, vals.length - 1, -top, top);
      const show = up(t, V('sgd', 'lrHigh'), 0.4);
      if (show > 0) {
        axes(s, r, M, { yTicks: [[top, f(top, 0)], [0, '0'], [-top, f(-top, 0)]], alpha: show });
        label(s, TXT.zigTitle, r.x + 8, r.y - 18, { size: SC.caption, color: s.c.muted, weight: 700, alpha: show, tracking: 0 });
        dashed(s, r.x, M.Y(ANS[0]), r.x + r.w, M.Y(ANS[0]), { color: s.c.ink, alpha: 0.5 * show });
        label(s, `정답 ${fi(ANS[0])}`, r.x + r.w, M.Y(ANS[0]) - 10, { size: SC.micro, color: s.c.ink, align: 'right', weight: 700, alpha: show, tracking: 0 });
      }
      const step = 0.33, b0 = V('sgd', 'bounce');
      const visible = t < b0 ? 1 : Math.min(vals.length, 2 + Math.floor((t - b0) / step));
      if (show > 0) {
        const pts = vals.slice(0, visible).map((v, i) => ({ x: M.X(i), y: M.Y(v) }));
        poly(s, pts, 1, { color: s.c.accent, width: ST.line, dots: 6, alpha: show });
        pts.forEach((p, i) => i && label(s, f(vals[i]), p.x, p.y + (vals[i] >= 0 ? -16 : 34), { size: SC.micro, color: s.c.ink, align: 'center', weight: 700, tracking: 0 }));
      }
      const dv = up(t, b0 + step * (vals.length - 2), 0.4);
      // 16:9: right of the chart; 9:16: inside its top-left corner, away from the late (large) points on the right
      rise(s, TXT.diverge, port ? r.x + 16 : r.x + r.w + 40, r.y + SC.h3 + 8, dv, { size: SC.h3, weight: 800, color: s.c.accent });
      rise(s, TXT.limit, port ? Z.x : W / 2, r.y + r.h + 76, up(t, V('sgd', 'limit'), 0.5), { size: SC.body, weight: 700, color: s.c.ink, align: port ? 'left' : 'center' });
      exampleTag(s, port ? Z.x : r.x, r.y + r.h + 100, show);
    } else { // below the limit: area converges, distance crawls
      const { side: R } = distGeo(s), lt = t - tB;
      label(s, TXT.lrLow, Z.x, Z.y + 4, { role: 'display', size: SC.h3, weight: 800, color: s.c.accent, tracking: 0 });
      const drawEnd = Math.max(1.2, V('sgd', 'station') - tB);
      distChart(s, { sgdP: tween(lt, 0, drawEnd, EASE.move), ends: { sgd: up(t, V('sgd', 'station'), 0.3) } });
      const rows = [
        { name: TXT.bars[0], frac: SGD.safe.w100[0] / ANS[0], val: `${f(SGD.safe.w100[0])} / ${fi(ANS[0])}`, at: V('sgd', 'area4') },
        { name: TXT.bars[1], frac: SGD.safe.w100[1] / ANS[1], val: `${f(SGD.safe.w100[1])} / ${fi(ANS[1])}`, at: V('sgd', 'station') },
      ];
      rows.forEach((row, k) => {
        const y = R.y + k * (port ? 100 : 130), w = R.w;
        lift(s, up(t, row.at, 0.4), 30, () => {
          label(s, row.name, R.x, y + 30, { role: 'display', size: SC.h3 * 0.8, weight: 800, color: s.c.ink, tracking: 0 });
          label(s, row.val, R.x + w, y + 30, { role: 'display', size: SC.body, weight: 800, color: k ? s.c.accent : s.c.ink, align: 'right', tracking: 0 });
          g.save(); g.fillStyle = rgba(s.c.muted, 0.2); g.fillRect(R.x, y + 46, w, 22);
          g.fillStyle = k ? s.c.accent : s.c.ink; g.fillRect(R.x, y + 46, w * clamp01(row.frac) * up(t, row.at, 0.8), 22); g.restore();
        });
      });
      rise(s, TXT.far, R.x, R.y + 2 * (port ? 100 : 130) + 40, up(t, V('sgd', 'target'), 0.5), { size: SC.body, weight: 800, color: s.c.accent });
      exampleTag(s, R.x, R.y + 2 * (port ? 100 : 130) + 70, 1);
    }
  },
};

const adamcase = {
  id: 'adamcase', dur: P.dur('adamcase'), recipe: 'paper', holdLast: true,
  draw: s => {
    const { t, g } = s, port = s.portrait, Z = s.zone('stage'), { side: R, chart } = distGeo(s);
    tag(s, '사용 상황 · Adam');
    headline(s, [{ text: TXT.adamHead[0], at: 0 }, { text: TXT.adamHead[1], at: V('adamcase', 'loss') }]);
    label(s, TXT.adamChip, Z.x, Z.y + 4, { role: 'display', size: SC.h3, weight: 800, color: s.c.accent, tracking: 0 });
    const run = V('adamcase', 'run'), drawEnd = Math.max(1.2, V('adamcase', 'station') - run);
    distChart(s, { sgdP: 1, sgdAlpha: 0.4, adamP: tween(t, run, drawEnd, EASE.move), ends: { sgd: 1, adam: up(t, V('adamcase', 'station'), 0.3) } });
    legend(s, chart.x + chart.w, chart.y + 30, [[TXT.legendSgd, rgba(s.c.ink, 0.4), 'line'], [TXT.legendAdam, s.c.accent, 'line']]);
    // results table: rows appear as they are spoken
    const cw = port ? [0.34, 0.2, 0.22, 0.24] : [0.34, 0.2, 0.22, 0.24], rowH = port ? 52 : 58;
    const colX = k => R.x + R.w * cw.slice(0, k).reduce((a, b) => a + b, 0) + (k ? (R.w * cw[k]) / 2 : 0);
    const cell = (text, k, i, { color = s.c.ink, weight = 700, alpha = 1 } = {}) =>
      label(s, text, colX(k), R.y + rowH * (i + 0.7), { role: 'display', size: SC.caption, weight, color, align: k ? 'center' : 'left', alpha, tracking: 0 });
    TXT.resCols.forEach((c, k) => c && cell(c, k, 0, { color: s.c.muted }));
    g.save(); g.fillStyle = rgba(s.c.ink, 0.3); g.fillRect(R.x, R.y + rowH - 1, R.w, 2); g.restore();
    cell(TXT.resRows[0], 0, 1); cell(fi(ANS[0]), 1, 1); cell(fi(ANS[1]), 2, 1);
    cell(TXT.resRows[1], 0, 2); cell(f(SGD.safe.w100[0]), 1, 2); cell(f(SGD.safe.w100[1]), 2, 2);
    const a1 = up(t, V('adamcase', 'area'), 0.3), a2 = up(t, V('adamcase', 'station'), 0.3);
    if (a1 > 0) { cell(TXT.resRows[2], 0, 3, { color: s.c.accent, weight: 800 }); cell(f(A.w100[0]), 1, 3, { color: s.c.accent, weight: 800 }); }
    if (a2 > 0) cell(f(A.w100[1]), 2, 3, { color: s.c.accent, weight: 800 });
    if (t >= P.at('C05-02')) cell(f(SGD.safe.loss100), 3, 2, { weight: 800 });
    if (t >= V('adamcase', 'lossAdam')) cell(f(A.loss100), 3, 3, { color: s.c.accent, weight: 800 });
    exampleTag(s, R.x, R.y + rowH * 4 + 10, 1);
    const by = R.y + rowH * 4 + (port ? 110 : 120);
    rise(s, TXT.bridge1, R.x, by, up(t, V('adamcase', 'bridge'), 0.5), { size: SC.h3, weight: 800, color: s.c.accent });
    rise(s, TXT.bridge2, R.x, by + SC.h3 * 1.3, up(t, V('adamcase', 'bridge') + 0.3, 0.5), { size: SC.caption, weight: 700, color: s.c.ink });
  },
};

/** Big centred formula with two annotations under named parts. */
function formulaCard(s, list, notes, at, { noteAt, chip, chipAt } = {}) {
  const { t, g, W } = s, port = s.portrait, Z = s.zone('stage');
  const size = port ? SC.h2 : SC.h1, y = Z.y + Z.h * (port ? 0.22 : 0.3);
  const p = up(t, at, 0.6);
  if (p <= 0) return;
  lift(s, p, 40, () => {
    const spans = parts(s, list, W / 2, y, { size, align: 'center' });
    notes.forEach(([idx, text, color], k) => {
      const a = up(t, noteAt[k], 0.4);
      if (a <= 0) return;
      const x0 = spans[idx[0]][0], x1 = spans[idx[1]][1];
      g.save(); g.globalAlpha = a; g.fillStyle = color; g.fillRect(x0, y + size * 0.32, x1 - x0, ST.line); g.restore();
      rise(s, text, (x0 + x1) / 2, y + size * 0.32 + SC.body * 1.6, a, { size: port ? SC.caption : SC.body, weight: 700, color, align: 'center' });
    });
  });
  if (chip) rise(s, chip, W / 2, Z.y + Z.h * (port ? 0.55 : 0.82), up(t, chipAt, 0.5), { size: port ? SC.h3 : SC.h2, weight: 800, color: s.c.accent, align: 'center' });
}
function barsGeo(s, sideW = 0) {
  const Z = s.zone('stage'), port = s.portrait;
  return port ? { x: Z.x + CHART_LEFT, y: Z.y + 90, w: Z.w - CHART_LEFT, h: 520 } : { x: Z.x + CHART_LEFT, y: Z.y + 70, w: Z.w - CHART_LEFT - sideW, h: Z.h - 140 };
}
/** Motif M3: the area weight's first 12 gradients. absP 0 → signed around a mid zero line, 1 → |g| from the bottom. */
function gradBars(s, r, absP, { growAt, dimOthers = 0, hi = -1 }) {
  const { g, t } = s, vals = A.areaFirst12.g, n = vals.length, top = Math.abs(G0[0]), slot = r.w / n, bw = slot * 0.56;
  const base = lerp(r.y + r.h / 2, r.y + r.h, absP), k = lerp(r.h / 2, r.h, absP) / top;
  // ticks only in the two settled states (signed / squared); none while the bars flip
  const ticks = absP <= 0 ? [[top, fi(top)], [0, '0'], [-top, f(-top, 0)]] : absP >= 1 ? [[top, fi(top)], [top / 2, fi(top / 2)], [0, '0']] : [];
  ticks.forEach(([v, text]) => label(s, text, r.x - 12, base - v * k + SC.micro * 0.35, { size: SC.micro, color: s.c.muted, align: 'right', weight: 600, tracking: 0 }));
  g.save(); g.fillStyle = rgba(s.c.muted, 0.5); g.fillRect(r.x, base - 1, r.w, 2); g.restore();
  const pts = [];
  vals.forEach((v, i) => {
    const gp = up(t, growAt + i * 0.12, 0.4), val = lerp(v, Math.abs(v), absP), x = r.x + slot * i + (slot - bw) / 2;
    g.save(); g.globalAlpha = i === hi ? 1 : 1 - 0.55 * dimOthers; g.fillStyle = s.c.ink;
    const h = val * k * gp; g.fillRect(x, h >= 0 ? base - h : base, bw, Math.abs(h)); g.restore();
    label(s, String(i + 1), x + bw / 2, r.y + r.h + SC.micro * 1.5, { size: SC.micro, color: s.c.muted, align: 'center', weight: 600, tracking: 0 });
    pts.push({ x: x + bw / 2, base, k });
  });
  return pts;
}

const lec1 = {
  id: 'lec1', dur: P.dur('lec1'), recipe: 'orange', holdLast: true,
  draw: s => {
    const { t } = s, tC = P.at('C06-02');
    kicker(s, 1, 4, TXT.l1Kick);
    headline(s, [{ text: TXT.l1Head[0], at: 0 }, { text: TXT.l1Head[1], at: V('lec1', 'mline') }]);
    if (t < tC) {
      const C = s.c, list = [['m', C.accent], [' ← ', C.muted], ['β₁·m', C.accent], [' + ', C.muted], ['(1 − β₁)·g', C.ink]];
      formulaCard(s, list, [[[2, 2], TXT.l1Notes[0], C.accent], [[4, 4], TXT.l1Notes[1], C.ink]], 0,
        { noteAt: [V('lec1', 'formula'), V('lec1', 'formula') + 0.6], chip: TXT.l1Beta, chipAt: V('lec1', 'beta') });
    } else {
      const r = barsGeo(s), flip = A.firstAreaSignFlip - 1;
      exampleTag(s, r.x, r.y - 52, 1);
      legend(s, r.x + r.w, r.y - 22, [[TXT.legendG, s.c.ink, 'bar'], [TXT.legendM, s.c.accent, 'line']]);
      const pts = gradBars(s, r, 0, { growAt: tC, dimOthers: up(t, V('lec1', 'flip'), 0.3) * (1 - up(t, V('lec1', 'mline'), 0.3)), hi: flip });
      const fa = up(t, V('lec1', 'flip'), 0.4);
      if (fa > 0) rise(s, TXT.flip, pts[flip].x, pts[flip].base - A.areaFirst12.g[flip] * pts[flip].k - 24, fa, { size: SC.caption, weight: 800, color: s.c.ink, align: 'center' });
      const mp = tween(t, V('lec1', 'mline'), 1.2, EASE.move);
      poly(s, A.areaFirst12.m.map((m, i) => ({ x: pts[i].x, y: pts[i].base - m * pts[i].k })), mp, { color: s.c.accent, width: ST.bold, dots: 6 });
      const lo = A.areaFirst12.m.reduce((b, m, i, arr) => (Math.abs(m) < Math.abs(arr[b]) ? i : b), 0);
      const sa = up(t, V('lec1', 'sum'), 0.4);
      if (sa > 0) rise(s, `m = ${f(A.areaFirst12.m[lo], 1)}`, pts[lo].x, pts[lo].base - A.areaFirst12.m[lo] * pts[lo].k + 48, sa, { size: SC.caption, weight: 800, color: s.c.accent, align: 'center' });
    }
  },
};

const lec2 = {
  id: 'lec2', dur: P.dur('lec2'), recipe: 'orange', holdLast: true,
  draw: s => {
    const { t } = s, port = s.portrait, Z = s.zone('stage'), tS = P.at('C07-02');
    kicker(s, 2, 4, TXT.l2Kick);
    headline(s, [{ text: TXT.l2Head[0], at: 0 }, { text: TXT.l2Head[1], at: tS }]);
    if (t < tS) {
      const C = s.c, list = [['v', C.muted], [' ← ', C.muted], ['β₂·v', C.muted], [' + ', C.muted], ['(1 − β₂)·g²', C.ink]];
      formulaCard(s, list, [[[2, 2], TXT.l2Notes[0], C.muted], [[4, 4], TXT.l2Notes[1], C.ink]], 0,
        { noteAt: [V('lec2', 'formula'), V('lec2', 'formula') + 0.6], chip: TXT.l2Beta, chipAt: V('lec2', 'beta') });
    } else {
      const sideW = 520, r = barsGeo(s, sideW);
      exampleTag(s, r.x, r.y - 52, 1);
      legend(s, r.x + r.w, r.y - 22, [[TXT.legendAbs, s.c.ink, 'bar'], [TXT.legendV, s.c.muted, 'line']]);
      const pts = gradBars(s, r, tween(t, tS, 0.7, EASE.move), { growAt: tS - 2 });
      const vp = tween(t, V('lec2', 'area'), 1.2, EASE.move), sv = A.areaFirst12.sqrtVHat;
      poly(s, sv.map((v, i) => ({ x: pts[i].x, y: pts[i].base - v * pts[i].k })), vp, { color: s.c.muted, width: ST.bold, dots: 6 });
      const la = up(t, V('lec2', 'area') + 1.2, 0.4);
      if (la > 0) {
        label(s, fi(sv[0]), pts[0].x + 34, pts[0].base - sv[0] * pts[0].k + 30, { role: 'display', size: SC.caption, weight: 800, color: s.c.muted, alpha: la, tracking: 0 });
        label(s, fi(sv[11]), pts[11].x, pts[11].base - sv[11] * pts[11].k - 18, { role: 'display', size: SC.caption, weight: 800, color: s.c.muted, align: 'center', alpha: la, tracking: 0 });
      }
      const sx = port ? Z.x : Z.x + Z.w - sideW + 40, sy = port ? r.y + r.h + 110 : r.y + 40;
      rise(s, TXT.stationV, sx, sy, up(t, V('lec2', 'station'), 0.5), { size: SC.body, weight: 700, color: s.c.muted });
      rise(s, TXT.stationVal, sx, sy + SC.h3 * 1.5, up(t, V('lec2', 'station') + 0.2, 0.5), { size: SC.h3, weight: 800, color: s.c.ink });
      TXT.l2Sum.forEach((line, i) => rise(s, line, sx, sy + SC.h3 * 3.4 + i * SC.body * 1.5, up(t, V('lec2', 'sum') + i * 0.2, 0.5), { size: SC.body, weight: 700, color: s.c.accent }));
    }
  },
};

const lec3 = {
  id: 'lec3', dur: P.dur('lec3'), recipe: 'orange', holdLast: true,
  draw: s => {
    const { t } = s, port = s.portrait, Z = s.zone('stage'), C = s.c, T1 = A.t1;
    kicker(s, 3, 4, TXT.l3Kick);
    headline(s, [{ text: TXT.l3Head[0], at: 0 }]);
    rise(s, TXT.zero, Z.x, Z.y + 40, up(t, V('lec3', 'zero'), 0.5), { size: SC.body, weight: 700, color: C.muted });
    const fsz = port ? SC.h3 : SC.h2, fy = Z.y + (port ? 130 : 140);
    rise(s, 'm̂ = m ÷ (1 − β₁ᵗ)', Z.x, fy, up(t, V('lec3', 'formula'), 0.5), { size: fsz, weight: 800, color: C.accent });
    rise(s, 'v̂ = v ÷ (1 − β₂ᵗ)', Z.x + (port ? Z.w * 0.52 : Z.w * 0.5), fy, up(t, V('lec3', 'formula') + 0.2, 0.5), { size: fsz, weight: 800, color: C.muted });
    const rows = [
      { color: C.accent, segs: [`m₁ = ${short(T1.divM)} × (${f(G0[0], 0)})`, `= ${f(T1.m[0], 0)}`, `÷ ${short(T1.divM)}`, `m̂₁ = ${f(T1.mHat[0], 0)}`], at: ['m1', 'm1', 'fix', 'hat'] },
      { color: C.muted, segs: [`v₁ = ${short(T1.divV)} × ${fi(Math.abs(G0[0]))}²`, `= ${f(T1.v[0], 0)}`, `÷ ${short(T1.divV)}`, `√v̂₁ = ${f(T1.sqrtVHat[0], 0)}`], at: ['v1', 'v1', 'fix', 'hat'] },
    ];
    const size = port ? SC.body : SC.h3;
    rows.forEach((row, i) => {
      const y0 = port ? Z.y + 260 + i * 170 : Z.y + 260 + i * 100;
      const pos = port ? [[0, 0], [Z.w * 0.6, 0], [0, 64], [Z.w * 0.3, 64]] : [[0, 0], [Z.w * 0.33, 0], [Z.w * 0.5, 0], [Z.w * 0.66, 0]];
      row.segs.forEach((seg, k) => {
        const at = V('lec3', row.at[k]) + (k === 1 ? 0.5 : 0) + i * (row.at[k] === 'fix' || row.at[k] === 'hat' ? 0.3 : 0);
        rise(s, seg, Z.x + pos[k][0], y0 + pos[k][1], up(t, at, 0.5), { size, weight: k === 3 ? 800 : 700, color: k === 3 ? row.color : C.ink });
      });
    });
    if (t >= P.at('C08-02')) {
      const cy = port ? Z.y + 640 : Z.y + 430, cw = port ? Z.w : (Z.w - 40) / 2;
      [[TXT.nobc, C.muted, 0], [TXT.bc, C.accent, 1]].forEach(([text, color, k]) => {
        const r = port ? { x: Z.x, y: cy + k * 100, w: cw, h: 80 } : { x: Z.x + k * (cw + 40), y: cy, w: cw, h: 84 };
        lift(s, up(t, P.at('C08-02') + k * 0.4, 0.5), 30, () => {
          panel(s, r, { color, fillA: 0.12, strokeA: 0.8, radius: RAD.chip, lw: ST.line });
          label(s, text, r.x + 28, r.y + r.h / 2 + SC.h3 * 0.36, { role: 'display', size: port ? SC.body : SC.h3, weight: 800, color, tracking: 0 });
        });
      });
    }
  },
};

const lec4 = {
  id: 'lec4', dur: P.dur('lec4'), recipe: 'orange', holdLast: true,
  draw: s => {
    const { t, g, W } = s, port = s.portrait, Z = s.zone('stage'), C = s.c, t20 = P.at('C09-02');
    kicker(s, 4, 4, TXT.l4Kick);
    headline(s, [{ text: TXT.l4Head[0], at: 0 }, { text: TXT.l4Head[1], at: V('lec4', 'area') }]);
    if (t < t20) {
      const size = port ? SC.h2 : SC.h1, y = Z.y + (port ? 90 : 100);
      lift(s, up(t, V('lec4', 'formula'), 0.6), 40, () => parts(s, [['w ← w − ', C.ink], ['α', C.ink], [' · ', C.muted], ['m̂', C.accent], [' ÷ ', C.muted], ['(√v̂ + ε)', C.muted]], W / 2, y, { size, align: 'center' }));
      const cs = port ? SC.caption : SC.h3;
      TXT.calc.forEach((line, k) => rise(s, line, port ? Z.x : W / 2, Z.y + (port ? 250 : 240) + k * (port ? 90 : 90), up(t, V('lec4', k ? 't1s' : 't1'), 0.5), { size: cs, weight: 700, color: k ? C.accent : C.ink, align: port ? 'left' : 'center' }));
      const oa = up(t, V('lec4', 'one'), 0.5);
      if (oa > 0) {
        const bs = port ? SC.body : SC.h3, bw = measure(g, TXT.one, 'display', bs, 800, 0) + bs * 1.6, r = { x: W / 2 - bw / 2, y: Z.y + (port ? 470 : 380), w: bw, h: bs * 2 };
        lift(s, oa, 30, () => {
          panel(s, r, { color: C.accent, fillA: 0.16, strokeA: 0.9, radius: RAD.chip, lw: ST.line });
          label(s, TXT.one, W / 2, r.y + r.h / 2 + bs * 0.36, { role: 'display', size: bs, weight: 800, color: C.accent, align: 'center', tracking: 0 });
        });
      }
    } else {
      const r = port ? { x: Z.x + CHART_LEFT, y: Z.y + 90, w: Z.w - CHART_LEFT - CHART_RIGHT, h: 560 } : { x: Z.x + CHART_LEFT, y: Z.y + 70, w: Z.w - CHART_LEFT - CHART_RIGHT, h: Z.h - 140 };
      const M = scaler(r, 1, STEPS, 0, 1.1);
      exampleTag(s, r.x, r.y - 52, 1);
      label(s, TXT.stepChart, r.x + 8, r.y + 10, { size: SC.caption, color: C.muted, weight: 700, tracking: 0 });
      legend(s, r.x + r.w, r.y - 22, [[TXT.bars[0], C.ink, 'line'], [TXT.bars[1], C.accent, 'line']]);
      axes(s, r, M, { yTicks: [[0, '0'], [0.5, '0.5'], [1, '1']], xTicks: [[1, '1'], [A.t20.t, String(A.t20.t)], [STEPS / 2, String(STEPS / 2)], [STEPS, String(STEPS)]], xLabel: TXT.stepAxis });
      const lp = tween(t, t20, 2.0, EASE.move);
      [0, 1].forEach(k => poly(s, A.stepAbs[k].map((v, i) => ({ x: M.X(i + 1), y: M.Y(v) })), lp, { color: k ? C.accent : C.ink, width: k ? ST.bold : ST.line, alpha: k ? 1 : 0.85 }));
      const x20 = M.X(A.t20.t);
      dashed(s, x20, r.y + 20, x20, r.y + r.h, { color: C.muted, alpha: up(t, t20 + 1.0, 0.4) });
      [['area', 0], ['station', 1]].forEach(([cue, k]) => {
        const a = up(t, V('lec4', cue), 0.4), v = A.t20.stepAbs[k], y = M.Y(v);
        if (a <= 0) return;
        g.save(); g.globalAlpha = a; g.fillStyle = k ? C.accent : C.ink; g.beginPath(); g.arc(x20, y, 9, 0, Math.PI * 2); g.fill(); g.restore();
        rise(s, `${TXT.t20(TXT.bars[k])} ${f(v)}`, x20 + 24, y + (k ? -22 : -18), a, { size: SC.body, weight: 800, color: k ? C.accent : C.ink });
      });
    }
  },
};

const defaults = {
  id: 'defaults', dur: P.dur('defaults'), recipe: 'orange', holdLast: true,
  draw: s => {
    const { t } = s, port = s.portrait, Z = s.zone('stage'), C = s.c;
    tag(s, '본 강의 · 기본값');
    headline(s, [{ text: TXT.defHead[0], at: 0 }, { text: TXT.defHead[1], at: V('defaults', 'choose') }]);
    const cues = ['lr', 'b1', 'b2', 'eps'];
    TXT.chips.forEach((c, i) => {
      const r = port ? { x: Z.x + (i % 2) * ((Z.w - 30) / 2 + 30), y: Z.y + Math.floor(i / 2) * 220, w: (Z.w - 30) / 2, h: 190 } : { x: Z.x + i * ((Z.w - 90) / 4 + 30), y: Z.y + 10, w: (Z.w - 90) / 4, h: 210 };
      lift(s, up(t, V('defaults', cues[i]), 0.5), 40, () => {
        panel(s, r);
        label(s, c.sym, r.x + 30, r.y + 96, { role: 'display', size: SC.h1, weight: 800, color: C.accent, tracking: 0 });
        label(s, c.name, r.x + r.w - 24, r.y + 46, { size: SC.micro, color: C.muted, align: 'right', weight: 600, tracking: 0 });
        label(s, c.val, r.x + 30, r.y + r.h - 30, { role: 'display', size: SC.h2, weight: 800, color: C.ink, tracking: 0 });
      });
    });
    const ny = port ? Z.y + 2 * 220 + 70 : Z.y + 300;
    rise(s, TXT.ours, Z.x, ny, up(t, V('defaults', 'ours'), 0.5), { size: SC.body, weight: 700, color: C.ink });
    rise(s, TXT.bound, Z.x, ny + SC.body * 2, up(t, V('defaults', 'bound'), 0.5), { size: SC.body, weight: 700, color: C.accent });
  },
};

const recap = {
  id: 'recap', dur: P.dur('recap'), recipe: 'cerulean', holdLast: true,
  draw: s => {
    const { t, W } = s, port = s.portrait, Z = s.zone('stage'), C = s.c;
    tag(s, '정리');
    headline(s, [{ text: TXT.recapHead[0], at: 0 }]);
    const cues = ['m', 'v', 'step'];
    TXT.recap.forEach((row, i) => {
      const y = Z.y + (port ? 90 + i * 150 : 80 + i * 120), sx = Z.x, tx = Z.x + (port ? 280 : 420);
      lift(s, up(t, V('recap', cues[i]), 0.5), 40, () => {
        label(s, row.sym, sx, y, { role: 'display', size: i === 2 ? (port ? SC.h3 : SC.h2) : SC.h1, weight: 800, color: i === 2 ? C.ink : C.accent, tracking: 0 });
        label(s, row.text, tx, y, { role: 'display', size: SC.h3, weight: 800, color: C.ink, tracking: 0 });
      });
    });
    const fy = Z.y + (port ? 560 : 430);
    footprints(s, Z.x + 20, Z.x + Z.w - 20, fy, STEPS + 1, { alpha: up(t, V('recap', 'step'), 0.6) });
    rise(s, TXT.practice, port ? Z.x : W / 2, fy + (port ? 110 : 90), up(t, V('recap', 'practice'), 0.5), { size: port ? SC.micro : SC.caption, role: 'text', weight: 700, color: C.muted, align: port ? 'left' : 'center' });
  },
};

const end = {
  id: 'end', dur: P.dur('end'), recipe: 'cerulean', holdLast: true,
  draw: s => {
    const { W, H } = s, port = s.portrait, big = port ? 264 : 280, y = H * (port ? 0.44 : 0.46);
    fill(s, s.c.ground);
    // static lockup (no zoom, no rise): large type under a per-frame transform broke seek determinism before
    label(s, 'Adam', W / 2, y, { role: 'hero', size: big, color: s.c.ink, align: 'center', tracking: 0 });
    const lines = port ? TXT.endSubLines : [TXT.endSub];
    lines.forEach((l, i) => label(s, l, W / 2, y + SC.h3 * 2.2 + i * SC.h3 * 1.4, { role: 'display', size: SC.h3, weight: 800, color: s.c.accent, align: 'center', tracking: 0 }));
    label(s, SERIES, W / 2, y + SC.h3 * 2.2 + lines.length * SC.h3 * 1.4 + SC.label * 1.4, { size: SC.label, color: s.c.muted, align: 'center', weight: 600 });
  },
};

const SCENES = [open, summary, caseScene, sgd, adamcase, lec1, lec2, lec3, lec4, defaults, recap, end];

export default {
  id: ID,
  title: 'Adam — 기울기의 평균과 제곱 평균으로 학습 보폭 조절하기',
  formats: ['16x9', '9x16'],
  scenes: SCENES,
  overlay: s => { if (s.scene.id !== 'open' && s.scene.id !== 'end') foot(s); },
  // QA (verify.py) checks every eojeol of these lines on screen; formulas are drawn in coloured parts and are not listed
  script: [
    'Adam', TXT.sub1, TXT.sub2, plainHead(TXT.sumHead), ...TXT.cards.flatMap(c => [c.title, c.what]), TXT.note1, TXT.note2,
    ...TXT.caseHead.map(plainHead), TXT.devArea, TXT.devStation, TXT.ratio,
    ...TXT.sgdHead.map(plainHead), TXT.lrHigh, TXT.limit, TXT.lrLow,
    ...TXT.adamHead.map(plainHead), TXT.bridge1, TXT.bridge2,
    ...TXT.l1Head.map(plainHead), TXT.flip, ...TXT.l2Head.map(plainHead), ...TXT.l2Sum,
    ...TXT.l3Head.map(plainHead), TXT.nobc, TXT.bc, ...TXT.l4Head.map(plainHead), TXT.one,
    ...TXT.defHead.map(plainHead), TXT.ours, TXT.bound, plainHead(TXT.recapHead[0]), ...TXT.recap.map(r => r.text), TXT.endSub,
  ],
  copy: [JSON.stringify(TXT), TXT.calc.join(' '), 'm̂ v̂ √ ÷ × · ← → − ± ≤ β₁ β₂ ᵗ ε α Δ ² ⁻⁸ ₀ ₁ |g| 0123456789 %㎡()',
    SERIES, '핵심 요약 사용 상황 경사하강법 본 강의 기본값 정리 정답 걸음 예시 값'],
  // narration: one recording per scene (not recorded yet — voice/script.json, tools/voice_lines.py); music bed under it
  // at 0.6× and ducked 12 dB if films/<id>/music/score.* exists (sunzi-trailer levels)
  score: { source: 'library', musicGain: 0.6, duckDb: 12, musicFadeOut: 3 },
  cues: () => Object.values(plan.voice).map(v => ({ t: v.at, kind: 'sample', src: `films/${ID}/voice/v1/${v.file}`, bus: 'voice', maxLen: v.len + 0.5, gain: 1.4, fadeOut: 0.05 })),
};
