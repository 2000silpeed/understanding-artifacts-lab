"""Adam vs SGD on a two-input linear model — the reference example of films/adam-20261108.

The model predicts a house price from two inputs whose units differ (floor area in m², distance to the station in km):
    price = mean_price + w[0]·(area − mean_area) + w[1]·(km − mean_km)
Loss is half the mean squared error, so the gradient is the mean of error × input. The inputs are centred, and the
fixture is a full 4 × 2 grid, so the two inputs are independent and each weight has its own scale of gradient.

Adam (Kingma & Ba, 2015), per parameter i at step t (t starts at 1):
    m[i] = β1·m[i] + (1 − β1)·g[i]          # mean of the gradient          → direction
    v[i] = β2·v[i] + (1 − β2)·g[i]²         # mean of the squared gradient  → size
    m̂ = m[i] / (1 − β1^t),  v̂ = v[i] / (1 − β2^t)   # bias correction: m and v start at 0
    w[i] = w[i] − α·m̂ / (√v̂ + ε)

usage (stdout is JSON; nothing else is printed):
    python3 adam.py fit --data fixtures/houses.csv --opt adam --lr 1 --steps 100
    python3 adam.py fit --data fixtures/houses.csv --opt adam --lr 1 --steps 100 --no-bias-correction
    python3 adam.py fit --data fixtures/houses.csv --opt sgd --lr 0.0035 --steps 100
Standard library only (Python 3.9+).
"""
import argparse
import csv
import json
import math
import sys
from pathlib import Path

NAMES = ['area', 'station']  # w[0]: 백만원 per m², w[1]: 백만원 per km


def load(path):
    """Read the fixture (lines starting with # are notes) and centre both inputs and the price."""
    rows = [r for r in csv.DictReader(line for line in Path(path).read_text(encoding='utf-8').splitlines() if line and not line.startswith('#'))]
    if not rows:
        raise SystemExit(f'no rows in {path}')
    a = [float(r['area_m2']) for r in rows]
    d = [float(r['station_km']) for r in rows]
    p = [float(r['price_mwon']) for r in rows]
    n = len(rows)
    ma, md, mp = sum(a) / n, sum(d) / n, sum(p) / n
    X = [(ai - ma, di - md) for ai, di in zip(a, d)]
    Y = [pi - mp for pi in p]
    return {'n': n, 'mean': {'area_m2': ma, 'station_km': md, 'price_mwon': mp}, 'X': X, 'Y': Y}


def loss_and_grad(w, X, Y):
    """Half mean squared error and its gradient."""
    n = len(X)
    err = [w[0] * x0 + w[1] * x1 - y for (x0, x1), y in zip(X, Y)]
    loss = sum(e * e for e in err) / (2 * n)
    g = [sum(e * x[k] for e, x in zip(err, X)) / n for k in range(2)]
    return loss, g


class Adam:
    def __init__(self, lr, beta1=0.9, beta2=0.999, eps=1e-8, bias_correction=True):
        self.lr, self.b1, self.b2, self.eps, self.bc = lr, beta1, beta2, eps, bias_correction
        self.m = [0.0, 0.0]
        self.v = [0.0, 0.0]
        self.t = 0

    def step(self, w, g):
        """Return the new weights and what each parameter saw this step."""
        self.t += 1
        t, new, seen = self.t, list(w), []
        for i in range(len(w)):
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g[i]
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * g[i] * g[i]
            m_hat = self.m[i] / (1 - self.b1 ** t) if self.bc else self.m[i]
            v_hat = self.v[i] / (1 - self.b2 ** t) if self.bc else self.v[i]
            step = self.lr * m_hat / (math.sqrt(v_hat) + self.eps)
            new[i] = w[i] - step
            seen.append({'m': self.m[i], 'v': self.v[i], 'm_hat': m_hat, 'v_hat': v_hat, 'step': step})
        return new, seen


class SGD:
    def __init__(self, lr):
        self.lr = lr

    def step(self, w, g):
        steps = [self.lr * gi for gi in g]
        return [wi - s for wi, s in zip(w, steps)], [{'step': s} for s in steps]


def fit(data_path, opt='adam', lr=1.0, steps=100, beta1=0.9, beta2=0.999, eps=1e-8, bias_correction=True):
    data = load(data_path)
    X, Y = data['X'], data['Y']
    o = Adam(lr, beta1, beta2, eps, bias_correction) if opt == 'adam' else SGD(lr)
    w = [0.0, 0.0]
    trace = []
    for t in range(1, steps + 1):
        loss, g = loss_and_grad(w, X, Y)
        w_next, seen = o.step(w, g)
        row = {'t': t, 'loss_before': loss, 'w_before': w, 'g': g, 'w': w_next}
        for k in ('m', 'v', 'm_hat', 'v_hat', 'step'):
            if k in seen[0]:
                row[k] = [s[k] for s in seen]
        trace.append(row)
        w = w_next
    loss, g = loss_and_grad(w, X, Y)
    finite = all(math.isfinite(x) for x in w) and math.isfinite(loss)
    config = {'opt': opt, 'lr': lr, 'steps': steps}
    if opt == 'adam':
        config.update({'beta1': beta1, 'beta2': beta2, 'eps': eps, 'bias_correction': bias_correction})
    return {
        'config': config,
        'data': {'file': Path(data_path).name, 'n': data['n'], 'mean': data['mean'], 'params': NAMES},
        'init': {'w': [0.0, 0.0], 'loss': trace[0]['loss_before'], 'g': trace[0]['g']},
        'final': {'w': w, 'loss': loss, 'g': g, 'finite': finite},
        'trace': trace,
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    f = sub.add_parser('fit')
    f.add_argument('--data', default=str(Path(__file__).with_name('fixtures') / 'houses.csv'))
    f.add_argument('--opt', choices=['adam', 'sgd'], default='adam')
    f.add_argument('--lr', type=float, default=1.0)
    f.add_argument('--steps', type=int, default=100)
    f.add_argument('--beta1', type=float, default=0.9)
    f.add_argument('--beta2', type=float, default=0.999)
    f.add_argument('--eps', type=float, default=1e-8)
    f.add_argument('--no-bias-correction', action='store_true')
    a = ap.parse_args(argv)
    res = fit(a.data, a.opt, a.lr, a.steps, a.beta1, a.beta2, a.eps, not a.no_bias_correction)
    # a diverged run is a valid result (it is what the film shows); JSON has no inf/nan, so write them as strings
    json.dump(res, sys.stdout, ensure_ascii=False, indent=1, default=str, allow_nan=True)
    sys.stdout.write('\n')


if __name__ == '__main__':
    main()
