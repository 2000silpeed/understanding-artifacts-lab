// Shared by example/adam.cpp and practice/adam_practice.cpp (C++17, standard library only):
// read the house fixture, centre the inputs, and compute half the mean squared error and its gradient
// in the same order as adam.py, so the C++ and Python numbers agree to the last digits.
#pragma once
#include <array>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

namespace adamex {

using Vec2 = std::array<double, 2>;

struct Data {
  std::vector<Vec2> X;    // centred (area m², distance km)
  std::vector<double> Y;  // centred price (백만원)
  double mean_area = 0, mean_km = 0, mean_price = 0;
};

inline Data load(const std::string& path) {
  std::ifstream in(path);
  if (!in) { std::fprintf(stderr, "cannot open %s\n", path.c_str()); std::exit(2); }
  std::vector<double> a, d, p;
  std::string line;
  bool header = true;
  while (std::getline(in, line)) {
    if (line.empty() || line[0] == '#') continue;
    if (header) { header = false; continue; }  // area_m2,station_km,price_mwon
    std::stringstream ss(line);
    std::string c0, c1, c2;
    std::getline(ss, c0, ','); std::getline(ss, c1, ','); std::getline(ss, c2, ',');
    a.push_back(std::stod(c0)); d.push_back(std::stod(c1)); p.push_back(std::stod(c2));
  }
  if (a.empty()) { std::fprintf(stderr, "no rows in %s\n", path.c_str()); std::exit(2); }
  Data D;
  const double n = static_cast<double>(a.size());
  for (size_t i = 0; i < a.size(); ++i) { D.mean_area += a[i]; D.mean_km += d[i]; D.mean_price += p[i]; }
  D.mean_area /= n; D.mean_km /= n; D.mean_price /= n;
  for (size_t i = 0; i < a.size(); ++i) {
    D.X.push_back({a[i] - D.mean_area, d[i] - D.mean_km});
    D.Y.push_back(p[i] - D.mean_price);
  }
  return D;
}

// Half mean squared error and its gradient g (mean of error × input).
inline double loss_and_grad(const Vec2& w, const Data& D, Vec2& g) {
  const size_t n = D.X.size();
  std::vector<double> err(n);
  double loss = 0;
  for (size_t i = 0; i < n; ++i) {
    err[i] = w[0] * D.X[i][0] + w[1] * D.X[i][1] - D.Y[i];
    loss += err[i] * err[i];
  }
  loss /= 2.0 * n;
  for (int k = 0; k < 2; ++k) {
    double s = 0;
    for (size_t i = 0; i < n; ++i) s += err[i] * D.X[i][k];
    g[k] = s / n;
  }
  return loss;
}

}  // namespace adamex
