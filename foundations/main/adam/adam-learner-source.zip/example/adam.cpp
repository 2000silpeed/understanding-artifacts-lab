// Adam vs SGD on the same two-input linear model as adam.py (C++17, standard library only).
// Prints the same JSON fields as `python3 adam.py fit`, so tests/test_adam.py can compare the two step by step.
//
// build:  c++ -std=c++17 -O2 -ffp-contract=off -Wall -Wextra -o build/adam adam.cpp   (no FMA: reproducible digits)
// usage:  build/adam fit --data fixtures/houses.csv --opt adam --lr 1 --steps 100 [--no-bias-correction]
//         build/adam fit --data fixtures/houses.csv --opt sgd --lr 0.0035 --steps 100
//
// Adam, per parameter i at step t (t starts at 1):
//   m = b1*m + (1-b1)*g        mean of the gradient          (direction)
//   v = b2*v + (1-b2)*g*g      mean of the squared gradient  (size)
//   m_hat = m/(1-b1^t), v_hat = v/(1-b2^t)                   (m and v start at 0)
//   w -= lr * m_hat / (sqrt(v_hat) + eps)
#include <cmath>
#include <cstdio>
#include <sstream>
#include <string>

#include "adam_core.hpp"  // load(), loss_and_grad(): shared with practice/adam_practice.cpp

namespace {

using adamex::Data;
using adamex::Vec2;
using adamex::load;
using adamex::loss_and_grad;

std::string num(double x) {
  if (std::isnan(x)) return "\"nan\"";
  if (std::isinf(x)) return x > 0 ? "\"inf\"" : "\"-inf\"";
  char buf[40];
  std::snprintf(buf, sizeof buf, "%.17g", x);
  return buf;
}
std::string pair(const Vec2& v) { return "[" + num(v[0]) + ", " + num(v[1]) + "]"; }

}  // namespace

int main(int argc, char** argv) {
  std::string data = "fixtures/houses.csv", opt = "adam";
  double lr = 1.0, b1 = 0.9, b2 = 0.999, eps = 1e-8;
  int steps = 100;
  bool bc = true;
  if (argc < 2 || std::string(argv[1]) != "fit") { std::fprintf(stderr, "usage: adam fit [--data F] [--opt adam|sgd] [--lr X] [--steps N] [--beta1 X] [--beta2 X] [--eps X] [--no-bias-correction]\n"); return 2; }
  for (int i = 2; i < argc; ++i) {
    std::string k = argv[i];
    auto val = [&]() -> std::string { if (i + 1 >= argc) { std::fprintf(stderr, "missing value for %s\n", k.c_str()); std::exit(2); } return argv[++i]; };
    if (k == "--data") data = val();
    else if (k == "--opt") opt = val();
    else if (k == "--lr") lr = std::stod(val());
    else if (k == "--steps") steps = std::stoi(val());
    else if (k == "--beta1") b1 = std::stod(val());
    else if (k == "--beta2") b2 = std::stod(val());
    else if (k == "--eps") eps = std::stod(val());
    else if (k == "--no-bias-correction") bc = false;
    else { std::fprintf(stderr, "unknown option %s\n", k.c_str()); return 2; }
  }
  if (opt != "adam" && opt != "sgd") { std::fprintf(stderr, "--opt must be adam or sgd\n"); return 2; }
  const Data D = load(data);
  const bool adam = opt == "adam";
  Vec2 w{0, 0}, m{0, 0}, v{0, 0}, g{0, 0};
  double init_loss = 0;
  Vec2 init_g{0, 0};
  std::ostringstream tr;
  for (int t = 1; t <= steps; ++t) {
    const double loss = loss_and_grad(w, D, g);
    if (t == 1) { init_loss = loss; init_g = g; }
    Vec2 next = w, step{0, 0}, mh{0, 0}, vh{0, 0};
    for (int i = 0; i < 2; ++i) {
      if (adam) {
        m[i] = b1 * m[i] + (1 - b1) * g[i];
        v[i] = b2 * v[i] + (1 - b2) * g[i] * g[i];
        mh[i] = bc ? m[i] / (1 - std::pow(b1, t)) : m[i];
        vh[i] = bc ? v[i] / (1 - std::pow(b2, t)) : v[i];
        step[i] = lr * mh[i] / (std::sqrt(vh[i]) + eps);
      } else {
        step[i] = lr * g[i];
      }
      next[i] = w[i] - step[i];
    }
    tr << (t > 1 ? ",\n  " : "\n  ") << "{\"t\": " << t << ", \"loss_before\": " << num(loss) << ", \"w_before\": " << pair(w) << ", \"g\": " << pair(g) << ", \"w\": " << pair(next);
    if (adam) tr << ", \"m\": " << pair(m) << ", \"v\": " << pair(v) << ", \"m_hat\": " << pair(mh) << ", \"v_hat\": " << pair(vh);
    tr << ", \"step\": " << pair(step) << "}";
    w = next;
  }
  const double loss = loss_and_grad(w, D, g);
  const bool finite = std::isfinite(w[0]) && std::isfinite(w[1]) && std::isfinite(loss);
  std::printf("{\n \"config\": {\"opt\": \"%s\", \"lr\": %s, \"steps\": %d", opt.c_str(), num(lr).c_str(), steps);
  if (adam) std::printf(", \"beta1\": %s, \"beta2\": %s, \"eps\": %s, \"bias_correction\": %s", num(b1).c_str(), num(b2).c_str(), num(eps).c_str(), bc ? "true" : "false");
  std::printf("},\n \"data\": {\"n\": %zu, \"mean\": {\"area_m2\": %s, \"station_km\": %s, \"price_mwon\": %s}, \"params\": [\"area\", \"station\"]},\n",
              D.X.size(), num(D.mean_area).c_str(), num(D.mean_km).c_str(), num(D.mean_price).c_str());
  std::printf(" \"init\": {\"w\": [0, 0], \"loss\": %s, \"g\": %s},\n", num(init_loss).c_str(), pair(init_g).c_str());
  std::printf(" \"final\": {\"w\": %s, \"loss\": %s, \"g\": %s, \"finite\": %s},\n", pair(w).c_str(), num(loss).c_str(), pair(g).c_str(), finite ? "true" : "false");
  std::printf(" \"trace\": [%s\n ]\n}\n", tr.str().c_str());
  return 0;
}
