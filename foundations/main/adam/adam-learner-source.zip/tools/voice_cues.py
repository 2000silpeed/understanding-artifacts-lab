"""Measured narration timing: recordings + ElevenLabs Scribe transcripts → voice/timings.json (read by plan.py).

usage:
  python3 films/adam-20261108/tools/voice_cues.py <dir>
<dir> holds, per scene, the recording named in voice/script.json (e.g. seg-02-case.mp3) and its Scribe transcript
<same name>.json (the speech-to-text response: {"words": [{"text", "start", "end", "type"}, ...]}).
Length is the recording's duration (ffprobe); without ffprobe or audio it falls back to the last word's end + 0.3 s
and says so. Then run `python3 films/adam-20261108/plan.py` and `.venv/bin/python pipeline/shotlint.py adam-20261108`.
"""
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import voicelib  # noqa: E402


def duration(path):
    probe = shutil.which('ffprobe') or ('/opt/homebrew/bin/ffprobe' if Path('/opt/homebrew/bin/ffprobe').exists() else None)
    if not probe or not path.exists():
        return None
    out = subprocess.run([probe, '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', str(path)], capture_output=True, text=True)
    return round(float(out.stdout.strip()), 3) if out.returncode == 0 and out.stdout.strip() else None


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    src = Path(sys.argv[1])
    sc = voicelib.load_script()
    timings, report = {'$doc': 'Measured from recordings + Scribe by tools/voice_cues.py; plan.py prefers this over the estimate.', 'source': str(src), 'scenes': {}}, {}
    for s in sc['scenes']:
        audio = src / s['file']
        tr = audio.with_suffix('.json')
        if not tr.exists():
            raise SystemExit(f'missing transcript {tr}')
        words = json.loads(tr.read_text(encoding='utf-8'))['words']
        cues, rep = voicelib.align(s['tts'], words)
        length = duration(audio)
        if length is None:
            length = round(max(float(w['end']) for w in words) + 0.3, 3)
            rep['length'] = 'last word end + 0.3 s (no audio duration)'
        timings['scenes'][s['id']] = {'file': s['file'], 'len': length, 'cues': cues}
        report[s['id']] = rep
    voicelib.TIMINGS.write_text(json.dumps(timings, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=1))
    print('wrote', voicelib.TIMINGS)


if __name__ == '__main__':
    main()
