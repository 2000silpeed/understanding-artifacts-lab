"""Print the exact narration lines to record (markers stripped), and — once a voice is chosen — the recording commands.

usage:
  python3 films/adam-20261108/tools/voice_lines.py                      # table: scene, file, syllables, estimated length, text
  python3 films/adam-20261108/tools/voice_lines.py --voice <voice_id>   # + one pipeline/elevenlabs.py command per scene
This script never calls an API. Recording is paid and needs the user's approval; run the printed commands then.
"""
import shlex
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import voicelib  # noqa: E402


def main():
    sc = voicelib.load_script()
    voice = sys.argv[sys.argv.index('--voice') + 1] if '--voice' in sys.argv else None
    total = 0.0
    for s in sc['scenes']:
        plain, words, cues = voicelib.parse(s['tts'])
        n = sum(voicelib.syllables(w) for w in words)
        est, _ = voicelib.estimate(s['tts'])
        total += est
        print(f"{s['id']:<9} {s['file']:<22} {n:4d}음절 ≈{est:5.1f}s  cues={len(cues)}")
        print(f"          {plain}")
        if voice:
            text = (sc['voice'].get('tags', '') + ' ' + plain).strip()
            out = f"films/adam-20261108/voice/v1/{s['file']}"
            print('          ' + ' '.join(['python3', 'pipeline/elevenlabs.py', 'tts', shlex.quote(voice), shlex.quote(text), out,
                                         '--model', sc['voice']['model'], '--speed', str(sc['voice']['speed'])]))
    print(f'total ≈{total:.1f}s of speech (placeholder rate {voicelib.RATE} syllables/s)')


if __name__ == '__main__':
    main()
