"""Narration helpers shared by plan.py and the voice tools (standard library only).

A scene's `tts` string carries {cue} markers in front of the word that cues a picture element:
    "{c1}첫째, 엠은 기울기의 평균입니다."
parse() strips the markers and returns the words and each cue's word index; estimate() gives placeholder times
until the recording exists; align() maps cues onto real word times from ElevenLabs Scribe.
"""
import difflib
import json
import re
from pathlib import Path

FILM = Path(__file__).resolve().parents[1]
SCRIPT = FILM / 'voice' / 'script.json'
TIMINGS = FILM / 'voice' / 'timings.json'
MARK = re.compile(r'\{([A-Za-z0-9]+)\}')

# Placeholder speech model, used only until voice/timings.json is measured from the recordings.
RATE = 6.0       # spoken syllables per second (Korean, calm lecture pace; replace with the measured value)
PAUSE = {'.': 0.45, '?': 0.45, '!': 0.45, ',': 0.2}


def load_script():
    return json.loads(SCRIPT.read_text(encoding='utf-8'))


def parse(tts):
    """→ (plain text sent to TTS, words, {cue: word index})."""
    cues, words = {}, []
    for tok in tts.split():
        while True:
            m = MARK.match(tok)
            if not m:
                break
            if m.group(1) in cues:
                raise ValueError(f'duplicate cue {m.group(1)}')
            cues[m.group(1)] = len(words)
            tok = tok[m.end():]
        if MARK.search(tok):
            raise ValueError(f'cue marker inside a word: {tok}')
        if tok:
            words.append(tok)
    return ' '.join(words), words, cues


def syllables(word):
    """Spoken units: Hangul syllables, plus Latin letters/digits as one unit each (the readings are Hangul anyway)."""
    return sum(1 for ch in word if '가' <= ch <= '힣' or ch.isalnum())


def estimate(tts, rate=RATE):
    """Placeholder timing → (length s, {cue: start s}). Each word starts after the syllables and pauses before it."""
    _, words, cues = parse(tts)
    t, starts = 0.0, []
    for w in words:
        starts.append(t)
        t += syllables(w) / rate + sum(PAUSE.get(ch, 0) for ch in w[-1:])
    return round(t, 3), {k: round(starts[i], 3) for k, i in cues.items()}


def norm(word):
    return re.sub(r'[^\w]', '', word).lower()


def align(tts, scribe_words):
    """Cue times from a Scribe transcript: [{'text', 'start', 'end', 'type'?}] in spoken order.

    Script words and transcript words are matched with difflib on normalised text (Scribe may write numbers as
    digits where the script has Hangul readings). A cue on an unmatched word takes the start of the nearest matched
    word after it, or interpolates from the one before. Returns ({cue: start s}, report)."""
    _, words, cues = parse(tts)
    heard = [w for w in scribe_words if w.get('type', 'word') == 'word' and norm(w['text'])]
    a, b = [norm(w) for w in words], [norm(w['text']) for w in heard]
    match = {}
    for blk in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks():
        for k in range(blk.size):
            match[blk.a + k] = blk.b + k
    out, guessed = {}, []
    for cue, i in cues.items():
        if i in match:
            out[cue] = round(float(heard[match[i]]['start']), 3)
            continue
        after = next((j for j in range(i + 1, len(words)) if j in match), None)
        before = next((j for j in range(i - 1, -1, -1) if j in match), None)
        if before is not None and after is not None:
            t0, t1 = float(heard[match[before]]['start']), float(heard[match[after]]['start'])
            out[cue] = round(t0 + (t1 - t0) * (i - before) / (after - before), 3)
        elif after is not None:
            out[cue] = round(float(heard[match[after]]['start']), 3)
        elif before is not None:
            out[cue] = round(float(heard[match[before]]['end']), 3)
        else:
            raise ValueError(f'cannot place cue {cue}: no word of the script was recognised')
        guessed.append(cue)
    return out, {'scriptWords': len(words), 'heardWords': len(heard), 'matched': len(match), 'interpolatedCues': guessed}
