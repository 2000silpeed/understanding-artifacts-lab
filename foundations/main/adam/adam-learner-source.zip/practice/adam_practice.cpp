// 실습(C++17): Adam 한 걸음을 직접 구현한다. TODO 네 곳을 채우고 확인한다:
//   python3 films/adam-20261108/practice/check_practice.py --cpp films/adam-20261108/practice/adam_practice.cpp
// 데이터 읽기와 기울기는 예제의 adam_core.hpp를 그대로 쓴다. 출력은 걸음마다 한 줄:
//   t w0 w1 step0 step1     (w_new = w − step)
#include <cmath>
#include <cstdio>
#include <string>

#include "../example/adam_core.hpp"

using adamex::Vec2;

struct MyAdam {
  double lr = 1.0, b1 = 0.9, b2 = 0.999, eps = 1e-8;
  Vec2 m{0, 0};  // 기울기의 평균 (방향)
  Vec2 v{0, 0};  // 기울기 제곱의 평균 (크기)
  int t = 0;

  // w를 제자리에서 갱신하고, 파라미터마다 움직인 양을 step에 쓴다.
  void step(Vec2& w, const Vec2& g, Vec2& step) {
    ++t;
    for (int i = 0; i < 2; ++i) {
      // TODO 1: m[i] = β1·m[i] + (1 − β1)·g[i]
      // TODO 2: v[i] = β2·v[i] + (1 − β2)·g[i]²
      // TODO 3: 편향 보정 m̂ = m[i] / (1 − β1^t), v̂ = v[i] / (1 − β2^t)   (std::pow)
      // TODO 4: step[i] = lr · m̂ / (√v̂ + eps), w[i] -= step[i]
      step[i] = 0.0;
      (void)g;
    }
  }
};

int main(int argc, char** argv) {
  const std::string data = argc > 1 ? argv[1] : "films/adam-20261108/example/fixtures/houses.csv";
  const adamex::Data D = adamex::load(data);
  MyAdam opt;
  Vec2 w{0, 0}, g{0, 0}, st{0, 0};
  for (int t = 1; t <= 100; ++t) {
    adamex::loss_and_grad(w, D, g);
    opt.step(w, g, st);
    std::printf("%d %.17g %.17g %.17g %.17g\n", t, w[0], w[1], st[0], st[1]);
  }
  return 0;
}
