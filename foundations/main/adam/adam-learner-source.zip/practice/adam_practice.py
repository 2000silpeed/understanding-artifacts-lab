"""실습: Adam 한 걸음을 직접 구현한다.

TODO 네 곳을 채우고 확인한다:
    python3 films/adam-20261108/practice/check_practice.py
데이터 읽기와 손실·기울기 계산은 예제(example/adam.py)의 것을 그대로 쓴다. 여기서는 옵티마이저만 만든다.
영상의 숫자(첫 걸음 보폭 1, 20번째 걸음 0.07 / 0.91, 100걸음 뒤 3.99 / −50.39)가 그대로 나오면 성공이다.
"""
import math  # noqa: F401  (TODO 4에서 math.sqrt를 쓴다)
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'example'))
from adam import load, loss_and_grad  # noqa: E402  (예제의 데이터 읽기·기울기)


class MyAdam:
    def __init__(self, lr=1.0, beta1=0.9, beta2=0.999, eps=1e-8):
        self.lr, self.b1, self.b2, self.eps = lr, beta1, beta2, eps
        self.m = [0.0, 0.0]  # 기울기의 평균 (방향)
        self.v = [0.0, 0.0]  # 기울기 제곱의 평균 (크기)
        self.t = 0

    def step(self, w, g):
        """새 가중치와, 파라미터마다 이번에 움직인 양(step)을 돌려준다: w_new[i] = w[i] − step[i]."""
        self.t += 1
        new, steps = list(w), []
        for i in range(len(w)):
            # TODO 1: m[i]를 갱신한다. 새 기울기 g[i]를 (1 − β1)만큼, 지난 m[i]를 β1만큼 섞는다.
            raise NotImplementedError('TODO 1: m 갱신')
            # TODO 2: v[i]를 갱신한다. 기울기 제곱 g[i]²을 (1 − β2)만큼, 지난 v[i]를 β2만큼 섞는다.
            # TODO 3: 편향 보정. m̂ = m[i] / (1 − β1^t), v̂ = v[i] / (1 − β2^t)
            # TODO 4: 보폭. step = lr · m̂ / (√v̂ + eps), 그리고 new[i] = w[i] − step
        return new, steps


def run(data_path=None, steps=100, **kw):
    data = load(data_path or Path(__file__).resolve().parents[1] / 'example' / 'fixtures' / 'houses.csv')
    opt, w, trace = MyAdam(**kw), [0.0, 0.0], []
    for _ in range(steps):
        _, g = loss_and_grad(w, data['X'], data['Y'])
        w, st = opt.step(w, g)
        trace.append({'w': w, 'step': st, 'm': list(opt.m), 'v': list(opt.v)})
    return trace


if __name__ == '__main__':
    tr = run()
    print('1번째 걸음 보폭:', [round(abs(x), 4) for x in tr[0]['step']])
    print('20번째 걸음 보폭:', [round(abs(x), 2) for x in tr[19]['step']])
    print('100걸음 뒤 w:', [round(x, 2) for x in tr[-1]['w']])
    # 더 해 보기 (practice/README.md): β1 = 0, 편향 보정 빼기, lr 바꾸기, 가격 단위를 10배로
