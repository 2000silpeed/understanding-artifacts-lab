"""실습 확인: 내 Adam이 예제(example/results/adam_lr1.py.json)와 걸음마다 같은지 본다.

usage:
  python3 films/adam-20261108/practice/check_practice.py [내_파일.py]          # 기본: practice/adam_practice.py
  python3 films/adam-20261108/practice/check_practice.py --cpp [내_파일.cpp]   # 기본: practice/adam_practice.cpp
처음 어긋나는 걸음과, 어느 TODO를 보면 되는지 알려 준다. 맞으면 exit 0, 아니면 exit 1.
"""
import importlib.util
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILM = HERE.parent
REF = json.loads((FILM / 'example' / 'results' / 'adam_lr1.py.json').read_text(encoding='utf-8'))['trace']
FIXTURE = FILM / 'example' / 'fixtures' / 'houses.csv'
NAMES = ['면적', '거리']


def close(a, b, tol=1e-9):
    return abs(a - b) <= tol * max(1.0, abs(b))


def hint(t, key, i, got, want):
    if key == 'm':
        return 'TODO 1(m 갱신)을 보세요: m = β1·m + (1 − β1)·g'
    if key == 'v':
        return 'TODO 2(v 갱신)을 보세요: v = β2·v + (1 − β2)·g²'
    if t == 1 and want and close(abs(got / want), 0.1 / math.sqrt(0.001), 1e-6):
        return '첫 걸음이 3.16배입니다. TODO 3의 편향 보정(1 − β^t로 나누기)이 빠졌습니다.'
    if t == 1 and got == 0:
        return '아직 움직이지 않습니다. TODO 4에서 step을 계산하고 w에서 빼세요.'
    return 'TODO 3–4(편향 보정, step = lr·m̂/(√v̂ + eps), w − step)를 보세요.'


def compare(rows, keys):
    for ref, row in zip(REF, rows):
        t = ref['t']
        for key in keys:
            for i in range(2):
                got, want = row[key][i], ref[key][i]
                if not (isinstance(got, (int, float)) and math.isfinite(got) and close(got, want)):
                    return f"{t}번째 걸음, {NAMES[i]}의 {key}: {got!r} (정답 {want!r}). {hint(t, key, i, got, want)}"
    if len(rows) < len(REF):
        return f'{len(rows)}걸음만 나왔습니다(100걸음 필요).'
    return None


def check_py(path):
    spec = importlib.util.spec_from_file_location('learner', path)
    mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(Path(path).resolve().parent))
    try:
        spec.loader.exec_module(mod)
        rows = mod.run(FIXTURE, 100)
    except NotImplementedError as e:
        return f'아직 TODO가 남았습니다: {e}'
    return compare(rows, ['m', 'v', 'step', 'w'])


def check_cpp(path):
    cxx = shutil.which('c++') or shutil.which('clang++') or shutil.which('g++')
    if not cxx:
        return 'C++ 컴파일러(c++)가 없습니다.'
    with tempfile.TemporaryDirectory() as tmp:
        exe = Path(tmp) / 'learner'
        b = subprocess.run([cxx, '-std=c++17', '-O2', '-ffp-contract=off', '-Wall', '-Wextra', '-o', str(exe), str(path)], capture_output=True, text=True)
        if b.returncode:
            return '컴파일 실패:\n' + b.stderr[-1500:]
        r = subprocess.run([str(exe), str(FIXTURE)], capture_output=True, text=True)
        if r.returncode:
            return f'실행 실패(exit {r.returncode}): {r.stderr[-500:]}'
    rows = []
    for line in r.stdout.split('\n'):
        if line.strip():
            t, w0, w1, s0, s1 = line.split()
            rows.append({'w': [float(w0), float(w1)], 'step': [float(s0), float(s1)]})
    return compare(rows, ['step', 'w'])


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    cpp = '--cpp' in argv
    rest = [a for a in argv if a != '--cpp']
    path = Path(rest[0]) if rest else HERE / ('adam_practice.cpp' if cpp else 'adam_practice.py')
    err = check_cpp(path) if cpp else check_py(path)
    if err:
        print('FAIL', path.name, '—', err)
        return 1
    s1, s20, w = [abs(x) for x in REF[0]['step']], [abs(x) for x in REF[19]['step']], REF[-1]['w']
    print(f'PASS {path.name} — 100걸음 모두 예제와 같습니다. 첫 걸음 보폭 {s1[0]:.4f} / {s1[1]:.4f}, '
          f'20번째 {s20[0]:.2f} / {s20[1]:.2f}, 100걸음 뒤 w = {w[0]:.2f} / {w[1]:.2f}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
