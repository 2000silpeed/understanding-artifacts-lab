"""실습 풀이: practice/adam_practice.py의 TODO를 채운 것. 확인:
    python3 films/adam-20261108/practice/check_practice.py films/adam-20261108/practice/solutions/adam_practice_solved.py
"""
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import adam_practice  # noqa: E402  (run()과 데이터 읽기는 실습 파일 것을 그대로 쓴다)


class MyAdam(adam_practice.MyAdam):
    def step(self, w, g):
        self.t += 1
        new, steps = list(w), []
        for i in range(len(w)):
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g[i]           # 1: 기울기의 평균
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * g[i] * g[i]    # 2: 기울기 제곱의 평균
            m_hat = self.m[i] / (1 - self.b1 ** self.t)                       # 3: 편향 보정
            v_hat = self.v[i] / (1 - self.b2 ** self.t)
            step = self.lr * m_hat / (math.sqrt(v_hat) + self.eps)            # 4: 보폭
            new[i] = w[i] - step
            steps.append(step)
        return new, steps


def run(data_path=None, steps=100, **kw):
    adam_practice.MyAdam, original = MyAdam, adam_practice.MyAdam
    try:
        return adam_practice.run(data_path, steps, **kw)
    finally:
        adam_practice.MyAdam = original


if __name__ == '__main__':
    tr = run()
    print('1번째 걸음 보폭:', [round(abs(x), 4) for x in tr[0]['step']])
    print('20번째 걸음 보폭:', [round(abs(x), 2) for x in tr[19]['step']])
    print('100걸음 뒤 w:', [round(x, 2) for x in tr[-1]['w']])
