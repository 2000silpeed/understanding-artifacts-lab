// 실습 풀이(C++17). 확인:
//   python3 films/adam-20261108/practice/check_practice.py --cpp films/adam-20261108/practice/solutions/adam_practice_solved.cpp
// 데이터 읽기와 기울기는 예제의 adam_core.hpp를 그대로 쓴다. 출력은 걸음마다 한 줄:
//   t w0 w1 step0 step1     (w_new = w − step)
#include <cmath>
#include <cstdio>
#include <string>

#include "../../example/adam_core.hpp"

using adamex::Vec2;

struct MyAdam {
  double lr = 1.0, b1 = 0.9, b2 = 0.999, eps = 1e-8;
  Vec2 m{0, 0};  // 기울기의 평균 (방향)
  Vec2 v{0, 0};  // 기울기 제곱의 평균 (크기)
  int t = 0;

  // w를 제자리에서 갱신하고, 파라미터마다 움직인 양을 step에 쓴다.
  void step(Vec2& w, const Vec2& g, Vec2& step) {
    ++t;
    for (int i = 0; i < 2; ++i) {
      m[i] = b1 * m[i] + (1 - b1) * g[i];          // 1: 기울기의 평균
      v[i] = b2 * v[i] + (1 - b2) * g[i] * g[i];   // 2: 기울기 제곱의 평균
      const double m_hat = m[i] / (1 - std::pow(b1, t));  // 3: 편향 보정
      const double v_hat = v[i] / (1 - std::pow(b2, t));
      step[i] = lr * m_hat / (std::sqrt(v_hat) + eps);    // 4: 보폭
      w[i] -= step[i];
    }
  }
};

int main(int argc, char** argv) {
  const std::string data = argc > 1 ? argv[1] : "films/adam-20261108/example/fixtures/houses.csv";
  const adamex::Data D = adamex::load(data);
  MyAdam opt;
  Vec2 w{0, 0}, g{0, 0}, st{0, 0};
  for (int t = 1; t <= 100; ++t) {
    adamex::loss_and_grad(w, D, g);
    opt.step(w, g, st);
    std::printf("%d %.17g %.17g %.17g %.17g\n", t, w[0], w[1], st[0], st[1]);
  }
  return 0;
}
