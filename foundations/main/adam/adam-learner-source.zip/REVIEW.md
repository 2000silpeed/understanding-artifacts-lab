# Adam — 기울기의 평균과 제곱 평균으로 학습 보폭 조절하기 (REVIEW)

**미적 승인: 대기** · **단계: 소스 작성 완료, 독립 검수 전 (SOURCE_AUTHORED_NOT_INDEPENDENT)**

- 렌더한 결과물이 없다(스틸·미리보기·전체 모두 하지 않음). 녹음·음악·업로드도 없다.
- 기술 검사는 소스 단계 것만 했다. `verify.py`와 `shotlint --video`는 렌더 뒤에 할 일이다.

## 소스 단계 검사 (2026-11-08)

| 항목 | 결과 |
|---|---|
| `example/run_examples.py --check` (Python·C++ 각 4회 실행, 결과 일치) | PASS |
| `tests/` unittest 27개 | PASS |
| `tests/film_smoke.mjs` (두 포맷 × 9,144프레임, 모의 캔버스) | PASS: 예외·레이아웃 위반·안전 영역 이탈·겹침 0, 대본 48줄 모두 화면에 있음 |
| `tests/bundle_check.mjs` (실제 빌드 설정, 메모리) | PASS |
| `pipeline/shotlint.py adam-20261108` (계획) | PASS |

자세한 명령과 exit 코드, hash는 `qa/author-result.json`에 있다.

## 남은 일

발음 승인 → 목소리 선택·녹음 → Scribe 단어 시각 → `plan.py` → (음악) → 스틸 게이트 → `make.sh` → `verify.py` → `shotlint --video` → 사람 리뷰. 순서와 명령은 `README.md`에 있다.
