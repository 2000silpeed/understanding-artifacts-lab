"""실습 정답: split_node (강의 코드 code/python/btree.py의 _split과 같은 일).

확인: python3 films/b-tree-20261108/practice/check.py films/b-tree-20261108/practice/solution_btree.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'code' / 'python'))
from btree import Node  # noqa: E402


def split_node(node):
    """넘친 node를 쪼개 (가운데 키, 오른쪽 새 노드)를 돌려준다. node는 왼쪽 절반만 남도록 바꾼다."""
    m = len(node.keys) // 2
    mid = node.keys[m]
    right = Node(node.keys[m + 1:], node.children[m + 1:])
    node.keys = node.keys[:m]
    node.children = node.children[:m + 1]
    return mid, right
