"""실습: 넘친 B 트리 노드를 쪼개는 split_node를 채운다.

영상의 강의 코드(code/python/btree.py)에서 _split만 비워 둔 실습이다. 나머지(search, insert)는 강의 코드를 그대로 쓴다.
확인: python3 films/b-tree-20261108/practice/check.py films/b-tree-20261108/practice/exercise_btree.py

규칙 (영상과 같음)
- node.keys는 정렬돼 있고, 지금 max_keys + 1개로 넘친 상태다. 예: [10, 20, 30, 40, 50]
- 가운데 키(인덱스 len(keys) // 2)를 위로 올린다. 예: 30
- 가운데보다 왼쪽 키와 그 자식은 node에 남기고, 오른쪽 키와 그 자식은 새 노드 right로 옮긴다.
  자식이 있는 노드(잎이 아닌 노드)라면 자식 수는 키 수 + 1이다. 왼쪽은 키 m개·자식 m + 1개.
- (mid, right)를 돌려준다. 부모가 mid를 받아 끼우는 일은 _insert가 이미 한다.

Node는 Node(keys, children)로 만든다(강의 코드의 클래스, 아래에서 가져온다).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'code' / 'python'))
from btree import Node  # noqa: E402


def split_node(node):
    """넘친 node를 쪼개 (가운데 키, 오른쪽 새 노드)를 돌려준다. node는 왼쪽 절반만 남도록 바꾼다."""
    # 여기를 채운다 (5–6줄). 힌트: m = len(node.keys) // 2
    raise NotImplementedError('split_node가 아직 비어 있습니다')
