"""실습 채점: 내가 쓴 split_node로 영상의 예제와 무작위 삽입을 돌려 강의 코드와 비교한다.

usage: python3 films/b-tree-20261108/practice/check.py <내 파일.py>      (통과 0, 실패 1)
1) 영상 예제: code/fixtures/lesson.txt의 삽입 순서대로 넣으며 매 단계 트리가 강의 코드와 같은지
2) 무작위: max_keys 2–6, 키 300개를 섞어 넣고 B 트리 규칙(정렬, 키 수, 자식 수, 잎 깊이)과 탐색 결과
"""
import importlib.util
import random
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'code' / 'python'))
import btree  # noqa: E402


def load(path):
    spec = importlib.util.spec_from_file_location('practice_split', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.split_node


def tree_with(split_node, max_keys):
    class PracticeTree(btree.BTree):
        def _split(self, node):
            return split_node(node)
    return PracticeTree(max_keys)


def main():
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    split_node = load(sys.argv[1])
    fx = btree.read_fixture(HERE.parent / 'code' / 'fixtures' / 'lesson.txt')
    mine, ref = tree_with(split_node, fx['max_keys'][0]), btree.BTree(fx['max_keys'][0])
    try:
        for key in fx['insert']:
            mine.insert(key)
            ref.insert(key)
            if btree.show(mine.root) != btree.show(ref.root):
                print(f'FAIL 영상 예제: {key}를 넣은 뒤 트리가 다릅니다\n  내 결과   {btree.show(mine.root)}\n  기대 결과 {btree.show(ref.root)}')
                return 1
        print(f'PASS 영상 예제: {len(fx["insert"])}개 삽입, 최종 {btree.show(mine.root)}')
        rnd = random.Random(20261108)
        for max_keys in range(2, 7):
            keys = rnd.sample(range(1000), 300)
            t = tree_with(split_node, max_keys)
            for k in keys:
                t.insert(k)
            btree.check(t)
            present = set(keys)
            for k in range(1000):
                if t.search(k)[0] != (k in present):
                    print(f'FAIL 무작위(max_keys {max_keys}): {k} 탐색 결과가 틀립니다')
                    return 1
        print('PASS 무작위: max_keys 2–6, 키 300개씩, 규칙과 탐색 모두 맞음')
    except NotImplementedError as e:
        print(f'FAIL {e} — practice 파일의 split_node를 채우세요')
        return 1
    except AssertionError as e:
        print(f'FAIL B 트리 규칙 위반: {e}')
        return 1
    print('CHECK PASS')
    return 0


if __name__ == '__main__':
    sys.exit(main())
