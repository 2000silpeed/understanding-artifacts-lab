# B 트리: 여러 키를 한 노드에 담아 탐색과 삽입하기 — 소스 패키지

AI 기본기 교육 영상(공개 패키징 트랙 15). **소스 단계**다. 녹음·음악·렌더는 아직 없다(아래 "다음 단계").

구성: **핵심 개념 요약 → 구체적 사용 상황(데이터베이스 색인) → 본 강의 7장(노드 구조 · 탐색 · 삽입 · 분할 · 연쇄 분할 · 파이썬 코드 · C++17) → 정리·실습 → 엔드 카드**. 장면별 화면 카피와 발화는 [scenario.md](scenario.md), 컷 단위 계획은 [shotlist.md](shotlist.md).

## 한 번의 실제 실행이 원천이다

화면의 트리 상태, 탐색 경로, 비교 횟수, 층수, 코드 줄, 출력 줄은 모두 `data/film-data.json`에서 읽는다. 이 파일은 `code/export.py`가 Python 예제를 실제로 돌려 만들고, 같은 입력으로 C++ 예제를 컴파일·실행해 출력이 한 글자도 다르지 않은지 확인한 뒤에만 쓴다. 발화의 숫자는 `voice/script.json`의 `claims`로 같은 파일과 대조한다(테스트).

| 무엇 | 파일 |
|---|---|
| 예제 입력 | `code/fixtures/lesson.txt` — 차수 5(노드당 키 최대 4개), 삽입 `30 10 50 20 40 70 60 80 25`, 탐색 `40 65`, 층수 계산(100만 키, 노드당 1·4·255키), 100만 키 실험 |
| Python 예제 | `code/python/btree.py` — `search`, `insert`/`_insert`, `_split` (`[film:*]` 표시 사이가 화면에 나오는 줄) |
| C++17 예제 | `code/cpp/btree.cpp` — 같은 알고리즘, 같은 출력 (`-std=c++17 -Wall -Wextra -Werror`) |
| 실제 실행 결과 | `code/expected/python-stdout.txt`, `code/expected/cpp-stdout.txt` (26줄, 동일) |
| 영상 데이터 | `data/film-data.json` (생성물, 손대지 않음) |
| 대본·읽기·큐 | `voice/script.json` — `text`(원문), `tts`(한글 읽기), `cues`(그림이 놓이는 단어), `readings`(승인 필요 읽기), `claims` |
| 전사 → 큐 시각 | `voice/cues.py` |
| 기획 | `plan.py` → `shots.json`, `scenario.md` · `shotlist.md`(shotlint 생성) |
| 연출(그림) | `film.js` — 엔진 `engine/*`, 컴포넌트 `system/components/*`, 토큰 `system/tokens.json`만 사용. 공유 파일은 바꾸지 않았다 |
| 실습 | `practice/exercise_btree.py`(빈칸 `split_node`), `practice/solution_btree.py`, `practice/check.py` |
| 소스 테스트 | `tests/test_btree.py`, `tests/test_film_data.py`, `tests/film_smoke.mjs`, `tests/bundle_check.cjs` |

## 확인 명령 (저장소 루트에서)

```sh
python3 films/b-tree-20261108/code/export.py --check        # Python·C++ 다시 실행 → 출력 동일, 데이터 최신
python3 films/b-tree-20261108/plan.py --check               # shots.json·scenario.md 최신
python3 pipeline/shotlint.py b-tree-20261108                # 샷리스트 검사(plan)
python3 -m unittest discover -s films/b-tree-20261108/tests -p 'test_*.py' -v
node films/b-tree-20261108/tests/film_smoke.mjs             # 렌더 없이 모든 장면을 모의 캔버스에 그려 검사
node films/b-tree-20261108/tests/bundle_check.cjs           # engine/main.js + film.js 번들(메모리, 파일 안 씀)
python3 films/b-tree-20261108/practice/check.py films/b-tree-20261108/practice/solution_btree.py   # 정답 → CHECK PASS
python3 films/b-tree-20261108/practice/check.py films/b-tree-20261108/practice/exercise_btree.py   # 빈칸 → FAIL(정상)
```

예제를 바꾸면 `python3 films/b-tree-20261108/code/export.py` → `python3 films/b-tree-20261108/plan.py` 순서로 다시 만든다. 대본의 숫자를 바꾸면 `claims`도 고친다.

## 다음 단계 (승인 필요, 이 패키지에서는 하지 않음)

1. **읽기 승인**: `voice/script.json`의 `readings` 중 `approve: true`(k개·k+1개, C++17, 코드 이름 읽기).
2. **목소리 고르기·녹음(유료)**: 후보 3–5개를 summary 첫 문장으로 비교 → 장면당 한 파일, `tts` 문장 그대로.
   `python3 pipeline/elevenlabs.py tts <voice_id> "<tts>" films/b-tree-20261108/voice/<file> --model eleven_v4 --stability 0.55 --style 0.2 --speed 0.95`
   파일 이름은 `voice/script.json`의 `file`(seg-01-summary.mp3 … seg-11-end.mp3).
3. **전사**: 장면마다 Scribe 결과를 `voice/scribe/<scene>.json`(`{"words": [{"text","start","end","type"}]}`)으로 둔다 → `python3 films/b-tree-20261108/plan.py`가 실측 단어 시각과 녹음 길이로 장면 길이·큐를 다시 쓴다(큐를 못 찾으면 어느 큐인지 알려 준다).
4. **음악(유료)**: `shots.json` `music.brief`(100 BPM, 내레이션 밑 차분한 베드, 길이는 재계획 뒤 값) → `films/b-tree-20261108/music/score.mp3` → `pipeline/measure_music.py`로 위상을 재서 `plan.py`의 `offset`에 적는다. 베드 0.6배, 내레이션 아래 12 dB 덕킹(`film.js` `score`).
5. **스틸 게이트(사람 확인)**: `node pipeline/build.cjs b-tree-20261108 && node pipeline/render.cjs b-tree-20261108 --format 16x9 --stills` → `contact.py` 시트, 9:16도.
6. **제작·검증**: `sh pipeline/make.sh b-tree-20261108 16x9 9x16` → `verify.py` PASS → `shotlint.py b-tree-20261108 --video 16x9 9x16` → `REVIEW.md`. 기술 PASS는 승인이 아니다.

## 알려진 한계 (소스 단계)

- 단어 시각과 길이(약 317초)는 **추정값**(초당 5.6음절)이다. 실제 녹음 뒤 바뀐다.
- 레이아웃은 모의 캔버스(한글 0.95em·라틴 0.6em 근사)로만 검사했다. 실제 글자 폭·겹침·가독성은 스틸 게이트에서 눈으로 확인해야 한다.
- 녹음과 음악 파일이 없어서 지금은 `audio.py`가 이 영상을 섞을 수 없다(목소리 큐가 `voice/*.mp3`를 가리킴).
- 자체 호스팅 고정폭 서체가 없어 코드는 Pretendard를 고정 칸에 놓아 그린다(공유 폰트 설정은 바꾸지 않음).
- paper 장면의 밝은 배경 필드는 움직임이 약해 QA "1초 이상 정지 구간"에 걸릴 수 있다. 렌더 뒤 확인이 필요하다.
