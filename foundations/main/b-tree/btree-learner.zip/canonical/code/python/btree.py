"""B-tree: several sorted keys in one node, search and insert (split on overflow).

usage:
  python3 btree.py <fixture.txt>                      print the lesson run (same text as the C++ version)
  python3 btree.py <fixture.txt> --trace <out.json>   also write every tree state for the film

The lines between `# [film:<name>]` and `# [film:end]` are shown on screen; keep them short (≤ 48 columns).
"""
import json
import sys
from bisect import bisect_left


class Node:
    def __init__(self, keys=None, children=None):
        self.keys = keys or []          # sorted, no duplicates
        self.children = children or []  # len(keys) + 1, or [] in a leaf

    @property
    def leaf(self):
        return not self.children


def slot(keys, key):
    """First index whose key is >= key (std::lower_bound in the C++ version)."""
    return bisect_left(keys, key)


class BTree:
    def __init__(self, max_keys=4, watch=None):
        if max_keys < 2:
            raise ValueError('max_keys must be at least 2')
        self.max_keys = max_keys
        self.root = Node()
        self.watch = watch  # watch(event, key) after every change (the film's trace)

    def _tell(self, event, key):
        if self.watch:
            self.watch(event, key)

    # [film:search]
    def search(self, key):
        node, path, seen = self.root, [], []
        while True:
            path.append(node)
            i = 0
            while i < len(node.keys):
                seen.append(node.keys[i])
                if key == node.keys[i]:
                    return True, path, seen
                if key < node.keys[i]:
                    break
                i += 1
            if node.leaf:
                return False, path, seen
            node = node.children[i]
    # [film:end]

    def insert(self, key):
        up = self._insert(self.root, key)
        if up:  # the root split: a new root on top
            mid, right = up
            self.root = Node([mid], [self.root, right])
            self._tell('new-root', mid)

    # [film:insert]
    def _insert(self, node, key):
        i = slot(node.keys, key)
        if node.keys[i:i + 1] == [key]:
            return None            # already there
        if node.leaf:
            node.keys.insert(i, key)
            self._tell('placed', key)
        else:
            up = self._insert(node.children[i], key)
            if not up:
                return None
            mid, right = up
            node.keys.insert(i, mid)
            node.children.insert(i + 1, right)
            self._tell('raised', mid)
        if len(node.keys) > self.max_keys:
            return self._split(node)
        return None
    # [film:end]

    # [film:split]
    def _split(self, node):
        m = len(node.keys) // 2
        mid = node.keys[m]
        right = Node(node.keys[m + 1:],
                     node.children[m + 1:])
        node.keys = node.keys[:m]
        node.children = node.children[:m + 1]
        return mid, right
    # [film:end]


# ---------- views and checks (not shown in the film) ----------

def as_dict(node):
    """{'k': keys, 'c': children} — the shape the film draws."""
    d = {'k': list(node.keys)}
    if node.children:
        d['c'] = [as_dict(c) for c in node.children]
    return d


def levels(node):
    out, row = [], [node]
    while row:
        out.append(row)
        row = [c for n in row for c in n.children]
    return out


def show(node):
    """'[30 60] / [10 20 25] [40 50] [70 80]' — one group per level."""
    return ' / '.join(' '.join('[' + ' '.join(map(str, n.keys)) + ']' for n in row) for row in levels(node))


def stats(tree):
    rows = levels(tree.root)
    return {'height': len(rows), 'nodes': sum(len(r) for r in rows), 'keys': sum(len(n.keys) for r in rows for n in r)}


def overflowing(tree):
    return any(len(n.keys) > tree.max_keys for r in levels(tree.root) for n in r)


def check(tree):
    """B-tree invariants; raises AssertionError on the first broken one."""
    leaf_depths = set()

    def walk(node, lo, hi, depth):
        assert node.keys == sorted(set(node.keys)), 'keys sorted and unique'
        assert len(node.keys) <= tree.max_keys, 'at most max_keys keys'
        if node is not tree.root:
            assert len(node.keys) >= tree.max_keys // 2, 'non-root node at least half full'
        assert all((lo is None or k > lo) and (hi is None or k < hi) for k in node.keys), 'keys between parent separators'
        if node.leaf:
            leaf_depths.add(depth)
            return
        assert len(node.children) == len(node.keys) + 1, 'children = keys + 1'
        bounds = [lo] + node.keys + [hi]
        for j, c in enumerate(node.children):
            walk(c, bounds[j], bounds[j + 1], depth + 1)

    walk(tree.root, None, None, 0)
    assert len(leaf_depths) <= 1, 'all leaves at the same depth'


def levels_needed(n, max_keys):
    """Fewest levels that hold n keys when every node holds max_keys keys: (max_keys+1)^h - 1 >= n."""
    h, cap = 0, 0
    while cap < n:
        h += 1
        cap = (max_keys + 1) ** h - 1
    return h


# ---------- the lesson run ----------

def read_fixture(path):
    fx = {}
    for line in open(path, encoding='utf-8'):
        line = line.split('#', 1)[0].split()
        if line:
            fx[line[0]] = [int(x) for x in line[1:]]
    return fx


def run(path, trace_path=None):
    fx = read_fixture(path)
    max_keys = fx['max_keys'][0]
    out = [f'max_keys {max_keys}']
    trace = {'maxKeys': max_keys, 'inserts': [], 'searches': []}
    events = []
    tree = BTree(max_keys, watch=lambda e, k: events.append((e, k, as_dict(tree.root), show(tree.root), overflowing(tree))))
    for key in fx['insert']:
        events.clear()
        tree.insert(key)
        out.append(f'insert {key}')
        for e, k, d, txt, over in events:
            out.append(f'  {e} {k}: {txt}' + ('  (overflow)' if over else ''))
        trace['inserts'].append({'key': key, 'events': [{'event': e, 'key': k, 'tree': d, 'overflow': over} for e, k, d, _, over in events]})
        assert not overflowing(tree)
    check(tree)
    for key in fx['search']:
        found, path, seen = tree.search(key)
        route = ' > '.join('[' + ' '.join(map(str, n.keys)) + ']' for n in path)
        out.append(f'search {key}: {"found" if found else "not found"}, path {route}, compared {" ".join(map(str, seen))} ({len(seen)})')
        trace['searches'].append({'key': key, 'found': found, 'path': [list(n.keys) for n in path], 'seen': seen})
    st = stats(tree)
    out.append(f"tree height {st['height']}, nodes {st['nodes']}, keys {st['keys']}")
    trace['final'] = as_dict(tree.root)
    trace['stats'] = st

    n, *mks = fx['capacity']
    caps = {mk: levels_needed(n, mk) for mk in mks}
    out.append(f'levels for {n} keys (full nodes): ' + ', '.join(f'max_keys {mk} -> {h}' for mk, h in caps.items()))
    trace['capacity'] = {'n': n, 'levels': [{'maxKeys': mk, 'levels': h} for mk, h in caps.items()]}

    n, mk, step, probe = fx['experiment']
    big = BTree(mk)
    for i in range(n):
        big.insert(i * step % n)
    check(big)
    found, path, seen = big.search(probe)
    bst = stats(big)
    out.append(f"experiment: {n} keys, max_keys {mk} -> height {bst['height']}, nodes {bst['nodes']}, "
               f"search {probe} {'found' if found else 'not found'}, nodes read {len(path)}, compared {len(seen)}")
    trace['experiment'] = {'n': n, 'maxKeys': mk, 'step': step, 'search': probe, 'found': found, 'nodesRead': len(path), 'compared': len(seen), **bst}

    text = '\n'.join(out) + '\n'
    if trace_path:
        trace['stdout'] = text.splitlines()
        with open(trace_path, 'w', encoding='utf-8') as f:
            json.dump(trace, f, ensure_ascii=False, indent=1)
            f.write('\n')
    return text


if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    trace_path = sys.argv[sys.argv.index('--trace') + 1] if '--trace' in sys.argv else None
    sys.stdout.write(run(sys.argv[1], trace_path))
