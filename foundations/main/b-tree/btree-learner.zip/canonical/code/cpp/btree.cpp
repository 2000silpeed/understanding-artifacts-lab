// B-tree: several sorted keys in one node, search and insert (split on overflow). C++17, no dependencies.
// Same algorithm and the same printed lesson run as ../python/btree.py (tests/test_btree.py diffs the two).
//   c++ -std=c++17 -O2 -Wall -Wextra -Werror btree.cpp -o btree && ./btree ../fixtures/lesson.txt
// The lines between `// [film:<name>]` and `// [film:end]` are shown on screen (≤ 48 columns).
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <memory>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

// [film:node]
struct Node {
  std::vector<int> keys;  // sorted
  std::vector<std::unique_ptr<Node>> kids;
  bool leaf() const { return kids.empty(); }
};
// [film:end]

using Up = std::optional<std::pair<int, std::unique_ptr<Node>>>;

struct SearchResult {
  bool found = false;
  std::vector<const Node*> path;
  std::vector<int> seen;
};

class BTree {
 public:
  explicit BTree(std::size_t maxKeys, std::function<void(const std::string&, int)> watch = nullptr)
      : maxKeys_(maxKeys), root_(std::make_unique<Node>()), watch_(std::move(watch)) {
    if (maxKeys < 2) throw std::invalid_argument("max_keys must be at least 2");
  }
  const Node* root() const { return root_.get(); }
  std::size_t maxKeys() const { return maxKeys_; }

  SearchResult search(int key) const {
    SearchResult r;
    const Node* node = root_.get();
    while (true) {
      r.path.push_back(node);
      std::size_t i = 0;
      while (i < node->keys.size()) {
        r.seen.push_back(node->keys[i]);
        if (key == node->keys[i]) { r.found = true; return r; }
        if (key < node->keys[i]) break;
        ++i;
      }
      if (node->leaf()) return r;
      node = node->kids[i].get();
    }
  }

  void insert(int key) {
    Up up = insert(root_.get(), key);
    if (up) {  // the root split
      auto top = std::make_unique<Node>();
      top->keys.push_back(up->first);
      top->kids.push_back(std::move(root_));
      top->kids.push_back(std::move(up->second));
      root_ = std::move(top);
      tell("new-root", up->first);
    }
  }

 private:
  // [film:insert]
  Up insert(Node* n, int key) {
    auto at = std::lower_bound(
        n->keys.begin(), n->keys.end(), key);
    std::size_t i = at - n->keys.begin();
    if (at != n->keys.end() && *at == key)
      return std::nullopt;  // already there
    if (n->leaf()) {
      n->keys.insert(at, key);
      tell("placed", key);
    } else {
      Up up = insert(n->kids[i].get(), key);
      if (!up) return std::nullopt;
      n->keys.insert(n->keys.begin() + i,
                     up->first);
      n->kids.insert(n->kids.begin() + i + 1,
                     std::move(up->second));
      tell("raised", up->first);
    }
    if (n->keys.size() > maxKeys_)
      return split(n);
    return std::nullopt;
  }
  // [film:end]

  Up split(Node* n) {
    std::size_t m = n->keys.size() / 2;
    int mid = n->keys[m];
    auto right = std::make_unique<Node>();
    right->keys.assign(n->keys.begin() + m + 1, n->keys.end());
    n->keys.resize(m);
    if (!n->leaf()) {
      for (std::size_t j = m + 1; j < n->kids.size(); ++j) right->kids.push_back(std::move(n->kids[j]));
      n->kids.resize(m + 1);
    }
    return std::make_pair(mid, std::move(right));
  }

  void tell(const std::string& event, int key) {
    if (watch_) watch_(event, key);
  }

  std::size_t maxKeys_;
  std::unique_ptr<Node> root_;
  std::function<void(const std::string&, int)> watch_;
};

// ---------- views (same text as the Python version) ----------

static std::vector<std::vector<const Node*>> levels(const Node* root) {
  std::vector<std::vector<const Node*>> out;
  std::vector<const Node*> row{root};
  while (!row.empty()) {
    out.push_back(row);
    std::vector<const Node*> next;
    for (const Node* n : row)
      for (const auto& c : n->kids) next.push_back(c.get());
    row = std::move(next);
  }
  return out;
}

static std::string bracket(const Node* n) {
  std::string s = "[";
  for (std::size_t i = 0; i < n->keys.size(); ++i) s += (i ? " " : "") + std::to_string(n->keys[i]);
  return s + "]";
}

static std::string show(const Node* root) {
  std::string s;
  bool firstRow = true;
  for (const auto& row : levels(root)) {
    if (!firstRow) s += " / ";
    firstRow = false;
    for (std::size_t i = 0; i < row.size(); ++i) s += (i ? " " : "") + bracket(row[i]);
  }
  return s;
}

static bool overflowing(const BTree& t) {
  for (const auto& row : levels(t.root()))
    for (const Node* n : row)
      if (n->keys.size() > t.maxKeys()) return true;
  return false;
}

struct Stats { std::size_t height = 0, nodes = 0, keys = 0; };
static Stats stats(const BTree& t) {
  Stats s;
  for (const auto& row : levels(t.root())) {
    ++s.height;
    s.nodes += row.size();
    for (const Node* n : row) s.keys += n->keys.size();
  }
  return s;
}

static int levelsNeeded(std::int64_t n, std::int64_t maxKeys) {
  int h = 0;
  std::int64_t cap = 0, pow = 1;
  while (cap < n) {
    ++h;
    pow *= maxKeys + 1;
    cap = pow - 1;
  }
  return h;
}

static std::string joinInts(const std::vector<int>& v) {
  std::string s;
  for (std::size_t i = 0; i < v.size(); ++i) s += (i ? " " : "") + std::to_string(v[i]);
  return s;
}

int main(int argc, char** argv) {
  if (argc < 2) {
    std::cerr << "usage: btree <fixture.txt>\n";
    return 2;
  }
  std::ifstream in(argv[1]);
  if (!in) {
    std::cerr << "cannot open " << argv[1] << "\n";
    return 2;
  }
  std::map<std::string, std::vector<std::int64_t>> fx;
  for (std::string line; std::getline(in, line);) {
    line = line.substr(0, line.find('#'));
    std::istringstream ss(line);
    std::string name;
    if (!(ss >> name)) continue;
    std::vector<std::int64_t> nums;
    for (std::int64_t x; ss >> x;) nums.push_back(x);
    fx[name] = nums;
  }

  const std::size_t maxKeys = static_cast<std::size_t>(fx.at("max_keys").at(0));
  std::cout << "max_keys " << maxKeys << "\n";
  BTree* self = nullptr;
  std::vector<std::string> events;
  BTree tree(maxKeys, [&](const std::string& e, int k) {
    events.push_back("  " + e + " " + std::to_string(k) + ": " + show(self->root()) + (overflowing(*self) ? "  (overflow)" : ""));
  });
  self = &tree;
  for (std::int64_t key : fx.at("insert")) {
    events.clear();
    tree.insert(static_cast<int>(key));
    std::cout << "insert " << key << "\n";
    for (const auto& e : events) std::cout << e << "\n";
  }
  for (std::int64_t key : fx.at("search")) {
    SearchResult r = tree.search(static_cast<int>(key));
    std::string route;
    for (std::size_t i = 0; i < r.path.size(); ++i) route += (i ? " > " : "") + bracket(r.path[i]);
    std::cout << "search " << key << ": " << (r.found ? "found" : "not found") << ", path " << route << ", compared "
              << joinInts(r.seen) << " (" << r.seen.size() << ")\n";
  }
  Stats st = stats(tree);
  std::cout << "tree height " << st.height << ", nodes " << st.nodes << ", keys " << st.keys << "\n";

  const auto& cap = fx.at("capacity");
  std::cout << "levels for " << cap[0] << " keys (full nodes): ";
  for (std::size_t i = 1; i < cap.size(); ++i)
    std::cout << (i > 1 ? ", " : "") << "max_keys " << cap[i] << " -> " << levelsNeeded(cap[0], cap[i]);
  std::cout << "\n";

  const auto& ex = fx.at("experiment");
  const std::int64_t n = ex[0], step = ex[2];
  BTree big(static_cast<std::size_t>(ex[1]));
  for (std::int64_t i = 0; i < n; ++i) big.insert(static_cast<int>(i * step % n));
  SearchResult r = big.search(static_cast<int>(ex[3]));
  Stats bs = stats(big);
  std::cout << "experiment: " << n << " keys, max_keys " << ex[1] << " -> height " << bs.height << ", nodes " << bs.nodes
            << ", search " << ex[3] << " " << (r.found ? "found" : "not found") << ", nodes read " << r.path.size()
            << ", compared " << r.seen.size() << "\n";
  return 0;
}
