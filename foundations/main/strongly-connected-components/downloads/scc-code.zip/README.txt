이 ZIP은 authored lesson의 실행 가능한 SCC 입력과 Python/C++17 예제 사본입니다.
