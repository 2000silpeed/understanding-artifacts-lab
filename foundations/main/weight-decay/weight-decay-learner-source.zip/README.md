# Weight decay 학습자 source

이 ZIP은 영상 실습의 Python/C++17 예제와 TODO를 그대로 실행해 보는 작은 연습장입니다.

## 빠른 실행

```bash
python3 example/decay.py run --data example/fixtures/two_weights.csv --opt adam --l2 0.1 --lr 0.001 --steps 1000
mkdir -p build
c++ -std=c++17 -O2 -ffp-contract=off -Wall -Wextra -o build/decay example/decay.cpp
./build/decay run --data example/fixtures/two_weights.csv --opt adam --decoupled 0.1 --lr 0.001 --steps 1000
```

## TODO 실습

`practice/decay_practice.py` 또는 `practice/decay_practice.cpp`의 TODO 두 곳을 채운 뒤 확인합니다.

```bash
python3 practice/check_practice.py practice/decay_practice.py
python3 practice/check_practice.py --cpp practice/decay_practice.cpp
```

정답 파일은 `practice/solutions/`에 있습니다. λ·w를 기울기에 넣는 위치와, 기울기와 분리해 w를 먼저 줄이는 위치를 비교해 보세요. A의 grad_scale은 10, B는 0.001이라 같은 λ도 Adam + L2에서 다르게 보일 수 있습니다.

주의: 예제의 표준 출력은 JSON입니다. 표시 자릿수에 따른 반올림과 실제 계산값을 구분하세요.
