"""실습: Adam에 가중치 감쇠를 두 가지 방식으로 넣어 본다 (L2 규제 / 분리된 감쇠 = AdamW).

TODO 두 곳을 채우고 확인한다:
    python3 films/weight-decay-20261109/practice/check_practice.py
Adam의 m, v, 편향 보정은 앞 강의에서 만든 그대로 적어 두었다. 여기서는 감쇠가 들어가는 자리만 고른다.
영상의 숫자(1000걸음 뒤 Adam + L2: A 0.99 / B 0.26, AdamW: A 0.90 / B 0.90)가 그대로 나오면 성공이다.
다 되면 이 파일을 직접 실행해 λ와 기울기 크기를 바꿔 보자: python3 films/weight-decay-20261109/practice/decay_practice.py
"""
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'example'))
from decay import data_grad, load  # noqa: E402  (예제의 데이터 읽기와 데이터 기울기)

FIXTURE = Path(__file__).resolve().parents[1] / 'example' / 'fixtures' / 'two_weights.csv'


class MyAdam:
    """l2 > 0 이면 L2 규제(torch.optim.Adam의 weight_decay), decoupled > 0 이면 분리된 감쇠(torch.optim.AdamW의 weight_decay)."""

    def __init__(self, lr=0.001, l2=0.0, decoupled=0.0, beta1=0.9, beta2=0.999, eps=1e-8):
        self.lr, self.l2, self.dec = lr, l2, decoupled
        self.b1, self.b2, self.eps = beta1, beta2, eps
        self.m, self.v, self.t = [0.0, 0.0], [0.0, 0.0], 0

    def step(self, w, g_data):
        """새 가중치를 돌려준다. g_data는 데이터 손실의 기울기다."""
        self.t += 1
        new = list(w)
        for i in range(len(w)):
            # TODO 1: L2 규제. 옵티마이저가 볼 기울기 g를 만든다: 데이터 기울기에 λ·w를 더한다 (λ = self.l2, w = w[i]).
            raise NotImplementedError('TODO 1: L2 규제 기울기')
            # TODO 2: 분리된 감쇠. 기울기와 따로, 가중치를 먼저 (1 − lr·λ)배로 줄인다 (λ = self.dec). self.dec가 0이면 그대로.
            #         new[i] = ...
            # (완성됨) Adam 걸음: m, v, 편향 보정. 감쇠가 어디로 들어갔는지에 따라 결과가 달라진다.
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g  # noqa: F821  (TODO 1에서 g를 만든다)
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * g * g  # noqa: F821
            m_hat = self.m[i] / (1 - self.b1 ** self.t)
            v_hat = self.v[i] / (1 - self.b2 ** self.t)
            new[i] = new[i] - self.lr * m_hat / (math.sqrt(v_hat) + self.eps)
        return new


def run(fixture=FIXTURE, steps=1000, **opt):
    """[(t, [w_A, w_B]), ...] for every step. opt: lr, l2, decoupled."""
    rows = load(fixture)
    w = [r['w0'] for r in rows]
    o = MyAdam(**opt)
    out = []
    for t in range(1, steps + 1):
        w = o.step(w, [data_grad(r['grad_scale'], t) for r in rows])
        out.append((t, w))
    return out


if __name__ == '__main__':
    # 바꿔 볼 것: λ(0.1 → 0.01), fixtures의 grad_scale(10 / 0.001), 걸음 수.
    for name, opt in [('Adam + L2 λ 0.1', {'l2': 0.1}), ('AdamW    λ 0.1', {'decoupled': 0.1}),
                      ('Adam + L2 λ 0.01', {'l2': 0.01}), ('AdamW    λ 0.01', {'decoupled': 0.01})]:
        w = run(**opt)[-1][1]
        print(f'{name}: 1000걸음 뒤 A {w[0]:.3f}  B {w[1]:.3f}')
