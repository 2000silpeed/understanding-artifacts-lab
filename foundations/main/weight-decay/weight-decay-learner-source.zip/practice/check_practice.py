"""실습 확인: 내 Adam + L2와 내 AdamW가 예제(example/results/*.py.json)와 걸음마다 같은지 본다.

usage:
  python3 films/weight-decay-20261109/practice/check_practice.py [내_파일.py]          # 기본: practice/decay_practice.py
  python3 films/weight-decay-20261109/practice/check_practice.py --cpp [내_파일.cpp]   # 기본: practice/decay_practice.cpp
λ = 0.1로 두 방식(L2 규제, 분리된 감쇠)을 모두 돌려, 처음 어긋나는 걸음과 어느 TODO를 보면 되는지 알려 준다.
맞으면 exit 0, 아니면 exit 1.
"""
import importlib.util
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILM = HERE.parent
RES = FILM / 'example' / 'results'
FIXTURE = FILM / 'example' / 'fixtures' / 'two_weights.csv'
LAM = 0.1
REF = {k: {row['t']: row['w'] for row in json.loads((RES / f'{name}.py.json').read_text(encoding='utf-8'))['trace']}
       for k, name in [('l2', 'adam_l2_0.1'), ('decoupled', 'adamw_0.1'), ('none', 'adam')]}
NAMES = ['A', 'B']


def close(a, b, tol=1e-9):
    return abs(a - b) <= tol * max(1.0, abs(b))


def same(rows, ref):
    return all(t in rows and all(close(rows[t][i], ref[t][i]) for i in range(2)) for t in ref)


def hint(mode, rows):
    other = 'decoupled' if mode == 'l2' else 'l2'
    if same(rows, REF['none']):
        return ('TODO 1: λ·w를 기울기에 더하지 않았습니다. 감쇠 없는 Adam과 같은 결과입니다.' if mode == 'l2'
                else 'TODO 2: 가중치를 (1 − lr·λ)배로 줄이지 않았습니다. 감쇠 없는 Adam과 같은 결과입니다.')
    if same(rows, REF[other]):
        return ('L2 자리에 분리된 감쇠가 들어갔습니다. L2는 λ·w를 기울기 g에 더해 m과 v로 보냅니다(TODO 1).' if mode == 'l2'
                else '감쇠를 기울기에 넣었습니다(L2). AdamW는 기울기와 따로, 먼저 w를 (1 − lr·λ)배로 줄입니다(TODO 2).')
    return 'TODO 1(g = g데이터 + λ·w)과 TODO 2(w ← w·(1 − lr·λ), 기울기와 따로)를 다시 보세요. 한 방식의 λ가 다른 방식에 새지 않는지도 보세요.'


def compare(mode, rows):
    ref = REF[mode]
    for t in sorted(ref):
        if t not in rows:
            return f'{t}번째 걸음 결과가 없습니다(1000걸음 필요).'
        for i in range(2):
            got, want = rows[t][i], ref[t][i]
            if not (isinstance(got, (int, float)) and math.isfinite(got) and close(got, want)):
                label = 'Adam + L2' if mode == 'l2' else 'AdamW'
                return f'{label}: {t}번째 걸음, 가중치 {NAMES[i]}: {got!r} (정답 {want!r}). {hint(mode, rows)}'
    return None


def check_py(path):
    spec = importlib.util.spec_from_file_location('learner', path)
    mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(Path(path).resolve().parent))
    try:
        spec.loader.exec_module(mod)
        for mode in ('l2', 'decoupled'):
            rows = {t: w for t, w in mod.run(FIXTURE, 1000, lr=0.001, **{mode: LAM})}
            err = compare(mode, rows)
            if err:
                return err
    except NotImplementedError as e:
        return f'아직 TODO가 남았습니다: {e}'
    return None


def check_cpp(path):
    cxx = shutil.which('c++') or shutil.which('clang++') or shutil.which('g++')
    if not cxx:
        return 'C++ 컴파일러(c++)가 없습니다.'
    with tempfile.TemporaryDirectory() as tmp:
        exe = Path(tmp) / 'learner'
        b = subprocess.run([cxx, '-std=c++17', '-O2', '-ffp-contract=off', '-Wall', '-Wextra', '-o', str(exe), str(path)], capture_output=True, text=True)
        if b.returncode:
            return '컴파일 실패:\n' + b.stderr[-1500:]
        for mode in ('l2', 'decoupled'):
            r = subprocess.run([str(exe), str(FIXTURE), mode, str(LAM)], capture_output=True, text=True)
            if r.returncode:
                return f'실행 실패(exit {r.returncode}): {r.stderr[-500:]}'
            rows = {}
            for line in r.stdout.split('\n'):
                if line.strip():
                    t, w0, w1 = line.split()
                    rows[int(t)] = [float(w0), float(w1)]
            err = compare(mode, rows)
            if err:
                return err
    return None


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    cpp = '--cpp' in argv
    rest = [a for a in argv if a != '--cpp']
    path = Path(rest[0]) if rest else HERE / ('decay_practice.cpp' if cpp else 'decay_practice.py')
    err = check_cpp(path) if cpp else check_py(path)
    if err:
        print('FAIL', path.name, '—', err)
        return 1
    l2, aw = REF['l2'][1000], REF['decoupled'][1000]
    print(f'PASS {path.name} — 1000걸음 모두 예제와 같습니다. Adam + L2: A {l2[0]:.2f} / B {l2[1]:.2f}, '
          f'AdamW: A {aw[0]:.2f} / B {aw[1]:.2f} (λ {LAM})')
    return 0


if __name__ == '__main__':
    sys.exit(main())
