// 실습(C++17): Adam에 가중치 감쇠를 두 가지 방식으로 넣는다. TODO 두 곳을 채우고 확인한다:
//   python3 films/weight-decay-20261109/practice/check_practice.py --cpp films/weight-decay-20261109/practice/decay_practice.cpp
// 데이터 읽기와 데이터 기울기는 예제의 decay_core.hpp를 그대로 쓴다.
// 실행: decay_practice <fixture.csv> <l2|decoupled> <lambda>   출력(걸음 1–3, 10걸음마다): t w_A w_B
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

#include "../example/decay_core.hpp"

struct MyAdam {
  double lr = 0.001, l2 = 0, dec = 0, b1 = 0.9, b2 = 0.999, eps = 1e-8;
  std::vector<double> m{0, 0}, v{0, 0};
  int t = 0;

  void step(std::vector<double>& w, const std::vector<double>& g_data) {
    ++t;
    for (std::size_t i = 0; i < w.size(); ++i) {
      // TODO 1: L2 규제 — 옵티마이저가 볼 기울기: g = g_data[i] + l2·w[i]
      const double g = g_data[i];
      // TODO 2: 분리된 감쇠 — 기울기와 따로, 먼저 w[i]를 (1 − lr·dec)배로 줄인다
      // (완성됨) Adam 걸음
      m[i] = b1 * m[i] + (1 - b1) * g;
      v[i] = b2 * v[i] + (1 - b2) * g * g;
      const double m_hat = m[i] / (1 - std::pow(b1, t));
      const double v_hat = v[i] / (1 - std::pow(b2, t));
      w[i] = w[i] - lr * m_hat / (std::sqrt(v_hat) + eps);
    }
  }
};

int main(int argc, char** argv) {
  const std::string data = argc > 1 ? argv[1] : "films/weight-decay-20261109/example/fixtures/two_weights.csv";
  const std::string mode = argc > 2 ? argv[2] : "l2";
  const double lam = argc > 3 ? std::stod(argv[3]) : 0.1;
  const auto rows = wdex::load(data);
  MyAdam opt;
  (mode == "l2" ? opt.l2 : opt.dec) = lam;
  std::vector<double> w, gd(rows.size());
  for (const auto& r : rows) w.push_back(r.w0);
  for (int t = 1; t <= 1000; ++t) {
    for (std::size_t i = 0; i < rows.size(); ++i) gd[i] = wdex::data_grad(rows[i].grad_scale, t);
    opt.step(w, gd);
    if (t <= 3 || t % 10 == 0) std::printf("%d %.17g %.17g\n", t, w[0], w[1]);
  }
  return 0;
}
