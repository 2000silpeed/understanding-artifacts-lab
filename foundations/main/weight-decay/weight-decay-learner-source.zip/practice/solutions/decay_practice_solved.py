"""정답: practice/decay_practice.py의 TODO 두 곳을 채운 것. 확인:
    python3 films/weight-decay-20261109/practice/check_practice.py films/weight-decay-20261109/practice/solutions/decay_practice_solved.py
"""
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'example'))
from decay import data_grad, load  # noqa: E402

FIXTURE = Path(__file__).resolve().parents[2] / 'example' / 'fixtures' / 'two_weights.csv'


class MyAdam:
    def __init__(self, lr=0.001, l2=0.0, decoupled=0.0, beta1=0.9, beta2=0.999, eps=1e-8):
        self.lr, self.l2, self.dec = lr, l2, decoupled
        self.b1, self.b2, self.eps = beta1, beta2, eps
        self.m, self.v, self.t = [0.0, 0.0], [0.0, 0.0], 0

    def step(self, w, g_data):
        self.t += 1
        new = list(w)
        for i in range(len(w)):
            g = g_data[i] + self.l2 * w[i]                 # TODO 1: L2 — the penalty's gradient joins the data gradient
            new[i] = new[i] * (1 - self.lr * self.dec)     # TODO 2: decoupled — shrink first, outside the gradient
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * g * g
            m_hat = self.m[i] / (1 - self.b1 ** self.t)
            v_hat = self.v[i] / (1 - self.b2 ** self.t)
            new[i] = new[i] - self.lr * m_hat / (math.sqrt(v_hat) + self.eps)
        return new


def run(fixture=FIXTURE, steps=1000, **opt):
    rows = load(fixture)
    w = [r['w0'] for r in rows]
    o = MyAdam(**opt)
    out = []
    for t in range(1, steps + 1):
        w = o.step(w, [data_grad(r['grad_scale'], t) for r in rows])
        out.append((t, w))
    return out
