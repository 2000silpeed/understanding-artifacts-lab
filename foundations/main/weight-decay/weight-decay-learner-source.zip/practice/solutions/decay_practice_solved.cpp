// 정답(C++17): practice/decay_practice.cpp의 TODO 두 곳을 채운 것. 확인:
//   python3 films/weight-decay-20261109/practice/check_practice.py --cpp films/weight-decay-20261109/practice/solutions/decay_practice_solved.cpp
// 실행: decay_practice_solved <fixture.csv> <l2|decoupled> <lambda>   출력(걸음 1–3, 10걸음마다): t w_A w_B
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

#include "../../example/decay_core.hpp"

struct MyAdam {
  double lr = 0.001, l2 = 0, dec = 0, b1 = 0.9, b2 = 0.999, eps = 1e-8;
  std::vector<double> m{0, 0}, v{0, 0};
  int t = 0;

  void step(std::vector<double>& w, const std::vector<double>& g_data) {
    ++t;
    for (std::size_t i = 0; i < w.size(); ++i) {
      const double g = g_data[i] + l2 * w[i];  // TODO 1: L2 — the penalty's gradient joins the data gradient
      w[i] = w[i] * (1 - lr * dec);            // TODO 2: decoupled — shrink first, outside the gradient
      m[i] = b1 * m[i] + (1 - b1) * g;
      v[i] = b2 * v[i] + (1 - b2) * g * g;
      const double m_hat = m[i] / (1 - std::pow(b1, t));
      const double v_hat = v[i] / (1 - std::pow(b2, t));
      w[i] = w[i] - lr * m_hat / (std::sqrt(v_hat) + eps);
    }
  }
};

int main(int argc, char** argv) {
  const std::string data = argc > 1 ? argv[1] : "films/weight-decay-20261109/example/fixtures/two_weights.csv";
  const std::string mode = argc > 2 ? argv[2] : "l2";
  const double lam = argc > 3 ? std::stod(argv[3]) : 0.1;
  const auto rows = wdex::load(data);
  MyAdam opt;
  (mode == "l2" ? opt.l2 : opt.dec) = lam;
  std::vector<double> w, gd(rows.size());
  for (const auto& r : rows) w.push_back(r.w0);
  for (int t = 1; t <= 1000; ++t) {
    for (std::size_t i = 0; i < rows.size(); ++i) gd[i] = wdex::data_grad(rows[i].grad_scale, t);
    opt.step(w, gd);
    if (t <= 3 || t % 10 == 0) std::printf("%d %.17g %.17g\n", t, w[0], w[1]);
  }
  return 0;
}
