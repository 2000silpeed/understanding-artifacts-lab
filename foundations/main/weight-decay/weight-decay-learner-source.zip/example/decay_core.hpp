// L2 regularization vs decoupled weight decay (C++17, standard library only). Same rules and the same order of
// floating-point operations as decay.py; build with -ffp-contract=off so a*b+c is never fused.
//   L2:        g = g_data + l2·w, then the optimizer step on g          (torch.optim.Adam weight_decay)
//   decoupled: w ← w·(1 − lr·dec), then the optimizer step on g_data    (torch.optim.AdamW weight_decay)
#pragma once
#include <cmath>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace wdex {

struct Weight {
  std::string name;
  double w0 = 0, grad_scale = 0;
};

// Fixture: lines starting with '#' are notes; header "name,w0,grad_scale".
inline std::vector<Weight> load(const std::string& path) {
  std::ifstream in(path);
  if (!in) throw std::runtime_error("cannot open " + path);
  std::vector<Weight> rows;
  std::string line;
  bool header = true;
  while (std::getline(in, line)) {
    if (line.empty() || line[0] == '#') continue;
    if (header) { header = false; continue; }
    std::stringstream ss(line);
    std::string name, w0, gs;
    std::getline(ss, name, ',');
    std::getline(ss, w0, ',');
    std::getline(ss, gs, ',');
    rows.push_back({name, std::stod(w0), std::stod(gs)});
  }
  if (rows.empty()) throw std::runtime_error("no rows in " + path);
  return rows;
}

// +scale on odd steps, −scale on even steps (mean 0).
inline double data_grad(double scale, int t) { return t % 2 == 1 ? scale : -scale; }

struct Info {
  double g = 0, decay = 0, sqrt_v_hat = 0;
};

struct Optimizer {
  bool adam = true;
  double lr = 1e-3, l2 = 0, dec = 0, b1 = 0.9, b2 = 0.999, eps = 1e-8;
  std::vector<double> m, v;
  int t = 0;

  Optimizer(bool adam_, double lr_, std::size_t n, double l2_, double dec_)
      : adam(adam_), lr(lr_), l2(l2_), dec(dec_), m(n, 0.0), v(n, 0.0) {}

  // Updates w in place; info[i] gets the gradient the optimizer saw, the decoupled shrink and √v̂.
  void step(std::vector<double>& w, const std::vector<double>& g_data, std::vector<Info>& info) {
    ++t;
    info.assign(w.size(), Info{});
    for (std::size_t i = 0; i < w.size(); ++i) {
      const double g = g_data[i] + l2 * w[i];
      info[i].g = g;
      if (dec != 0.0) {
        const double shrunk = w[i] * (1 - lr * dec);
        info[i].decay = w[i] - shrunk;
        w[i] = shrunk;
      }
      if (!adam) {
        w[i] = w[i] - lr * g;
      } else {
        m[i] = b1 * m[i] + (1 - b1) * g;
        v[i] = b2 * v[i] + (1 - b2) * g * g;
        const double m_hat = m[i] / (1 - std::pow(b1, t));
        const double v_hat = v[i] / (1 - std::pow(b2, t));
        info[i].sqrt_v_hat = std::sqrt(v_hat);
        w[i] = w[i] - lr * m_hat / (std::sqrt(v_hat) + eps);
      }
    }
  }
};

}  // namespace wdex
