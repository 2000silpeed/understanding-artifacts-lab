"""L2 regularization vs decoupled weight decay, with SGD and Adam — the reference example of films/weight-decay-20261109.

Two weights (fixtures/two_weights.csv) start at 1. Their data-loss gradient flips sign every step (two-step arithmetic mean 0). That cancels the data term for plain SGD, but Adam's momentum and adaptive update can still move the weights, so compare any shrinkage with the no-decay baseline. A's data gradient is large (10), B's tiny (0.001).

Two ways to add weight decay λ, written as in PyTorch 2.15 (torch.optim.Adam / torch.optim.AdamW docs):
  L2 regularization (Adam's `weight_decay`):  loss + λ·w²/2  →  g = g_data + λ·w, and g goes through the optimizer
  decoupled decay  (AdamW's `weight_decay`):  w ← w·(1 − lr·λ) first, then the optimizer step on g_data only
SGD:  w ← w − lr·g
Adam (t from 1): m = β1·m + (1 − β1)·g;  v = β2·v + (1 − β2)·g²;  m̂ = m / (1 − β1^t);  v̂ = v / (1 − β2^t)
                 w ← w − lr·m̂ / (√v̂ + ε)
With SGD the two are the same update (rearranged). With Adam, the L2 term λ·w is divided by √v̂ with the rest of the
gradient: decay is weak where gradients are large (A) and strong where they are tiny (B), almost whatever λ is.

usage (stdout is JSON; nothing else is printed):
    python3 decay.py run --data fixtures/two_weights.csv --opt adam --l2 0.1 --lr 0.001 --steps 1000
    python3 decay.py run --data fixtures/two_weights.csv --opt adam --decoupled 0.1 --lr 0.001 --steps 1000   # AdamW
    python3 decay.py run --data fixtures/two_weights.csv --opt sgd --l2 0.1 --lr 0.001 --steps 1000
Standard library only (Python 3.9+).
"""
import argparse
import csv
import json
import math
import sys
from pathlib import Path


def load(path):
    """Read the fixture (lines starting with # are notes) → [{'name', 'w0', 'grad_scale'}]."""
    lines = [line for line in Path(path).read_text(encoding='utf-8').splitlines() if line and not line.startswith('#')]
    rows = [{'name': r['name'], 'w0': float(r['w0']), 'grad_scale': float(r['grad_scale'])} for r in csv.DictReader(lines)]
    if not rows:
        raise SystemExit(f'no rows in {path}')
    return rows


def data_grad(scale, t):
    """Gradient of the data loss at step t: +scale on odd steps, −scale on even steps (two-step arithmetic mean 0; this does not imply zero Adam update)."""
    return scale if t % 2 == 1 else -scale


class Optimizer:
    """SGD or Adam, with L2 regularization (`l2`) and/or decoupled weight decay (`decoupled`), per parameter."""

    def __init__(self, opt, lr, n, l2=0.0, decoupled=0.0, beta1=0.9, beta2=0.999, eps=1e-8):
        if opt not in ('sgd', 'adam'):
            raise ValueError(opt)
        self.opt, self.lr, self.l2, self.dec = opt, lr, l2, decoupled
        self.b1, self.b2, self.eps = beta1, beta2, eps
        self.m, self.v, self.t = [0.0] * n, [0.0] * n, 0

    def step(self, w, g_data):
        """One step → (new w, per-parameter info). `g` is the gradient the optimizer sees (data + L2 term)."""
        self.t += 1
        new, info = list(w), []
        for i in range(len(w)):
            g = g_data[i] + self.l2 * w[i]                      # L2: the penalty's gradient joins the data gradient
            row = {'g': g, 'decay': 0.0}
            if self.dec:                                       # decoupled: shrink first, outside the gradient
                shrunk = new[i] * (1 - self.lr * self.dec)
                row['decay'] = new[i] - shrunk
                new[i] = shrunk
            if self.opt == 'sgd':
                new[i] = new[i] - self.lr * g
            else:
                self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g
                self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * g * g
                m_hat = self.m[i] / (1 - self.b1 ** self.t)
                v_hat = self.v[i] / (1 - self.b2 ** self.t)
                row['sqrt_v_hat'] = math.sqrt(v_hat)
                new[i] = new[i] - self.lr * m_hat / (math.sqrt(v_hat) + self.eps)
            info.append(row)
        return new, info


def traced(t, steps):
    return t <= 3 or t % 10 == 0 or t == steps


def run(data, opt, lr, steps, l2=0.0, decoupled=0.0):
    rows = load(data)
    w = [r['w0'] for r in rows]
    o = Optimizer(opt, lr, len(w), l2=l2, decoupled=decoupled)
    trace = []
    for t in range(1, steps + 1):
        w, info = o.step(w, [data_grad(r['grad_scale'], t) for r in rows])
        if traced(t, steps):
            row = {'t': t, 'w': w, 'g': [x['g'] for x in info], 'decay': [x['decay'] for x in info]}
            if opt == 'adam':
                row['sqrt_v_hat'] = [x['sqrt_v_hat'] for x in info]
            trace.append(row)
    return {
        'config': {'opt': opt, 'lr': lr, 'steps': steps, 'l2': l2, 'decoupled': decoupled,
                   'beta1': o.b1, 'beta2': o.b2, 'eps': o.eps, 'trace': 't <= 3, every 10th step, last step'},
        'weights': rows,
        'final': {'w': w},
        'trace': trace,
    }


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    sub = p.add_subparsers(dest='cmd', required=True)
    r = sub.add_parser('run')
    r.add_argument('--data', required=True)
    r.add_argument('--opt', choices=['sgd', 'adam'], required=True)
    r.add_argument('--lr', type=float, required=True)
    r.add_argument('--steps', type=int, default=1000)
    r.add_argument('--l2', type=float, default=0.0, help='L2 regularization: λ·w added to the gradient (torch.optim.Adam weight_decay)')
    r.add_argument('--decoupled', type=float, default=0.0, help='decoupled decay: w ← w·(1 − lr·λ) (torch.optim.AdamW weight_decay)')
    a = p.parse_args(argv)
    json.dump(run(a.data, a.opt, a.lr, a.steps, l2=a.l2, decoupled=a.decoupled), sys.stdout)
    sys.stdout.write('\n')


if __name__ == '__main__':
    main()
