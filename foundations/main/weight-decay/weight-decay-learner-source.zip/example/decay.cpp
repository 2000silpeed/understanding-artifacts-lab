// C++17 twin of decay.py: same command line, same JSON fields (numbers printed with %.17g, so they round-trip).
//   c++ -std=c++17 -O2 -ffp-contract=off -Wall -Wextra -o build/decay decay.cpp
//   build/decay run --data fixtures/two_weights.csv --opt adam --l2 0.1 --lr 0.001 --steps 1000
//   build/decay run --data fixtures/two_weights.csv --opt adam --decoupled 0.1 --lr 0.001 --steps 1000   (AdamW)
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "decay_core.hpp"

namespace {

void num(double x) { std::printf("%.17g", x); }

void vec(const std::vector<double>& xs) {
  std::printf("[");
  for (std::size_t i = 0; i < xs.size(); ++i) {
    if (i) std::printf(", ");
    num(xs[i]);
  }
  std::printf("]");
}

int usage() {
  std::fprintf(stderr, "usage: decay run --data FILE --opt sgd|adam --lr LR [--steps N] [--l2 L] [--decoupled L]\n");
  return 2;
}

}  // namespace

int main(int argc, char** argv) {
  if (argc < 2 || std::strcmp(argv[1], "run") != 0) return usage();
  std::string data, opt;
  double lr = -1, l2 = 0, dec = 0;
  int steps = 1000;
  for (int i = 2; i + 1 < argc; i += 2) {
    const std::string k = argv[i], v = argv[i + 1];
    if (k == "--data") data = v;
    else if (k == "--opt") opt = v;
    else if (k == "--lr") lr = std::stod(v);
    else if (k == "--steps") steps = std::stoi(v);
    else if (k == "--l2") l2 = std::stod(v);
    else if (k == "--decoupled") dec = std::stod(v);
    else return usage();
  }
  if (data.empty() || (opt != "sgd" && opt != "adam") || lr < 0) return usage();

  std::vector<wdex::Weight> rows;
  try {
    rows = wdex::load(data);
  } catch (const std::exception& e) {
    std::fprintf(stderr, "%s\n", e.what());
    return 1;
  }
  std::vector<double> w, gd(rows.size()), col(rows.size());
  for (const auto& r : rows) w.push_back(r.w0);
  wdex::Optimizer o(opt == "adam", lr, w.size(), l2, dec);
  std::vector<wdex::Info> info;

  std::printf("{\"config\": {\"opt\": \"%s\", \"lr\": ", opt.c_str());
  num(lr);
  std::printf(", \"steps\": %d, \"l2\": ", steps);
  num(l2);
  std::printf(", \"decoupled\": ");
  num(dec);
  std::printf(", \"beta1\": ");
  num(o.b1);
  std::printf(", \"beta2\": ");
  num(o.b2);
  std::printf(", \"eps\": ");
  num(o.eps);
  std::printf(", \"trace\": \"t <= 3, every 10th step, last step\"}, \"weights\": [");
  for (std::size_t i = 0; i < rows.size(); ++i) {
    std::printf("%s{\"name\": \"%s\", \"w0\": ", i ? ", " : "", rows[i].name.c_str());
    num(rows[i].w0);
    std::printf(", \"grad_scale\": ");
    num(rows[i].grad_scale);
    std::printf("}");
  }
  std::printf("], \"trace\": [");
  bool first = true;
  for (int t = 1; t <= steps; ++t) {
    for (std::size_t i = 0; i < rows.size(); ++i) gd[i] = wdex::data_grad(rows[i].grad_scale, t);
    o.step(w, gd, info);
    if (!(t <= 3 || t % 10 == 0 || t == steps)) continue;
    std::printf("%s{\"t\": %d, \"w\": ", first ? "" : ", ", t);
    first = false;
    vec(w);
    for (std::size_t i = 0; i < rows.size(); ++i) col[i] = info[i].g;
    std::printf(", \"g\": ");
    vec(col);
    for (std::size_t i = 0; i < rows.size(); ++i) col[i] = info[i].decay;
    std::printf(", \"decay\": ");
    vec(col);
    if (o.adam) {
      for (std::size_t i = 0; i < rows.size(); ++i) col[i] = info[i].sqrt_v_hat;
      std::printf(", \"sqrt_v_hat\": ");
      vec(col);
    }
    std::printf("}");
  }
  std::printf("], \"final\": {\"w\": ");
  vec(w);
  std::printf("}}\n");
  return 0;
}
