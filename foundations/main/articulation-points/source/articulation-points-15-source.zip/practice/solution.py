"""실습 정답 — 다리(bridge) 찾기. 강의의 단절점 코드에서 판정 한 줄만 바뀐다.

단절점: 자식 v가 low[v] >= disc[u]  → u를 지우면 v의 서브트리가 떨어진다.
다리:   자식 v가 low[v] >  disc[u]  → 간선 u-v를 지우면 v의 서브트리가 떨어진다.
        (같으면 v의 서브트리에서 u로 돌아오는 다른 간선이 있으니 u-v가 없어도 이어져 있다.)
루트 규칙은 다리에는 필요 없다. 겹친 간선(0-1이 두 개)은 다리가 아니므로 부모는 정점이 아니라 간선 번호로 건너뛴다.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'code'))
from articulation import build_adj  # noqa: E402


def bridges(n, edges):
    adj = build_adj(n, edges)
    disc, low = [-1] * n, [0] * n
    found, timer = [], 0

    def dfs(u, parent_edge):
        nonlocal timer
        disc[u] = low[u] = timer
        timer += 1
        for v, e in adj[u]:
            if e == parent_edge:
                continue
            if disc[v] != -1:
                low[u] = min(low[u], disc[v])
            else:
                dfs(v, e)
                low[u] = min(low[u], low[v])
                if low[v] > disc[u]:      # 단절점과 다른 곳은 이 부등호 하나
                    found.append(tuple(sorted((u, v))))

    for s in range(n):
        if disc[s] == -1:
            dfs(s, -1)
    return sorted(found)
