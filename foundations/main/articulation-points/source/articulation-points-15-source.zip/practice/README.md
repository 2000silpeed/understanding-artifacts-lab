# 실습 — 알고리즘 15 · 단절점

영상 끝에서 안내하는 실습이다. 강의 코드(`../code/articulation.py`)와 같은 입력 형식·fixture를 쓴다.

## 1. 손으로 채우기 (5분)

정점 0에서 DFS를 시작하고, 이웃은 번호가 작은 것부터 방문한다. 빈칸에 disc와 low를 적고 단절점을 고른다.

**별 모양** (`../code/fixtures/star.txt`: 0-1, 0-2, 0-3)

| 정점 | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| disc | | | | |
| low | | | | |

**나비넥타이** (`../code/fixtures/bowtie.txt`: 삼각형 0-1-2와 삼각형 2-3-4가 정점 2를 공유)

| 정점 | 0 | 1 | 2 | 3 | 4 |
|---|---|---|---|---|---|
| disc | | | | | |
| low | | | | | |

확인: `python3 ../code/articulation.py ../code/fixtures/star.txt` (답은 맨 아래).

## 2. 규칙 두 줄 채우기 (10분)

`starter.py`의 `TODO 1`(비루트 규칙)과 `TODO 2`(루트 규칙)를 채운다.

```sh
python3 check.py starter      # PASS 16개면 통과 (단절점 8 + 다리 8). TODO가 남으면 exit 2
```

## 3. 다리 찾기 (15분)

간선 하나를 지웠을 때 그래프가 나뉘면 그 간선은 **다리(bridge)** 다. `starter.py`의 `TODO 3`에서 같은 DFS로 다리를 찾는다.

- 힌트: 단절점은 `low[v] >= disc[u]`. 다리는 등호 하나가 다르다. 같으면 v의 서브트리에서 u로 돌아오는 다른 간선이 있다는 뜻이다.
- 함정: `multi_edge.txt`처럼 0-1 간선이 두 개면 0-1은 다리가 아니다. 부모를 정점 번호가 아니라 **간선 번호**로 건너뛰어야 맞다.
- 정답: `solution.py` (`python3 check.py solution`으로 채점기 확인).

## 4. 더 해 보기

- `../code/articulation.py`의 `articulation_points_iterative`를 읽고, 재귀가 없는 버전이 왜 같은 disc/low를 내는지 설명해 보기(정점 100,000개 길 그래프로 테스트한다).
- 사내 네트워크(`network.txt`)에서 케이블 한 개만 더 놓아 단절점을 0개로 만들려면 어디를 이어야 하나? (`network.txt`를 복사해 간선을 더하고 실행해 확인. 답은 아래.)

## 답 (실행 기록)

```
$ python3 ../code/articulation.py ../code/fixtures/star.txt
graph: n=4 m=3
disc: 0 1 2 3
low:  0 1 2 3
articulation points: [0]

$ python3 ../code/articulation.py ../code/fixtures/bowtie.txt
graph: n=5 m=6
disc: 0 1 2 3 4
low:  0 0 0 2 2
articulation points: [2]
```

케이블 한 개로 단절점 0개: **0-6** 또는 **2-6** (가능한 28쌍 중 기존 간선을 뺀 모든 쌍을 실행해 찾은 두 개, `tests/test_articulation.py`가 확인). 둘 다 끝에 매달린 6에서 왼쪽 삼각형까지 우회로를 만들어, 어느 정점을 지워도 나머지가 이어지는 한 덩어리(이중 연결)가 된다. (모든 정점이 고리 위에 있다고 단절점이 없는 것은 아니다: 나비넥타이의 2를 보라.)
