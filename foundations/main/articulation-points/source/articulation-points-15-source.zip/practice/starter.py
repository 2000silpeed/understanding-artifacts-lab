"""실습 시작 파일. 빈칸(TODO)을 채운 뒤 `python3 check.py starter`로 확인한다.

과제 1: articulation_points — 강의의 판정 규칙 두 줄을 채운다(비루트 규칙, 루트 규칙).
과제 2: bridges — 같은 DFS에서 '간선을 지우면 끊기는 곳(다리)'을 찾는다. 단절점 규칙에서 부등호 하나가 바뀐다.
막히면 solution.py를 본다. 그래프 입력과 인접 리스트는 강의 코드(code/articulation.py)의 함수를 그대로 쓴다.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'code'))
from articulation import build_adj  # noqa: E402


def articulation_points(n, edges):
    adj = build_adj(n, edges)
    disc, low = [-1] * n, [0] * n
    cut, timer = set(), 0

    def dfs(u, parent_edge):
        nonlocal timer
        disc[u] = low[u] = timer
        timer += 1
        children = 0
        for v, e in adj[u]:
            if e == parent_edge:
                continue
            if disc[v] != -1:
                low[u] = min(low[u], disc[v])
            else:
                children += 1
                dfs(v, e)
                low[u] = min(low[u], low[v])
                # TODO 1: u가 루트가 아니고, 자식 v가 u 위로 올라갈 수 없으면 u를 cut에 넣는다.
                raise NotImplementedError('TODO 1: 비루트 판정 규칙')
        # TODO 2: u가 루트(parent_edge == -1)이면 언제 단절점인가?
        raise NotImplementedError('TODO 2: 루트 판정 규칙')

    for s in range(n):
        if disc[s] == -1:
            dfs(s, -1)
    return sorted(cut)


def bridges(n, edges):
    """(a, b) 튜플(a < b)의 정렬된 목록을 돌려준다."""
    # TODO 3: articulation_points의 DFS를 복사해, 트리 간선 u-v가 다리인 조건으로 바꾼다.
    raise NotImplementedError('TODO 3: 다리 찾기')
