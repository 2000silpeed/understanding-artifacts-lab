"""실습 채점기: fixtures 8개에서 단절점과 다리를 expected.json과 대조한다.

usage:
  python3 check.py starter     # 내가 채운 starter.py
  python3 check.py solution    # 정답 (다리만; 단절점은 강의 코드로 채점)
exit 0 = 모두 통과, 1 = 틀림, 2 = TODO가 남아 있음
"""
import importlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
CODE = HERE.parent / 'code'
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(CODE))
from articulation import read_graph, articulation_points as lecture_points  # noqa: E402


def main(argv):
    name = argv[1] if len(argv) > 1 else 'starter'
    mod = importlib.import_module(name)
    points_fn = getattr(mod, 'articulation_points', lecture_points)
    expected = json.loads((CODE / 'fixtures' / 'expected.json').read_text(encoding='utf-8'))
    fails, todo = 0, 0
    for fixture, want in expected.items():
        if fixture.startswith('$'):
            continue
        n, edges = read_graph(CODE / 'fixtures' / f'{fixture}.txt')
        for what, fn, target in (('단절점', points_fn, want['points']), ('다리', mod.bridges, [tuple(b) for b in want['bridges']])):
            try:
                got = fn(n, edges)
            except NotImplementedError as e:
                todo += 1
                print(f'TODO  {fixture:13s} {what}: {e}')
                continue
            ok = list(got) == list(target)
            fails += not ok
            print(f'{"PASS" if ok else "FAIL"}  {fixture:13s} {what}: {list(got)}' + ('' if ok else f'  (기대값 {target})'))
    print(f'결과: 실패 {fails}, TODO {todo}')
    return 2 if todo else (1 if fails else 0)


if __name__ == '__main__':
    sys.exit(main(sys.argv))
