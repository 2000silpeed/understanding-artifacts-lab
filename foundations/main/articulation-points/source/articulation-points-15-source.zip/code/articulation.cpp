// 단절점(articulation point) 찾기 — 알고리즘 강의 15의 C++17 예제.
// build: c++ -std=c++17 -O2 -Wall -Wextra -o articulation articulation.cpp
// run:   ./articulation fixtures/network.txt
// 입력은 articulation.py와 같다('#' 줄은 주석, "n m" 다음 m줄 "a b"). 인접 리스트를 (이웃, 간선 번호) 순으로
// 정렬하고 정점 0부터 DFS를 시작하므로 disc/low/단절점 출력이 Python 버전과 글자 단위로 같다.
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

struct Graph {
  int n = 0;
  std::vector<std::pair<int, int>> edges;
};

static Graph readGraph(const std::string& path) {
  std::ifstream in(path);
  if (!in) throw std::runtime_error("cannot open " + path);
  std::vector<long long> nums;
  std::string line;
  while (std::getline(in, line)) {
    auto first = line.find_first_not_of(" \t\r");
    if (first != std::string::npos && line[first] == '#') continue;
    std::istringstream ss(line);
    long long x;
    while (ss >> x) nums.push_back(x);
  }
  Graph g;
  g.n = static_cast<int>(nums.at(0));
  int m = static_cast<int>(nums.at(1));
  for (int i = 0; i < m; ++i) g.edges.emplace_back(static_cast<int>(nums.at(2 + 2 * i)), static_cast<int>(nums.at(3 + 2 * i)));
  return g;
}

struct Articulation {
  std::vector<std::vector<std::pair<int, int>>> adj;  // adj[u] = {(이웃 v, 간선 번호 e)}
  std::vector<int> disc, low;
  std::vector<bool> cut;
  int timer = 0;

  explicit Articulation(const Graph& g) : adj(g.n), disc(g.n, -1), low(g.n, 0), cut(g.n, false) {
    for (int i = 0; i < static_cast<int>(g.edges.size()); ++i) {
      auto [a, b] = g.edges[i];
      adj[a].emplace_back(b, i);
      if (a != b) adj[b].emplace_back(a, i);
    }
    for (auto& row : adj) std::sort(row.begin(), row.end());
    for (int s = 0; s < g.n; ++s)
      if (disc[s] == -1) dfs(s, -1);
  }

  void dfs(int u, int parentEdge) {
    disc[u] = low[u] = timer++;                 // 방문 번호
    int children = 0;
    for (auto [v, e] : adj[u]) {
      if (e == parentEdge) continue;            // 방금 타고 온 간선은 건너뛴다
      if (disc[v] != -1) {                      // 이미 방문: 뒤로 가는 간선
        low[u] = std::min(low[u], disc[v]);
      } else {                                  // 트리 간선: 자식으로 내려간다
        ++children;
        dfs(v, e);
        low[u] = std::min(low[u], low[v]);
        if (parentEdge != -1 && low[v] >= disc[u]) cut[u] = true;
      }
    }
    if (parentEdge == -1 && children >= 2) cut[u] = true;  // 루트: 자식이 둘 이상
  }
};

int main(int argc, char** argv) {
  if (argc < 2) {
    std::cerr << "usage: articulation <graph.txt>\n";
    return 2;
  }
  try {
    Graph g = readGraph(argv[1]);
    Articulation a(g);
    auto join = [](const std::vector<int>& xs, const char* sep) {
      std::string s;
      for (size_t i = 0; i < xs.size(); ++i) s += (i ? sep : "") + std::to_string(xs[i]);
      return s;
    };
    std::vector<int> points;
    for (int v = 0; v < g.n; ++v)
      if (a.cut[v]) points.push_back(v);
    std::cout << "graph: n=" << g.n << " m=" << g.edges.size() << "\n";
    std::cout << "disc: " << join(a.disc, " ") << "\n";
    std::cout << "low:  " << join(a.low, " ") << "\n";
    std::cout << "articulation points: [" << join(points, ", ") << "]\n";
  } catch (const std::exception& e) {
    std::cerr << e.what() << "\n";
    return 1;
  }
  return 0;
}
