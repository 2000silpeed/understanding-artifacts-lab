"""단절점(articulation point) 찾기 — 알고리즘 강의 15의 실행 예제.

usage:
  python3 articulation.py fixtures/network.txt            # disc, low, 단절점 (C++ 버전과 같은 출력)
  python3 articulation.py fixtures/network.txt --brute    # + 정점을 하나씩 지워 보는 완전 탐색과 확인 횟수
  python3 articulation.py --path 1000 --brute             # 정점 1,000개 길 그래프(영상의 비용 비교)

입력 형식: '#' 줄은 주석, 첫 줄 "n m", 이어서 m줄 "a b"(무방향 간선, 0-기준 정점 번호).
인접 리스트는 (이웃, 간선 번호) 순으로 정렬해 DFS 순서를 고정한다. C++ 버전도 같은 순서를 쓰므로 disc/low가 같다.
"""
import sys


def read_graph(path):
    nums = []
    with open(path, encoding='utf-8') as f:
        for line in f:
            if not line.strip().startswith('#'):
                nums += [int(x) for x in line.split()]
    n, m = nums[0], nums[1]
    edges = [(nums[2 + 2 * i], nums[3 + 2 * i]) for i in range(m)]
    return n, edges


def path_graph(n):
    return n, [(i, i + 1) for i in range(n - 1)]


def build_adj(n, edges):
    adj = [[] for _ in range(n)]
    for i, (a, b) in enumerate(edges):
        adj[a].append((b, i))
        if a != b:
            adj[b].append((a, i))
    for row in adj:
        row.sort()
    return adj


# [screen:begin] 영상의 코드 장면은 이 표시 사이를 그대로 보여 준다(film-data.json의 code.python).
def articulation_points(n, edges):
    adj = build_adj(n, edges)              # adj[u] = [(이웃 v, 간선 번호 e), ...]
    disc, low = [-1] * n, [0] * n
    cut, timer = set(), 0

    def dfs(u, parent_edge):
        nonlocal timer
        disc[u] = low[u] = timer           # 방문 번호
        timer += 1
        children = 0
        for v, e in adj[u]:
            if e == parent_edge:           # 방금 타고 온 간선은 건너뛴다
                continue
            if disc[v] != -1:              # 이미 방문: 뒤로 가는 간선
                low[u] = min(low[u], disc[v])
            else:                          # 트리 간선: 자식으로 내려간다
                children += 1
                dfs(v, e)
                low[u] = min(low[u], low[v])
                if parent_edge != -1 and low[v] >= disc[u]:
                    cut.add(u)             # 자식이 u 위로 못 올라감
        if parent_edge == -1 and children >= 2:
            cut.add(u)                     # 루트: 자식이 둘 이상

    for s in range(n):
        if disc[s] == -1:
            dfs(s, -1)
    return sorted(cut)
# [screen:end]


def articulation_points_iterative(n, edges):
    """재귀 없는 같은 알고리즘(정점이 많아도 파이썬 재귀 한도에 걸리지 않는다). (단절점, disc, low)를 돌려준다."""
    adj = build_adj(n, edges)
    disc, low = [-1] * n, [0] * n
    cut, timer = set(), 0
    for root in range(n):
        if disc[root] != -1:
            continue
        disc[root] = low[root] = timer
        timer += 1
        root_children = 0
        stack = [[root, -1, 0]]  # 정점, 타고 온 간선, 다음에 볼 이웃 위치
        while stack:
            top = stack[-1]
            u, pe, i = top
            if i < len(adj[u]):
                top[2] += 1
                v, e = adj[u][i]
                if e == pe:
                    continue
                if disc[v] != -1:
                    low[u] = min(low[u], disc[v])
                else:
                    disc[v] = low[v] = timer
                    timer += 1
                    if u == root:
                        root_children += 1
                    stack.append([v, e, 0])
            else:
                stack.pop()
                if stack:
                    p = stack[-1][0]
                    low[p] = min(low[p], low[u])
                    if p != root and low[u] >= disc[p]:
                        cut.add(p)
        if root_children >= 2:
            cut.add(root)
    return sorted(cut), disc, low


def count_components(n, adj, removed=-1, counter=None):
    """removed 정점을 뺀 연결 요소 수. counter[0]에 인접 간선 확인 횟수를 더한다."""
    seen = [False] * n
    comps = 0
    for s in range(n):
        if s == removed or seen[s]:
            continue
        comps += 1
        seen[s] = True
        queue = [s]
        while queue:
            u = queue.pop()
            for v, _ in adj[u]:
                if counter is not None:
                    counter[0] += 1
                if v != removed and not seen[v]:
                    seen[v] = True
                    queue.append(v)
    return comps


def brute_force(n, edges):
    """정의 그대로: 정점 v를 지웠을 때 연결 요소가 늘면 단절점. (단절점, 인접 간선 확인 횟수)."""
    adj = build_adj(n, edges)
    counter = [0]
    base = count_components(n, adj, -1, counter)
    points = [v for v in range(n) if count_components(n, adj, v, counter) > base]
    return points, counter[0]


def tarjan_checks(n, edges):
    """DFS 한 번이 확인하는 인접 간선 수: 인접 리스트 항목을 한 번씩 본다(자기 고리는 1, 나머지 간선은 2)."""
    return sum(len(row) for row in build_adj(n, edges))


def trace(n, edges):
    """영상용 DFS 기록: 방문 순서, 트리 간선, 뒤로 가는 간선, 끝나는 순서와 판정. 반복형과 같은 순서로 돈다."""
    adj = build_adj(n, edges)
    disc, low, parent = [-1] * n, [0] * n, [-1] * n
    timer, order, tree, back, finish, checks, roots = 0, [], [], [], [], [], []
    for root in range(n):
        if disc[root] != -1:
            continue
        roots.append({'root': root, 'children': 0})
        disc[root] = low[root] = timer
        timer += 1
        order.append(root)
        stack = [[root, -1, 0]]
        while stack:
            top = stack[-1]
            u, pe, i = top
            if i < len(adj[u]):
                top[2] += 1
                v, e = adj[u][i]
                if e == pe:
                    continue
                if disc[v] != -1:
                    if disc[v] < disc[u]:
                        back.append({'from': u, 'to': v, 'edge': e})
                    low[u] = min(low[u], disc[v])
                else:
                    disc[v] = low[v] = timer
                    timer += 1
                    parent[v] = u
                    order.append(v)
                    tree.append({'from': u, 'to': v, 'edge': e})
                    if u == root:
                        roots[-1]['children'] += 1
                    stack.append([v, e, 0])
            else:
                stack.pop()
                finish.append({'v': u, 'low': low[u]})
                if stack:
                    p = stack[-1][0]
                    low[p] = min(low[p], low[u])
                    if p != root:
                        checks.append({'parent': p, 'child': u, 'lowChild': low[u], 'discParent': disc[p], 'cut': low[u] >= disc[p]})
    points = sorted({c['parent'] for c in checks if c['cut']} | {r['root'] for r in roots if r['children'] >= 2})
    return {'disc': disc, 'low': low, 'parent': parent, 'order': order, 'tree': tree, 'back': back,
            'finish': finish, 'checks': checks, 'roots': roots, 'points': points}


def report(n, edges):
    points, disc, low = articulation_points_iterative(n, edges)
    return '\n'.join([f'graph: n={n} m={len(edges)}',
                      'disc: ' + ' '.join(map(str, disc)),
                      'low:  ' + ' '.join(map(str, low)),
                      'articulation points: [' + ', '.join(map(str, points)) + ']'])


def main(argv):
    if '--path' in argv:
        n, edges = path_graph(int(argv[argv.index('--path') + 1]))
    else:
        n, edges = read_graph(argv[1])
    if n <= 50:
        print(report(n, edges))
    else:
        print(f'graph: n={n} m={len(edges)}')
        print('articulation points: ' + str(len(articulation_points_iterative(n, edges)[0])) + ' vertices')
    if '--brute' in argv:
        points, checks = brute_force(n, edges)
        same = points == articulation_points_iterative(n, edges)[0]
        print(f'brute force: {len(points)} points, same={same}, adjacency checks={checks}')
        print(f'one DFS: adjacency checks={tarjan_checks(n, edges)}')


if __name__ == '__main__':
    main(sys.argv)
