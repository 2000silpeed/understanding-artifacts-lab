# 알고리즘 15 · 단절점 — source package

정점을 지우면 연결이 나뉘는 곳(단절점, articulation point)을 찾는 한국어 강의 영상의 **소스 패키지**. 흐름은 핵심 개념 요약 → 구체적인 사용 상황(사내 네트워크의 단일 장애 지점) → 본 강의(정의 → 완전 탐색 → DFS의 disc·low → 판정 규칙 → 루트 규칙 → 코드 → 비용 → 정리·실습).

상태: **소스만 작성했다.** TTS·음악 생성·렌더·브라우저·업로드는 실행하지 않았다. 내레이션 시각은 추정값이다. 독립 검수 전(`SOURCE_AUTHORED_NOT_INDEPENDENT`).

## 파일

| 경로 | 무엇 |
|---|---|
| `code/articulation.py` | Python 예제: 화면에 나오는 재귀 버전(`# [screen:begin]…[screen:end]`), 반복형, 완전 탐색, 영상용 trace, CLI |
| `code/articulation.cpp` | C++17 예제(같은 입력, 글자 단위로 같은 출력) |
| `code/fixtures/*.txt`, `expected.json` | 그래프 8개(본편 `network`, 루트 규칙 `star`, `cycle`, `path`, `bowtie`, `disconnected`, `multi_edge`, `single`)와 단절점·다리 기대값 |
| `code/export_film_data.py` → `film-data.json` | 영상이 그리는 모든 숫자·간선·코드 줄을 실제 실행에서 뽑는다(손으로 고치지 않는다) |
| `voice/lines.json` | 작성한 내레이션 원본: 장면별 `text`(대본), `tts`(한글 읽기), `cues`(그림이 기다리는 단어), `screen`(화면 문구), `facts` |
| `voice/script.md` | 녹음 전 검토용 장표/목소리 표(`plan.py`가 생성) |
| `plan.py` → `shots.json` → `shotlist.md` | 타이밍 플랜(대본 먼저, 마디 격자 + 단어 큐). `shotlist.md`는 `pipeline/shotlint.py`가 생성 |
| `film.js` | 네이티브 Canvas 연출(12장면, 16:9·9:16). `shots.json`·`film-data.json`·`voice/lines.json`만 읽는다 |
| `scenario.md` | 시나리오, 실행 값 표, 비트 시트, 디자인·연출 결정 |
| `practice/` | 실습: `starter.py`(TODO 3개), `solution.py`(다리 찾기), `check.py`(채점), `README.md`(손 계산 활동지와 답) |
| `tests/test_articulation.py` | 소스 테스트(fixture, 무작위 800개 대조, C++ 출력 일치, film-data 최신 여부, 내레이션 숫자 근거, 실습 채점) |
| `tests/film_smoke.mjs` | 브라우저 없이 `film.js`의 모든 장면을 목업 캔버스에 그려 예외·NaN·안전 영역(추정 글자 폭)·화면 문구 누락·탐색 결정성 확인 |
| `tests/record_runs.py` | 위 명령을 모두 실행해 `runs/*.txt`와 `qa/author-result.json`을 쓴다 |
| `runs/` | 실행 기록(명령, 출력, exit) |

## 다시 실행하기

worktree 루트에서:

```sh
python3 films/articulation-points-20261112/tests/record_runs.py     # 전체(아래 모두) + 기록 갱신
# 개별:
python3 films/articulation-points-20261112/code/articulation.py films/articulation-points-20261112/code/fixtures/network.txt --brute
c++ -std=c++17 -O2 -Wall -Wextra -o /tmp/articulation films/articulation-points-20261112/code/articulation.cpp && /tmp/articulation films/articulation-points-20261112/code/fixtures/network.txt
python3 films/articulation-points-20261112/tests/test_articulation.py -v
node films/articulation-points-20261112/tests/film_smoke.mjs        # esbuild: 이 worktree에 node_modules가 없으면 메인 체크아웃의 것을 읽기 전용으로 쓴다(ESBUILD=로 지정 가능)
python3 pipeline/shotlint.py articulation-points-20261112
```

`network.txt`를 바꾸면 `python3 code/export_film_data.py` → `voice/lines.json`의 숫자·문장 확인(`facts` 테스트가 어긋남을 잡는다) → `python3 plan.py` 순서로 다시 만든다.

## 다음 단계 (부모가 수행)

1. **소스 검수**(독립): 대본·숫자·코드·테스트.
2. **발음 확인**(사용자): `voice/script.md`의 발음 표 — 정점 번호 "영 번", disc "디스크".
3. **목소리 고르기와 녹음**(유료, 사용자 승인): 3–5개 목소리 한 줄 샘플 → 장면별 12개 파일을 `voice/v1/seg-XX-<scene>.mp3`로(`voice/lines.json`의 `tts`를 입력으로). 
4. **단어 시각**: Scribe 결과를 `voice/timings.json`(`{scene: {len, cues: {이름: 초}}}`, 큐 이름은 `lines.json`과 같게)에 넣고 `python3 plan.py` → `shots.json`의 `voice.recorded`를 `true`로 바꾸면 `film.js`가 내레이션 큐를 낸다.
5. **스틸 게이트**(사람 확인): `node pipeline/build.cjs articulation-points-20261112 && node pipeline/render.cjs articulation-points-20261112 --format 16x9 --stills` (9x16도). 실제 글꼴 폭으로 겹침·넘침 확인.
6. 전체 제작 `sh pipeline/make.sh articulation-points-20261112 16x9 9x16` → `verify.py` PASS → `shotlint.py --video` → `REVIEW.md`.

## 알려진 한계

- 내레이션 길이·단어 시각은 추정(0.16초/음절)이라 장면 길이(현재 259.2초)는 녹음 후 바뀐다.
- `tokens.json`에 고정폭(mono) 글꼴 역할이 없어 코드를 Pretendard(`text`)로 그린다. 들여쓰기는 숫자 0의 폭 단위로 맞추고 주석은 한 열로 정렬한다. 고정폭 역할 추가는 도구 작업(공유 토큰)이라 이 패키지에서는 하지 않았다.
- 스모크 테스트의 글자 폭은 추정이다. 실제 폭·겹침은 브라우저 스틸 게이트에서만 확인된다.
- 비용 장면의 DFS 막대는 실제 비율(1/1000)이면 1px 남짓이라 최소 선 두께(`stroke.bold`)로 그리고 숫자로 보인다.
