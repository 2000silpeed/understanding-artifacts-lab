"""실습 확인: 블록을 example/fixtures의 그래프 8개로 돌려 example/results의 정답과 비교한다.

usage:
  python3 films/biconnected-components-20261113/practice/check_practice.py                 # practice/bcc_practice.py
  python3 films/biconnected-components-20261113/practice/check_practice.py <file.py>
  python3 films/biconnected-components-20261113/practice/check_practice.py --cpp [<file.cpp>]  # practice/bcc_practice.cpp
블록은 간선 번호 집합으로 비교한다(블록 순서와 블록 안 간선 순서는 채점하지 않는다). 틀리면 흔한 실수를 짚어 준다.
Exit 0 = 모두 맞음, 1 = 틀림.
"""
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
EX = HERE.parent / 'example'
GRAPHS = ['network', 'triangle', 'path', 'bowtie', 'star', 'multi_edge', 'disconnected', 'single']
RESULT = {'network': 'net'}


def read_graph(path):
    rows = [[int(x) for x in ln.split('#', 1)[0].split()] for ln in path.read_text(encoding='utf-8').splitlines()]
    rows = [r for r in rows if r]
    return rows[0][0], [tuple(r) for r in rows[1:]]


def expected(name):
    res = json.loads((EX / 'results' / f'{RESULT.get(name, name)}.py.json').read_text(encoding='utf-8'))
    return [b['edges'] for b in res['blocks']]


def canon(blocks):
    return sorted(sorted(b) for b in blocks)


def run_py(path):
    spec = importlib.util.spec_from_file_location('practice_under_test', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    out = {}
    for name in GRAPHS:
        n, edges = read_graph(EX / 'fixtures' / f'{name}.txt')
        try:
            out[name] = [list(b) for b in mod.biconnected_blocks(n, edges)]
        except Exception as e:  # noqa: BLE001 — report any learner error as a failed graph
            out[name] = e
    return out


def run_cpp(path):
    cxx = next((c for c in ('c++', 'clang++', 'g++') if shutil.which(c)), None)
    if not cxx:
        raise SystemExit('C++ 컴파일러가 없습니다 (c++, clang++, g++)')
    with tempfile.TemporaryDirectory() as tmp:
        exe = Path(tmp) / 'bcc_practice'
        b = subprocess.run([cxx, '-std=c++17', '-O2', '-o', str(exe), str(path)], capture_output=True, text=True)
        if b.returncode != 0:
            print('컴파일 실패:\n' + b.stderr[-2000:])
            raise SystemExit(1)
        out = {}
        for name in GRAPHS:
            r = subprocess.run([str(exe), str(EX / 'fixtures' / f'{name}.txt')], capture_output=True, text=True)
            out[name] = RuntimeError(r.stderr.strip()) if r.returncode else [[int(x) for x in ln.split()] for ln in r.stdout.splitlines() if ln.strip()]
    return out


def hints(name, got, want, m):
    flat = [e for b in got for e in b]
    hs = []
    if len(flat) != len(set(flat)):
        hs.append('같은 간선이 두 번 나왔습니다: 자손 쪽 간선을 또 넣지 않았나요? 이미 방문한 이웃은 disc[w] < disc[u](조상 쪽)일 때만 넣습니다.')
    missing = sorted(set(range(m)) - set(flat))
    if missing and got:
        hs.append(f'어느 블록에도 없는 간선 {missing}: 꺼내는 조건이 low[w] >= disc[u]인지(같을 때도 꺼내는지) 확인하세요.')
    if not got and want:
        hs.append('블록이 하나도 없습니다: TODO 2(꺼내기)를 채웠나요?')
    if name == 'multi_edge' and canon(got) != canon(want) and len(set(flat)) == len(flat):
        hs.append("겹친 간선: 부모 '정점'이 아니라 들어온 '간선 번호'만 건너뛰어야 합니다.")
    if not hs:
        hs.append('블록 묶음이 다릅니다: 뒤로 가는 간선을 넣고 low[u]를 disc[w]로 낮췄는지(TODO 1) 확인하세요.')
    return hs


def main():
    args = [a for a in sys.argv[1:] if a != '--cpp']
    cpp = '--cpp' in sys.argv
    path = Path(args[0]) if args else HERE / ('bcc_practice.cpp' if cpp else 'bcc_practice.py')
    src = path.read_text(encoding='utf-8')
    got = run_cpp(path) if cpp else run_py(path)
    bad = 0
    for name in GRAPHS:
        n, edges = read_graph(EX / 'fixtures' / f'{name}.txt')
        want, g = expected(name), got[name]
        if isinstance(g, Exception):
            print(f'FAIL {name}: 실행 오류 {g!r}')
            bad += 1
            continue
        if canon(g) == canon(want):
            print(f'ok   {name}: 블록 {len(want)}개')
            continue
        bad += 1
        print(f'FAIL {name}: 나온 블록 {canon(g)} / 정답 {canon(want)}')
        for h in hints(name, g, want, len(edges)):
            print('     - ' + h)
    if bad and 'TODO' in src and '(풀이)' not in src:
        print('TODO가 남아 있습니다: 파일 안의 TODO 1, TODO 2를 채우세요.')
    print('PASS' if not bad else f'FAIL ({bad}/{len(GRAPHS)} 그래프 틀림)')
    return 0 if not bad else 1


if __name__ == '__main__':
    sys.exit(main())
