"""실습: 이중 연결 요소(블록) 찾기 — 빈칸(TODO) 두 곳을 채운다.

확인: python3 films/biconnected-components-20261113/practice/check_practice.py
     (example/fixtures의 그래프 8개로 돌려 example/results의 정답과 블록을 비교하고, 틀리면 흔한 실수를 짚어 준다)

규칙
- edges[i] = (a, b)가 간선 i다. 블록은 간선 번호 목록으로 돌려준다(꺼낸 순서 그대로, 순서는 채점하지 않는다).
- 들어온 간선은 '정점'이 아니라 '간선 번호'로 건너뛴다(겹친 간선 두 가닥은 서로 우회로다).
"""
import sys


def biconnected_blocks(n, edges):
    adj = [[] for _ in range(n)]
    for eid, (a, b) in enumerate(edges):
        adj[a].append((b, eid))
        adj[b].append((a, eid))
    disc, low = [-1] * n, [-1] * n
    stack, blocks = [], []
    clock = 0

    def dfs(u, parent_edge):
        nonlocal clock
        disc[u] = low[u] = clock
        clock += 1
        for w, eid in adj[u]:
            if eid == parent_edge:
                continue
            if disc[w] == -1:
                stack.append(eid)
                dfs(w, eid)
                low[u] = min(low[u], low[w])
                # TODO 2: 자식 w 쪽이 u를 거치지 않고는 위로 올라갈 수 없으면(low와 disc를 비교),
                #         스택에서 간선 eid가 나올 때까지 꺼내 그 간선들을 blocks에 블록 하나로 넣는다.
                pass
            # TODO 1: 이미 방문한 이웃 w로 가는 간선. 조상 쪽(disc가 더 작은 쪽)일 때만
            #         스택에 넣고 low[u]를 disc[w]로 낮춘다. 자손 쪽 간선은 자손이 이미 넣었다.

    sys.setrecursionlimit(max(sys.getrecursionlimit(), 4 * n + 100))
    for r in range(n):
        if disc[r] == -1:
            dfs(r, -1)
    return blocks
