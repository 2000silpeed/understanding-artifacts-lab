// 실습 (C++17): 이중 연결 요소(블록) 찾기 — 빈칸(TODO) 두 곳을 채운다.
// 출력: 블록마다 한 줄, 간선 번호(그래프 파일의 간선 줄 순서, 0부터)를 꺼낸 순서대로 공백으로.
// 확인: python3 films/biconnected-components-20261113/practice/check_practice.py --cpp
#include <algorithm>
#include <fstream>
#include <functional>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

int main(int argc, char** argv) {
  if (argc < 2) { std::cerr << "usage: bcc_practice GRAPH\n"; return 2; }
  std::ifstream in(argv[1]);
  std::vector<std::vector<int>> rows;
  std::string line;
  while (std::getline(in, line)) {
    auto h = line.find('#');
    if (h != std::string::npos) line = line.substr(0, h);
    std::istringstream ss(line);
    std::vector<int> r;
    int x;
    while (ss >> x) r.push_back(x);
    if (!r.empty()) rows.push_back(r);
  }
  int n = rows.at(0).at(0), m = rows.at(0).at(1);
  std::vector<std::vector<std::pair<int, int>>> adj(n);
  for (int i = 0; i < m; i++) {
    int a = rows.at(i + 1).at(0), b = rows.at(i + 1).at(1);
    adj[a].push_back({b, i});
    adj[b].push_back({a, i});
  }
  std::vector<int> disc(n, -1), low(n, -1), stack;
  std::vector<std::vector<int>> blocks;
  int clock = 0;
  std::function<void(int, int)> dfs = [&](int u, int parentEdge) {
    disc[u] = low[u] = clock++;
    for (auto [w, eid] : adj[u]) {
      if (eid == parentEdge) continue;
      if (disc[w] == -1) {
        stack.push_back(eid);
        dfs(w, eid);
        low[u] = std::min(low[u], low[w]);
        // TODO 2: 자식 w 쪽이 u를 거치지 않고는 위로 못 가면, 스택에서 eid가 나올 때까지 꺼내 blocks에 넣는다.
      }
      // TODO 1: 이미 방문한 이웃 w가 조상 쪽(disc[w] < disc[u])이면 스택에 넣고 low[u]를 낮춘다.
    }
  };
  for (int v = 0; v < n; v++)
    if (disc[v] == -1) dfs(v, -1);
  for (auto& b : blocks) {
    for (size_t i = 0; i < b.size(); i++) std::cout << (i ? " " : "") << b[i];
    std::cout << "\n";
  }
  return 0;
}
