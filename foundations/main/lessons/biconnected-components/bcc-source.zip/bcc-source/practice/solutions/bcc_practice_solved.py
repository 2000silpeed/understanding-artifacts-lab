"""실습 정답: 이중 연결 요소(블록)를 간선 번호 묶음으로 돌려준다.

python3 practice/check_practice.py practice/solutions/bcc_practice_solved.py
"""
import sys


def biconnected_blocks(n, edges):
    """edges: [(a, b), ...] (간선 번호 = 목록 순서). 돌려주는 값: 블록마다 간선 번호 목록(꺼낸 순서)."""
    adj = [[] for _ in range(n)]
    for eid, (a, b) in enumerate(edges):
        adj[a].append((b, eid))
        adj[b].append((a, eid))
    disc, low = [-1] * n, [-1] * n
    stack, blocks = [], []
    clock = 0

    def dfs(u, parent_edge):
        nonlocal clock
        disc[u] = low[u] = clock
        clock += 1
        for w, eid in adj[u]:
            if eid == parent_edge:
                continue
            if disc[w] == -1:
                stack.append(eid)
                dfs(w, eid)
                low[u] = min(low[u], low[w])
                # TODO 2 (풀이): 자식 쪽이 u를 거치지 않고는 위로 못 가면 (u, w)까지 꺼낸다
                if low[w] >= disc[u]:
                    block = []
                    while True:
                        e = stack.pop()
                        block.append(e)
                        if e == eid:
                            break
                    blocks.append(block)
            # TODO 1 (풀이): 조상으로 거슬러 가는 간선만 넣는다
            elif disc[w] < disc[u]:
                stack.append(eid)
                low[u] = min(low[u], disc[w])

    sys.setrecursionlimit(max(sys.getrecursionlimit(), 4 * n + 100))
    for r in range(n):
        if disc[r] == -1:
            dfs(r, -1)
    return blocks
