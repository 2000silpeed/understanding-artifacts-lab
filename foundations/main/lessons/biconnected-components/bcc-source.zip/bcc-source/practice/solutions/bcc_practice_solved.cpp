// 실습 정답 (C++17): 그래프 파일을 읽어 블록마다 한 줄에 간선 번호를 꺼낸 순서대로 출력한다.
// build: c++ -std=c++17 -O2 -Wall -Wextra -o /tmp/bcc_practice bcc_practice_solved.cpp
// run:   /tmp/bcc_practice ../../example/fixtures/network.txt
#include <algorithm>
#include <fstream>
#include <functional>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

int main(int argc, char** argv) {
  if (argc < 2) { std::cerr << "usage: bcc_practice GRAPH\n"; return 2; }
  std::ifstream in(argv[1]);
  std::vector<std::vector<int>> rows;
  std::string line;
  while (std::getline(in, line)) {
    auto h = line.find('#');
    if (h != std::string::npos) line = line.substr(0, h);
    std::istringstream ss(line);
    std::vector<int> r;
    int x;
    while (ss >> x) r.push_back(x);
    if (!r.empty()) rows.push_back(r);
  }
  int n = rows.at(0).at(0), m = rows.at(0).at(1);
  std::vector<std::vector<std::pair<int, int>>> adj(n);
  for (int i = 0; i < m; i++) {
    int a = rows.at(i + 1).at(0), b = rows.at(i + 1).at(1);
    adj[a].push_back({b, i});
    adj[b].push_back({a, i});
  }
  std::vector<int> disc(n, -1), low(n, -1), stack;
  std::vector<std::vector<int>> blocks;
  int clock = 0;
  std::function<void(int, int)> dfs = [&](int u, int parentEdge) {
    disc[u] = low[u] = clock++;
    for (auto [w, eid] : adj[u]) {
      if (eid == parentEdge) continue;
      if (disc[w] == -1) {
        stack.push_back(eid);
        dfs(w, eid);
        low[u] = std::min(low[u], low[w]);
        // TODO 2 (풀이)
        if (low[w] >= disc[u]) {
          std::vector<int> block;
          while (true) {
            int e = stack.back();
            stack.pop_back();
            block.push_back(e);
            if (e == eid) break;
          }
          blocks.push_back(block);
        }
      } else if (disc[w] < disc[u]) {  // TODO 1 (풀이)
        stack.push_back(eid);
        low[u] = std::min(low[u], disc[w]);
      }
    }
  };
  for (int v = 0; v < n; v++)
    if (disc[v] == -1) dfs(v, -1);
  for (auto& b : blocks) {
    for (size_t i = 0; i < b.size(); i++) std::cout << (i ? " " : "") << b[i];
    std::cout << "\n";
  }
  return 0;
}
