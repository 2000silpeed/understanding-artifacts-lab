"""이중 연결 요소(블록): DFS 한 번 + 간선 스택으로, 단절점을 경계로 간선을 블록으로 나눈다. 표준 라이브러리만 쓴다.

usage:
  python3 bcc.py run --graph fixtures/network.txt                  # 블록, 단절점, disc/low, 스택 기록 (JSON)
  python3 bcc.py run --graph fixtures/network.txt --bug double-back # 흔한 실수: 자손 쪽에서 이미 넣은 간선을 또 넣는다
  python3 bcc.py run --graph fixtures/network.txt --bug strict      # 흔한 실수: low[w] >= disc[u] 대신 >
  python3 bcc.py critical --graph fixtures/network.txt --pair 0,7   # 두 정점 사이 길에서, 하나만 꺼져도 끊기는 정점
  python3 bcc.py brute --graph fixtures/network.txt                 # 정의대로(간선 쌍 × 정점 하나씩 지우기) 블록을 구한다
  python3 bcc.py paths --graph fixtures/network.txt --pair 0,1      # 가운데 정점이 겹치지 않는 두 경로(작은 그래프용)
  python3 bcc.py run --graph fixtures/network.txt --text            # 사람이 읽는 요약

그래프 파일: '#' 줄은 주석, 첫 줄 "n m", 이어서 m줄 "a b"(무방향). 간선 번호는 줄 순서(0부터), 인접 목록도 이 순서다.
겹친 간선은 허용하고(서로 다른 간선 번호), 자기 고리는 거부한다. DFS는 번호가 작은 정점부터 연결 요소마다 시작한다.
"""
import argparse
import json
import sys
from collections import deque


def read_graph(path):
    rows = []
    with open(path, encoding='utf-8') as fh:
        for line in fh:
            line = line.split('#', 1)[0].strip()
            if line:
                rows.append([int(x) for x in line.split()])
    n, m = rows[0]
    edges = [tuple(r) for r in rows[1:]]
    if len(edges) != m or any(len(e) != 2 for e in edges):
        raise ValueError(f'{path}: expected {m} edges of two vertices')
    for a, b in edges:
        if not (0 <= a < n and 0 <= b < n):
            raise ValueError(f'{path}: vertex out of range in edge {a} {b}')
        if a == b:
            raise ValueError(f'{path}: self-loop {a} {b} is not supported')
    return n, edges


def adjacency(n, edges):
    adj = [[] for _ in range(n)]
    for eid, (a, b) in enumerate(edges):
        adj[a].append((b, eid))
        adj[b].append((a, eid))
    return adj


class Trace:
    """DFS 상태와 기록(스택, 블록, 이벤트, 횟수). 알고리즘의 판단은 하지 않고 적기만 한다."""

    def __init__(self, n, edges):
        self.n, self.edges = n, edges
        self.adj = adjacency(n, edges)
        self.disc, self.low = [-1] * n, [-1] * n
        self.stack, self.blocks, self.events, self.order, self.roots, self.tree, self.back = [], [], [], [], [], [], []
        self.counts = {'pushes': 0, 'pops': 0, 'adjScans': 0}

    def push(self, eid, kind):
        self.stack.append(eid)
        self.counts['pushes'] += 1
        self.events.append({'op': 'push', 'e': eid, 'kind': kind})
        (self.tree if kind == 'tree' else self.back).append(eid)

    def note(self, u, w, pop):
        self.events.append({'op': 'check', 'u': u, 'w': w, 'lowW': self.low[w], 'discU': self.disc[u], 'pop': pop})

    def pop_block(self, eid):
        """(u, w) 간선(eid)이 나올 때까지 꺼낸 간선들이 블록 하나다."""
        block = []
        while True:
            e = self.stack.pop()
            self.counts['pops'] += 1
            block.append(e)
            self.events.append({'op': 'pop', 'e': e, 'block': len(self.blocks)})
            if e == eid:
                break
        self.blocks.append(block)

    def run(self, dfs):
        limit = sys.getrecursionlimit()
        sys.setrecursionlimit(max(limit, 4 * self.n + 100))
        try:
            for r in range(self.n):
                if self.disc[r] == -1 and self.adj[r]:
                    self.roots.append(r)
                    dfs(r, -1)
        finally:
            sys.setrecursionlimit(limit)
        return summarize(self)


def biconnected(n, edges, bug=None):
    """Hopcroft–Tarjan(1973)의 방법: DFS 하나로 disc/low를 구하고, 간선을 스택에 쌓았다가
    자식 w에서 돌아왔을 때 low[w] >= disc[u]이면 (u, w) 간선까지 꺼낸 묶음이 블록 하나다.
    bug가 있으면 교육용으로 일부러 틀린 변형(biconnected_mistake)을 돌린다."""
    if bug:
        return biconnected_mistake(n, edges, bug)
    tr = Trace(n, edges)
    adj, disc, low, push, pop_block = tr.adj, tr.disc, tr.low, tr.push, tr.pop_block
    clock = 0

    def dfs(u, parent_edge):
        nonlocal clock
        disc[u] = low[u] = clock
        clock += 1
        tr.order.append(u)
        for w, eid in adj[u]:
            tr.counts['adjScans'] += 1
            if eid == parent_edge:  # 들어온 간선 자체만 건너뛴다(겹친 간선은 번호가 달라 남는다)
                continue
            if disc[w] == -1:  # 처음 가는 정점: 트리 간선
                push(eid, 'tree')
                dfs(w, eid)
                low[u] = min(low[u], low[w])
                tr.note(u, w, low[w] >= disc[u])
                if low[w] >= disc[u]:
                    pop_block(eid)
            elif disc[w] < disc[u]:  # 조상으로 거슬러 가는 간선만. 자손 쪽 간선은 자손이 이미 넣었다
                push(eid, 'back')
                low[u] = min(low[u], disc[w])

    return tr.run(dfs)


def biconnected_mistake(n, edges, bug):
    """교육용 틀린 변형. 위 dfs와 한 줄만 다르다.
    'double-back': 자손 쪽 간선도 또 넣는다(elif에서 disc[w] < disc[u] 조건을 뺀 실수).
    'strict': low[w] > disc[u]일 때만 꺼낸다(같을 때를 놓치는 실수)."""
    if bug not in ('double-back', 'strict'):
        raise ValueError(f'unknown bug {bug}')
    tr = Trace(n, edges)
    adj, disc, low, push, pop_block = tr.adj, tr.disc, tr.low, tr.push, tr.pop_block
    clock = 0

    def dfs(u, parent_edge):
        nonlocal clock
        disc[u] = low[u] = clock
        clock += 1
        tr.order.append(u)
        for w, eid in adj[u]:
            tr.counts['adjScans'] += 1
            if eid == parent_edge:
                continue
            if disc[w] == -1:
                push(eid, 'tree')
                dfs(w, eid)
                low[u] = min(low[u], low[w])
                pop = low[w] > disc[u] if bug == 'strict' else low[w] >= disc[u]  # 실수: strict
                tr.note(u, w, pop)
                if pop:
                    pop_block(eid)
            elif bug == 'double-back' or disc[w] < disc[u]:  # 실수: double-back
                push(eid, 'back')
                low[u] = min(low[u], disc[w])

    return tr.run(dfs)


def summarize(tr):
    n, edges, disc, low, order, roots, tree, back, blocks, events, counts = (
        tr.n, tr.edges, tr.disc, tr.low, tr.order, tr.roots, tr.tree, tr.back, tr.blocks, tr.events, tr.counts)
    leftover = list(tr.stack)
    vsets = [sorted({v for e in b for v in edges[e]}) for b in blocks]
    member = [0] * n
    for vs in vsets:
        for v in vs:
            member[v] += 1
    cuts = [v for v in range(n) if member[v] >= 2]
    names = [f'B{i + 1}' for i in range(len(blocks))]
    bc_edges = [[names[i], c] for i, vs in enumerate(vsets) for c in vs if c in cuts]
    return {
        'n': n, 'm': len(edges), 'edges': [list(e) for e in edges],
        'roots': roots, 'order': order, 'disc': disc, 'low': low,
        'treeEdges': tree, 'backEdges': back,
        'blocks': [{'name': names[i], 'edges': b, 'vertices': vsets[i]} for i, b in enumerate(blocks)],
        'cutVertices': cuts,
        'membership': member,
        'bridges': sorted(b[0] for b in blocks if len(b) == 1),
        'isolated': [v for v in range(n) if not any(v in e for e in edges)],
        'bcTree': {'nodes': names + cuts, 'edges': bc_edges},
        'leftover': leftover,
        'pushes': counts['pushes'], 'pops': counts['pops'], 'adjScans': counts['adjScans'],
        'events': events,
    }


def critical(n, edges, a, b):
    """a와 b 사이 길에서, 하나만 꺼져도 a와 b가 끊기는 정점 = 블록-단절점 트리 경로 위의 단절점(a, b 자신은 빼고)."""
    res = biconnected(n, edges)
    cuts = set(res['cutVertices'])
    node = lambda v: ('C', v) if v in cuts else next(('B', i) for i, bl in enumerate(res['blocks']) if v in bl['vertices'])
    nbr = {}
    for name, c in res['bcTree']['edges']:
        bi = int(name[1:]) - 1
        nbr.setdefault(('B', bi), []).append(('C', c))
        nbr.setdefault(('C', c), []).append(('B', bi))
    if a == b or not any(a in e for e in edges) or not any(b in e for e in edges):
        raise ValueError('pair must be two different vertices that have edges')
    src, dst = node(a), node(b)
    prev, q = {src: None}, deque([src])
    while q:
        x = q.popleft()
        for y in nbr.get(x, []):
            if y not in prev:
                prev[y] = x
                q.append(y)
    if dst not in prev:
        return {'a': a, 'b': b, 'connected': False, 'sameBlock': False, 'path': [], 'critical': []}
    path, x = [], dst
    while x is not None:
        path.append(x)
        x = prev[x]
    path.reverse()
    shown = [f'B{i + 1}' if k == 'B' else i for k, i in path]
    crit = [i for k, i in path if k == 'C' and i not in (a, b)]
    same = any(a in bl['vertices'] and b in bl['vertices'] for bl in res['blocks'])
    return {'a': a, 'b': b, 'connected': True, 'sameBlock': same, 'path': shown, 'critical': crit}


def brute(n, edges):
    """정의대로: 두 간선이 같은 블록 ⇔ 어떤 정점 x를 지워도 두 간선의 남은 끝점이 이어져 있다.
    간선 쌍마다 정점 n개를 하나씩 지우고 BFS로 확인한다. 정답 확인과 비용 비교용."""
    adj = adjacency(n, edges)
    bfs_runs = 0

    def connected_without(x, s, t):
        nonlocal bfs_runs
        bfs_runs += 1
        seen, q = {s}, deque([s])
        while q:
            u = q.popleft()
            if u == t:
                return True
            for w, _ in adj[u]:
                if w != x and w not in seen:
                    seen.add(w)
                    q.append(w)
        return False

    def same(e, f):
        for x in range(n):
            ends_e = [v for v in edges[e] if v != x]
            ends_f = [v for v in edges[f] if v != x]
            if not connected_without(x, ends_e[0], ends_f[0]):
                return False
        return True

    m = len(edges)
    parent = list(range(m))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    pairs = 0
    for e in range(m):
        for f in range(e + 1, m):
            pairs += 1
            if same(e, f):
                parent[find(e)] = find(f)
    groups = {}
    for e in range(m):
        groups.setdefault(find(e), []).append(e)
    blocks = sorted(sorted(g) for g in groups.values())
    vsets = [sorted({v for e in b for v in edges[e]}) for b in blocks]
    cuts = sorted({v for v in range(n) if sum(v in vs for vs in vsets) >= 2})
    return {'blocks': [{'edges': b, 'vertices': vs} for b, vs in zip(blocks, vsets)], 'cutVertices': cuts, 'edgePairs': pairs, 'bfsRuns': bfs_runs}


def disjoint_paths(n, edges, a, b):
    """작은 그래프용: a와 b 사이 단순 경로를 모두 늘어놓고, 가운데 정점이 겹치지 않는 두 경로 중 가장 짧은 쌍.
    같은 블록(정점 3개 이상) 안의 두 정점에는 이런 쌍이 반드시 있다(Whitney 정리)."""
    adj = adjacency(n, edges)
    paths = []

    def walk(u, path):
        if u == b:
            paths.append(list(path))
            return
        for w, _ in adj[u]:
            if w not in path:
                path.append(w)
                walk(w, path)
                path.pop()
    walk(a, [a])
    paths = sorted({tuple(p) for p in paths}, key=lambda p: (len(p), p))
    best = None
    for i, p in enumerate(paths):
        for q in paths[i + 1:]:
            if not set(p[1:-1]) & set(q[1:-1]) and (len(p) > 2 or len(q) > 2):
                if best is None or len(p) + len(q) < len(best[0]) + len(best[1]):
                    best = (list(p), list(q))
    return {'a': a, 'b': b, 'simplePaths': len(paths), 'pair': list(best) if best else []}


def text(res, edges):
    name = lambda e: f'{edges[e][0]}-{edges[e][1]}'
    out = [f"정점 {res['n']}개, 간선 {res['m']}개, DFS 시작 {res['roots']}",
           'disc ' + ' '.join(map(str, res['disc'])), 'low  ' + ' '.join(map(str, res['low']))]
    for b in res['blocks']:
        out.append(f"{b['name']}: 간선 {', '.join(name(e) for e in b['edges'])}  정점 {b['vertices']}")
    out.append(f"단절점 {res['cutVertices']}  단절선(간선 하나짜리 블록) {[name(e) for e in res['bridges']]}")
    out.append(f"스택: 넣기 {res['pushes']}번, 꺼내기 {res['pops']}번, 남은 간선 {[name(e) for e in res['leftover']]}")
    return '\n'.join(out)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('mode', choices=['run', 'critical', 'brute', 'paths'])
    ap.add_argument('--graph', required=True)
    ap.add_argument('--bug', choices=['double-back', 'strict'])
    ap.add_argument('--pair')
    ap.add_argument('--text', action='store_true')
    a = ap.parse_args(argv)
    n, edges = read_graph(a.graph)
    if a.mode == 'run':
        res = biconnected(n, edges, a.bug)
        print(text(res, edges) if a.text else json.dumps(res, ensure_ascii=False))
    elif a.mode == 'critical':
        x, y = (int(v) for v in a.pair.split(','))
        print(json.dumps(critical(n, edges, x, y), ensure_ascii=False))
    elif a.mode == 'paths':
        x, y = (int(v) for v in a.pair.split(','))
        print(json.dumps(disjoint_paths(n, edges, x, y), ensure_ascii=False))
    else:
        print(json.dumps(brute(n, edges), ensure_ascii=False))
    return 0


if __name__ == '__main__':
    sys.exit(main())
