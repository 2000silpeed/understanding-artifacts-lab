// 이중 연결 요소(블록): DFS 한 번 + 간선 스택. bcc.py와 같은 계산, 같은 JSON을 글자 그대로 출력한다(C++17, 표준 라이브러리만).
//
// build: c++ -std=c++17 -O2 -Wall -Wextra -o build/bcc bcc.cpp
// usage:
//   build/bcc run --graph fixtures/network.txt [--bug double-back|strict]
//   build/bcc critical --graph fixtures/network.txt --pair 0,7
// 그래프 파일 형식과 규칙은 bcc.py와 같다('#' 주석, "n m", m줄 "a b", 간선 번호 = 줄 순서, 자기 고리 거부).
#include <algorithm>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

using std::string;
using std::vector;

struct Graph {
  int n = 0;
  vector<std::pair<int, int>> edges;
  vector<vector<std::pair<int, int>>> adj;  // (이웃, 간선 번호), 간선 줄 순서
};

Graph readGraph(const string& path) {
  std::ifstream in(path);
  if (!in) throw std::runtime_error("cannot open " + path);
  vector<vector<int>> rows;
  string line;
  while (std::getline(in, line)) {
    auto hash = line.find('#');
    if (hash != string::npos) line = line.substr(0, hash);
    std::istringstream ss(line);
    vector<int> r;
    int x;
    while (ss >> x) r.push_back(x);
    if (!r.empty()) rows.push_back(r);
  }
  Graph g;
  g.n = rows.at(0).at(0);
  int m = rows.at(0).at(1);
  if (static_cast<int>(rows.size()) - 1 != m) throw std::runtime_error(path + ": edge count differs");
  g.adj.assign(g.n, {});
  for (int i = 1; i <= m; i++) {
    if (rows[i].size() != 2) throw std::runtime_error(path + ": edge needs two vertices");
    int a = rows[i][0], b = rows[i][1];
    if (a < 0 || b < 0 || a >= g.n || b >= g.n) throw std::runtime_error(path + ": vertex out of range");
    if (a == b) throw std::runtime_error(path + ": self-loop is not supported");
    int eid = static_cast<int>(g.edges.size());
    g.edges.push_back({a, b});
    g.adj[a].push_back({b, eid});
    g.adj[b].push_back({a, eid});
  }
  return g;
}

struct Event {
  string op;  // push | check | pop
  int e = -1, u = -1, w = -1, lowW = 0, discU = 0, block = -1;
  string kind;
  bool pop = false;
};

struct Result {
  vector<int> disc, low, order, roots, tree, back, leftover, cuts, member, bridges, isolated;
  vector<vector<int>> blocks, vsets;
  vector<Event> events;
  long pushes = 0, pops = 0, adjScans = 0;
};

Result biconnected(const Graph& g, const string& bug) {
  Result r;
  r.disc.assign(g.n, -1);
  r.low.assign(g.n, -1);
  vector<int> stack;
  int clock = 0;
  auto push = [&](int eid, const char* kind) {
    stack.push_back(eid);
    r.pushes++;
    Event ev; ev.op = "push"; ev.e = eid; ev.kind = kind;
    r.events.push_back(ev);
  };
  std::function<void(int, int)> dfs = [&](int u, int parentEdge) {
    r.disc[u] = r.low[u] = clock++;
    r.order.push_back(u);
    for (auto [w, eid] : g.adj[u]) {
      r.adjScans++;
      if (eid == parentEdge) continue;  // 들어온 간선 자체만 건너뛴다
      if (r.disc[w] == -1) {             // 트리 간선
        push(eid, "tree");
        r.tree.push_back(eid);
        dfs(w, eid);
        r.low[u] = std::min(r.low[u], r.low[w]);
        bool cut = bug == "strict" ? r.low[w] > r.disc[u] : r.low[w] >= r.disc[u];
        Event ev; ev.op = "check"; ev.u = u; ev.w = w; ev.lowW = r.low[w]; ev.discU = r.disc[u]; ev.pop = cut;
        r.events.push_back(ev);
        if (cut) {                        // (u, w)까지 꺼낸 간선들이 블록 하나
          vector<int> block;
          while (true) {
            int e = stack.back();
            stack.pop_back();
            r.pops++;
            block.push_back(e);
            Event pe; pe.op = "pop"; pe.e = e; pe.block = static_cast<int>(r.blocks.size());
            r.events.push_back(pe);
            if (e == eid) break;
          }
          r.blocks.push_back(block);
        }
      } else if (r.disc[w] < r.disc[u] || bug == "double-back") {  // 조상 쪽 간선만
        push(eid, "back");
        r.back.push_back(eid);
        r.low[u] = std::min(r.low[u], r.disc[w]);
      }
    }
  };
  for (int v = 0; v < g.n; v++)
    if (r.disc[v] == -1 && !g.adj[v].empty()) { r.roots.push_back(v); dfs(v, -1); }
  r.leftover = stack;
  r.member.assign(g.n, 0);
  for (auto& b : r.blocks) {
    std::set<int> vs;
    for (int e : b) { vs.insert(g.edges[e].first); vs.insert(g.edges[e].second); }
    r.vsets.push_back(vector<int>(vs.begin(), vs.end()));
    for (int v : vs) r.member[v]++;
    if (b.size() == 1) r.bridges.push_back(b[0]);
  }
  std::sort(r.bridges.begin(), r.bridges.end());
  for (int v = 0; v < g.n; v++) {
    if (r.member[v] >= 2) r.cuts.push_back(v);
    if (g.adj[v].empty()) r.isolated.push_back(v);
  }
  return r;
}

// ---------- JSON, the same text json.dumps(ensure_ascii=False) writes ----------
string arr(const vector<int>& v) {
  string s = "[";
  for (size_t i = 0; i < v.size(); i++) s += (i ? ", " : "") + std::to_string(v[i]);
  return s + "]";
}
string q(const string& s) { return "\"" + s + "\""; }
string bname(int i) { return "B" + std::to_string(i + 1); }

string runJson(const Graph& g, const Result& r) {
  std::ostringstream o;
  o << "{\"n\": " << g.n << ", \"m\": " << g.edges.size() << ", \"edges\": [";
  for (size_t i = 0; i < g.edges.size(); i++) o << (i ? ", " : "") << "[" << g.edges[i].first << ", " << g.edges[i].second << "]";
  o << "], \"roots\": " << arr(r.roots) << ", \"order\": " << arr(r.order) << ", \"disc\": " << arr(r.disc) << ", \"low\": " << arr(r.low)
    << ", \"treeEdges\": " << arr(r.tree) << ", \"backEdges\": " << arr(r.back) << ", \"blocks\": [";
  for (size_t i = 0; i < r.blocks.size(); i++)
    o << (i ? ", " : "") << "{\"name\": " << q(bname(static_cast<int>(i))) << ", \"edges\": " << arr(r.blocks[i]) << ", \"vertices\": " << arr(r.vsets[i]) << "}";
  o << "], \"cutVertices\": " << arr(r.cuts) << ", \"membership\": " << arr(r.member) << ", \"bridges\": " << arr(r.bridges)
    << ", \"isolated\": " << arr(r.isolated) << ", \"bcTree\": {\"nodes\": [";
  bool first = true;
  for (size_t i = 0; i < r.blocks.size(); i++) { o << (first ? "" : ", ") << q(bname(static_cast<int>(i))); first = false; }
  for (int c : r.cuts) { o << (first ? "" : ", ") << c; first = false; }
  o << "], \"edges\": [";
  first = true;
  for (size_t i = 0; i < r.vsets.size(); i++)
    for (int v : r.vsets[i])
      if (r.member[v] >= 2) { o << (first ? "" : ", ") << "[" << q(bname(static_cast<int>(i))) << ", " << v << "]"; first = false; }
  o << "]}, \"leftover\": " << arr(r.leftover) << ", \"pushes\": " << r.pushes << ", \"pops\": " << r.pops << ", \"adjScans\": " << r.adjScans << ", \"events\": [";
  for (size_t i = 0; i < r.events.size(); i++) {
    const Event& e = r.events[i];
    o << (i ? ", " : "") << "{\"op\": " << q(e.op);
    if (e.op == "push") o << ", \"e\": " << e.e << ", \"kind\": " << q(e.kind);
    else if (e.op == "check") o << ", \"u\": " << e.u << ", \"w\": " << e.w << ", \"lowW\": " << e.lowW << ", \"discU\": " << e.discU << ", \"pop\": " << (e.pop ? "true" : "false");
    else o << ", \"e\": " << e.e << ", \"block\": " << e.block;
    o << "}";
  }
  o << "]}";
  return o.str();
}

// 블록-단절점 트리 위 a → b 경로의 단절점(a, b 자신은 빼고): 하나만 꺼져도 a와 b가 끊기는 정점.
string criticalJson(const Graph& g, int a, int b) {
  Result r = biconnected(g, "");
  if (a == b || g.adj.at(a).empty() || g.adj.at(b).empty()) throw std::runtime_error("pair must be two different vertices that have edges");
  // 노드 번호: 블록 i → i, 단절점 c → nb + c
  int nb = static_cast<int>(r.blocks.size());
  auto isCut = [&](int v) { return r.member[v] >= 2; };
  auto node = [&](int v) {
    if (isCut(v)) return nb + v;
    for (int i = 0; i < nb; i++)
      if (std::find(r.vsets[i].begin(), r.vsets[i].end(), v) != r.vsets[i].end()) return i;
    return -1;
  };
  std::map<int, vector<int>> nbr;
  for (int i = 0; i < nb; i++)
    for (int v : r.vsets[i])
      if (isCut(v)) { nbr[i].push_back(nb + v); nbr[nb + v].push_back(i); }
  int src = node(a), dst = node(b);
  std::map<int, int> prev;
  prev[src] = -1;
  std::deque<int> dq{src};
  while (!dq.empty()) {
    int x = dq.front(); dq.pop_front();
    for (int y : nbr[x])
      if (!prev.count(y)) { prev[y] = x; dq.push_back(y); }
  }
  std::ostringstream o;
  o << "{\"a\": " << a << ", \"b\": " << b;
  if (!prev.count(dst)) { o << ", \"connected\": false, \"sameBlock\": false, \"path\": [], \"critical\": []}"; return o.str(); }
  vector<int> path;
  for (int x = dst; x != -1; x = prev[x]) path.push_back(x);
  std::reverse(path.begin(), path.end());
  bool same = false;
  for (auto& vs : r.vsets)
    if (std::count(vs.begin(), vs.end(), a) && std::count(vs.begin(), vs.end(), b)) same = true;
  vector<int> crit;
  o << ", \"connected\": true, \"sameBlock\": " << (same ? "true" : "false") << ", \"path\": [";
  for (size_t i = 0; i < path.size(); i++) {
    int x = path[i];
    if (x < nb) o << (i ? ", " : "") << q(bname(x));
    else {
      o << (i ? ", " : "") << x - nb;
      if (x - nb != a && x - nb != b) crit.push_back(x - nb);
    }
  }
  o << "], \"critical\": " << arr(crit) << "}";
  return o.str();
}

int main(int argc, char** argv) {
  try {
    if (argc < 2) throw std::runtime_error("usage: bcc run|critical --graph FILE [--bug double-back|strict] [--pair a,b]");
    string mode = argv[1], graph, bug, pair;
    for (int i = 2; i + 1 < argc; i += 2) {
      string k = argv[i], v = argv[i + 1];
      if (k == "--graph") graph = v;
      else if (k == "--bug") bug = v;
      else if (k == "--pair") pair = v;
      else throw std::runtime_error("unknown option " + k);
    }
    if (!bug.empty() && bug != "double-back" && bug != "strict") throw std::runtime_error("unknown bug " + bug);
    Graph g = readGraph(graph);
    if (mode == "run") std::cout << runJson(g, biconnected(g, bug)) << "\n";
    else if (mode == "critical") {
      auto comma = pair.find(',');
      if (comma == string::npos) throw std::runtime_error("--pair a,b");
      std::cout << criticalJson(g, std::stoi(pair.substr(0, comma)), std::stoi(pair.substr(comma + 1))) << "\n";
    } else throw std::runtime_error("unknown mode " + mode);
  } catch (const std::exception& e) {
    std::cerr << "error: " << e.what() << "\n";
    return 2;
  }
  return 0;
}
