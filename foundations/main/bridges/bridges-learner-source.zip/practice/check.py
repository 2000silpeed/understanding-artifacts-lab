"""실습 확인: 채운 find_bridges가 수업 예제와 무작위 그래프에서 맞는지 본다.

usage: python3 practice/check.py <실습 파일>        (영화 폴더 또는 저장소 루트 어디서나; 경로는 그대로 넘긴다)
  1) 수업 예제(code/fixtures/campus.graph): 단절선·방문 번호·low가 영상과 같은가
  2) 함정 두 개: 케이블 두 가닥(다중 간선) → 단절선 아님, 삼각형(low = tin) → 단절선 아님
  3) 무작위 그래프 300개: 정의(지우면 두 끝이 끊기는가)로 센 답과 같은가
하나라도 틀리면 어느 빈칸을 볼지 알려 주고 exit 1, 모두 맞으면 CHECK PASS.
"""
import importlib.util
import random
import sys
from collections import deque
from pathlib import Path

FILM = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(FILM / 'code' / 'python'))
import bridges as REF  # noqa: E402  (the lesson program: graph reader and adjacency)


def load(path):
    spec = importlib.util.spec_from_file_location('exercise', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def brute(n, edges):
    out = []
    for cut, (a, b) in enumerate(edges):
        if a == b:
            continue
        seen, q = {a}, deque([a])
        while q:
            v = q.popleft()
            for e, (x, y) in enumerate(edges):
                if e != cut and v in (x, y):
                    w = y if v == x else x
                    if w not in seen:
                        seen.add(w)
                        q.append(w)
        if b not in seen:
            out.append(cut)
    return out


def run(mod, n, edges):
    return mod.find_bridges(REF.adjacency(n, edges), n)


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    mod = load(argv[1])
    try:
        names, edges = REF.read_graph(FILM / 'code' / 'fixtures' / 'campus.graph')
        found, tin, low = run(mod, len(names), edges)
        want, wtin, wlow = REF.find_bridges(REF.adjacency(len(names), edges), len(names))
        if (tin, low) != (wtin, wlow):
            print('FAIL 수업 예제: 방문 번호나 low가 영상과 다르다 → 빈칸 1(건너뛰기) 또는 빈칸 2(역방향 간선의 low)')
            print('  low  got', dict(zip(names, low)), '\n       want', dict(zip(names, wlow)))
            return 1
        if found != want:
            print('FAIL 수업 예제: 단절선이 다르다 → 빈칸 3(판정)')
            print('  got ', [f'{names[edges[e][0]]}-{names[edges[e][1]]}' for e in found])
            print('  want', [f'{names[edges[e][0]]}-{names[edges[e][1]]}' for e in want])
            return 1
        print('ok   수업 예제: 단절선', len(found), '개, 방문 번호·low 일치')
        if run(mod, 2, [(0, 1), (1, 0)])[0]:
            print('FAIL 케이블 두 가닥(다중 간선)을 단절선으로 셌다 → 빈칸 1: 정점이 아니라 들어온 간선 번호만 건너뛴다')
            return 1
        if run(mod, 3, [(0, 1), (1, 2), (2, 0)])[0]:
            print('FAIL 삼각형의 간선을 단절선으로 셌다 → 빈칸 3: low[v]가 tin[u]와 같으면 단절선이 아니다(크다로 비교)')
            return 1
        print('ok   함정 두 개(다중 간선, low = tin)')
        rng = random.Random(14)
        for k in range(300):
            n = rng.randint(1, 8)
            edges = [(rng.randrange(n), rng.randrange(n)) for _ in range(rng.randint(0, 12))]
            if edges and rng.random() < 0.4:
                edges.append(edges[rng.randrange(len(edges))][::-1])
            got, wantb = sorted(run(mod, n, edges)[0]), brute(n, edges)
            if got != wantb:
                print(f'FAIL 무작위 그래프 #{k}: n={n} edges={edges} got {got} want {wantb}')
                return 1
        print('ok   무작위 그래프 300개가 정의와 일치')
    except NotImplementedError as e:
        print(f'FAIL 아직 비어 있다: {e}')
        return 1
    print('CHECK PASS')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
