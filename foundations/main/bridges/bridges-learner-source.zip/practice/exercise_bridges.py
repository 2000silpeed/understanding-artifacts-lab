"""실습: 단절선 찾기의 빈칸 세 곳을 채운다.

영상에서 본 DFS 한 번 + low 값 방법이 이미 짜여 있고, 판단 세 군데만 비어 있다.
  빈칸 1  came_in_by   — 지금 보는 간선이 '들어온 간선'인가? (다중 간선을 생각할 것: 정점이 아니라 간선 번호)
  빈칸 2  lower_by_back — 역방향 간선 v→w를 만났을 때 v의 low는 무엇이 되나?
  빈칸 3  is_bridge     — 트리 간선 u→v가 끝났을 때, 단절선인가? (같을 때는?)
확인: python3 practice/check.py practice/exercise_bridges.py   (영화 폴더 기준. 다 채우면 CHECK PASS)
"""


def came_in_by(e, pe):
    """e: 지금 보는 간선 번호, pe: v로 들어올 때 탄 간선 번호(루트는 -1). 건너뛸 간선이면 True."""
    raise NotImplementedError('빈칸 1: came_in_by')


def lower_by_back(low_v, tin_w):
    """역방향 간선 v→w를 만났을 때 v의 새 low 값."""
    raise NotImplementedError('빈칸 2: lower_by_back')


def is_bridge(low_v, tin_u):
    """트리 간선 u→v의 판정. low_v = v의 low, tin_u = u의 방문 번호."""
    raise NotImplementedError('빈칸 3: is_bridge')


def find_bridges(adj, n):
    """adj[v] = [(이웃, 간선 번호), …]. 돌려주는 값: (단절선 간선 번호들 — 찾은 순서, tin, low)."""
    tin, low = [0] * n, [0] * n
    timer, found = 0, []
    for root in range(n):
        if tin[root]:
            continue
        timer += 1
        tin[root] = low[root] = timer
        stack = [(root, -1, iter(adj[root]))]
        while stack:
            v, pe, it = stack[-1]
            nxt = next(it, None)
            if nxt is None:
                stack.pop()
                if stack:
                    u = stack[-1][0]
                    low[u] = min(low[u], low[v])
                    if is_bridge(low[v], tin[u]):
                        found.append(pe)
                continue
            w, e = nxt
            if came_in_by(e, pe):
                continue
            if tin[w]:
                low[v] = lower_by_back(low[v], tin[w])
            else:
                timer += 1
                tin[w] = low[w] = timer
                stack.append((w, e, iter(adj[w])))
    return found, tin, low
