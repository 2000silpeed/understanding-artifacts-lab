"""단절선(bridge) 찾기 — 무방향 그래프, DFS 한 번과 low 값(Tarjan). 재귀 대신 명시적 스택이라 깊은 그래프도 된다.

usage: python3 bridges.py <graph file> [--trace <out.json>]
  graph file: 'nodes a b c …' 한 줄, 그다음 간선 'a b' 한 줄씩('#' 뒤는 주석). 간선 번호 = 간선 줄 순서(0부터).
  stdout: 사람이 읽는 결과. C++ 판(code/cpp/bridges.cpp)과 글자 그대로 같아야 한다(code/export.py가 확인).
  --trace: 영상이 그리는 전체 기록(방문·역방향 간선·끝남 순서, 단순 방법 결과 등)을 JSON으로 쓴다.
다중 간선은 간선 번호로 구별한다: 들어온 '간선' 하나만 건너뛰고, 같은 이웃으로 가는 다른 간선은 역방향 간선으로 본다.
자기 간선(a a)은 무엇도 끊지 못하므로 인접 목록에 넣지 않는다.
"""
import json
import sys
from collections import deque

NAIVE_MAX_EDGES = 2000  # the naive check is O(E·(V+E)); above this it is skipped (same rule in the C++ program)


def read_graph(path):
    names, ix, edges = None, None, []
    with open(path, encoding='utf-8') as f:
        for raw in f:
            words = raw.split('#', 1)[0].split()
            if not words:
                continue
            if words[0] == 'nodes':
                names = words[1:]
                ix = {n: i for i, n in enumerate(names)}
                continue
            edges.append((ix[words[0]], ix[words[1]]))
    return names, edges


def adjacency(n, edges):
    """adj[v] = [(이웃, 간선 번호), …] in edge order; self-loops left out."""
    adj = [[] for _ in range(n)]
    for e, (a, b) in enumerate(edges):
        if a != b:
            adj[a].append((b, e))
            adj[b].append((a, e))
    return adj


# [film:dfs]
def find_bridges(adj, n):
    tin, low = [0] * n, [0] * n
    timer, found = 0, []
    for root in range(n):
        if tin[root]:
            continue
        timer += 1
        tin[root] = low[root] = timer
        stack = [(root, -1, iter(adj[root]))]
        while stack:
            v, pe, it = stack[-1]
            nxt = next(it, None)
            if nxt is None:      # v is done
                stack.pop()
                if stack:
                    u = stack[-1][0]
                    low[u] = min(low[u], low[v])
                    if low[v] > tin[u]:
                        found.append(pe)
                continue
            w, e = nxt
            if e == pe:          # came in by it
                continue
            if tin[w]:           # back edge
                low[v] = min(low[v], tin[w])
            else:                # tree edge
                timer += 1
                tin[w] = low[w] = timer
                stack.append((w, e, iter(adj[w])))
    return found, tin, low
# [film:end]


def trace_dfs(adj, n, skip='edge'):
    """The same DFS, recording every step for the film. skip='vertex' is the classic bug: it skips every edge back to the
    parent vertex (not just the edge it came in by), so a doubled cable looks like a single one."""
    tin, low, up, parent = [0] * n, [0] * n, [-1] * n, [-1] * n
    timer, found, events = 0, [], []
    for root in range(n):
        if tin[root]:
            continue
        timer += 1
        tin[root] = low[root] = timer
        events.append({'type': 'visit', 'v': root, 'tin': timer, 'edge': -1, 'from': -1})
        stack = [(root, 0)]
        while stack:
            v, i = stack[-1]
            if i == len(adj[v]):
                stack.pop()
                if stack:
                    u = stack[-1][0]
                    before = low[u]
                    low[u] = min(low[u], low[v])
                    bridge = low[v] > tin[u]
                    if bridge:
                        found.append(up[v])
                    events.append({'type': 'finish', 'v': v, 'parent': u, 'edge': up[v], 'low': low[v], 'tinParent': tin[u],
                                   'bridge': bridge, 'parentLowBefore': before, 'parentLowAfter': low[u]})
                else:
                    events.append({'type': 'finish', 'v': v, 'parent': -1, 'edge': -1, 'low': low[v], 'tinParent': None, 'bridge': False})
                continue
            stack[-1] = (v, i + 1)
            w, e = adj[v][i]
            if (e == up[v]) if skip == 'edge' else (w == parent[v]):
                continue
            if tin[w]:
                if tin[w] < tin[v]:  # to an ancestor (the other end of an edge already used from below changes nothing)
                    before = low[v]
                    low[v] = min(low[v], tin[w])
                    events.append({'type': 'back', 'v': v, 'w': w, 'edge': e, 'tinW': tin[w], 'lowBefore': before, 'lowAfter': low[v]})
            else:
                timer += 1
                tin[w] = low[w] = timer
                up[w], parent[w] = e, v
                events.append({'type': 'visit', 'v': w, 'tin': timer, 'edge': e, 'from': v})
                stack.append((w, 0))
    return {'bridges': found, 'tin': tin, 'low': low, 'up': up, 'parent': parent, 'events': events}


def naive_bridges(n, edges):
    """Remove one edge at a time and BFS from one end: a bridge iff the other end is no longer reached.
    Returns (bridges in edge order, adjacency entries scanned in total)."""
    adj = adjacency(n, edges)
    found, scanned = [], 0
    for cut, (a, b) in enumerate(edges):
        if a == b:
            continue
        seen = [False] * n
        seen[a] = True
        q = deque([a])
        while q:
            v = q.popleft()
            for w, e in adj[v]:
                scanned += 1
                if e != cut and not seen[w]:
                    seen[w] = True
                    q.append(w)
        if not seen[b]:
            found.append(cut)
    return found, scanned


def groups_without(n, edges, cut):
    """Connected components once the edges in `cut` are removed, each sorted, ordered by their first vertex."""
    adj = adjacency(n, edges)
    comp, out = [-1] * n, []
    for s in range(n):
        if comp[s] >= 0:
            continue
        comp[s], members, q = len(out), [s], deque([s])
        while q:
            v = q.popleft()
            for w, e in adj[v]:
                if e not in cut and comp[w] < 0:
                    comp[w] = len(out)
                    members.append(w)
                    q.append(w)
        out.append(sorted(members))
    return out


def subtree_sizes(n, tin, parent):
    """Vertices in each DFS subtree (children finish before parents: add in decreasing tin)."""
    size = [1] * n
    for v in sorted(range(n), key=lambda x: -tin[x]):
        if parent[v] >= 0:
            size[parent[v]] += size[v]
    return size


def analyse(names, edges):
    n = len(names)
    adj = adjacency(n, edges)
    found, tin, low = find_bridges(adj, n)
    tr = trace_dfs(adj, n)
    wrong = trace_dfs(adj, n, skip='vertex')
    found_set = set(found)
    removals = sum(1 for a, b in edges if a != b)
    naive, naive_scanned = naive_bridges(n, edges) if removals <= NAIVE_MAX_EDGES else (None, None)
    size = subtree_sizes(n, tin, tr['parent'])
    comp_of = groups_without(n, edges, set())
    comp_size = {v: len(c) for c in comp_of for v in c}
    child = {tr['up'][v]: v for v in range(n) if tr['up'][v] >= 0}
    splits = [{'edge': e, 'parent': tr['parent'][child[e]], 'child': child[e],
               'parentSide': comp_size[child[e]] - size[child[e]], 'childSide': size[child[e]]} for e in found]
    return {
        'nodes': names, 'edges': [list(x) for x in edges], 'n': n, 'm': len(edges),
        'bridges': found, 'tin': tin, 'low': low, 'up': tr['up'], 'parent': tr['parent'], 'events': tr['events'],
        'treeEdges': sorted(tr['up'][v] for v in range(n) if tr['up'][v] >= 0),
        'backEdges': [ev['edge'] for ev in tr['events'] if ev['type'] == 'back'],
        'checks': [{'edge': tr['up'][v], 'parent': tr['parent'][v], 'child': v, 'low': low[v], 'tinParent': tin[tr['parent'][v]],
                    'bridge': low[v] > tin[tr['parent'][v]]} for v in sorted((v for v in range(n) if tr['parent'][v] >= 0), key=lambda x: tin[x])],
        'splits': splits,
        'groups': groups_without(n, edges, found_set),
        'components': len(comp_of),
        'naive': {'bridges': naive, 'removals': removals, 'scanned': naive_scanned,
                  'same': None if naive is None else sorted(naive) == sorted(found)},
        'dfsScanned': sum(len(a) for a in adj),
        'wrongSkipVertex': {'bridges': wrong['bridges'], 'low': wrong['low'], 'extra': [e for e in wrong['bridges'] if e not in found_set]},
        'traceMatches': tr['bridges'] == found and tr['tin'] == tin and tr['low'] == low,
    }


def report(r):
    nm, ed = r['nodes'], r['edges']
    E = lambda e: f'{nm[ed[e][0]]}-{nm[ed[e][1]]}'
    P = lambda u, v: f'{nm[u]}-{nm[v]}'
    by_tin = sorted(range(r['n']), key=lambda v: r['tin'][v])
    out = [f"graph: {r['n']} nodes, {r['m']} edges, {r['components']} component(s)",
           'dfs order (tin): ' + ', '.join(f"{nm[v]} {r['tin'][v]}" for v in by_tin),
           'tree edges: ' + ' '.join(P(r['parent'][v], v) for v in by_tin if r['parent'][v] >= 0),
           'back edges: ' + ' '.join(E(e) for e in r['backEdges']),
           'low: ' + ', '.join(f"{nm[v]} {r['low'][v]}" for v in by_tin),
           'checks (tree edge u-v: low[v] > tin[u]?):']
    out += [f"  {P(c['parent'], c['child'])}: {c['low']} > {c['tinParent']} {'yes -> bridge' if c['bridge'] else 'no'}" for c in r['checks']]
    out.append(f"bridges ({len(r['bridges'])}): " + ' '.join(P(s['parent'], s['child']) for s in r['splits']))
    out += [f"  cut {P(s['parent'], s['child'])}: {s['parentSide']} | {s['childSide']} buildings" for s in r['splits']]
    out.append(f"groups without bridges ({len(r['groups'])}): " + ' '.join('{' + ' '.join(nm[v] for v in g) + '}' for g in r['groups']))
    nv = r['naive']
    if nv['bridges'] is None:
        out.append(f"naive: skipped ({nv['removals']} > {NAIVE_MAX_EDGES} edges)")
        out.append(f"adjacency entries scanned: dfs {r['dfsScanned']}")
    else:
        out.append(f"naive: {nv['removals']} removals, {len(nv['bridges'])} disconnect, same bridges: {'yes' if nv['same'] else 'NO'}")
        out.append(f"adjacency entries scanned: dfs {r['dfsScanned']}, naive {nv['scanned']}")
    w = r['wrongSkipVertex']
    out.append(f"skip parent vertex (wrong): {len(w['bridges'])} bridges, extra: " + (' '.join(E(e) for e in w['extra']) or '-'))
    return '\n'.join(line.rstrip() for line in out) + '\n'


def main(argv):
    names, edges = read_graph(argv[1])
    r = analyse(names, edges)
    sys.stdout.write(report(r))
    if '--trace' in argv:
        with open(argv[argv.index('--trace') + 1], 'w', encoding='utf-8') as f:
            json.dump(r, f, ensure_ascii=False, indent=1)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
