// 단절선(bridge) 찾기 — 무방향 그래프, DFS 한 번과 low 값(Tarjan). C++17, 명시적 스택(깊은 그래프도 스택 넘침 없음).
// usage: bridges <graph file>      (형식은 code/python/bridges.py와 같다)
// stdout은 Python 판과 글자 그대로 같아야 한다(code/export.py가 diff로 확인).
// 다중 간선은 간선 번호로 구별한다(들어온 간선 하나만 건너뜀). 자기 간선은 인접 목록에 넣지 않는다.
// build: c++ -std=c++17 -O2 -Wall -Wextra -Werror bridges.cpp -o bridges
#include <algorithm>
#include <cstdio>
#include <deque>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

// the naive check is O(E·(V+E)); above this many edges it is skipped (same rule in the Python program)
constexpr int kNaiveMaxEdges = 2000;

using Adj = std::vector<std::vector<std::pair<int, int>>>;  // (이웃, 간선 번호)

static Adj adjacency(int n, const std::vector<std::pair<int, int>>& edges) {
  Adj adj(n);
  for (int e = 0; e < static_cast<int>(edges.size()); ++e) {
    auto [a, b] = edges[e];
    if (a == b) continue;
    adj[a].push_back({b, e});
    adj[b].push_back({a, e});
  }
  return adj;
}

struct Result {
  std::vector<int> found, tin, low, up, parent;
};

// skipVertex = the classic bug: skip every edge back to the parent vertex, not just the edge we came in by.
static Result findBridges(const Adj& adj, int n, bool skipVertex = false) {
  Result r;
  r.tin.assign(n, 0); r.low.assign(n, 0); r.up.assign(n, -1); r.parent.assign(n, -1);
  int timer = 0;
  for (int root = 0; root < n; ++root) {
    if (r.tin[root]) continue;
    r.tin[root] = r.low[root] = ++timer;
    // [film:dfs]
    struct Frame { int v, pe; size_t i; };
    std::vector<Frame> st{{root, -1, 0}};
    while (!st.empty()) {
      Frame& f = st.back();
      int v = f.v;
      if (f.i == adj[v].size()) {  // v is done
        int pe = f.pe;
        st.pop_back();
        if (st.empty()) continue;
        int u = st.back().v;
        r.low[u] = std::min(r.low[u], r.low[v]);
        if (r.low[v] > r.tin[u]) r.found.push_back(pe);
        continue;
      }
      auto [w, e] = adj[v][f.i++];
      if (skipVertex ? w == r.parent[v] : e == f.pe)
        continue;                  // came in by it
      if (r.tin[w]) {              // back edge
        r.low[v] = std::min(r.low[v], r.tin[w]);
      } else {                     // tree edge
        r.tin[w] = r.low[w] = ++timer;
        r.up[w] = e; r.parent[w] = v;
        st.push_back({w, e, 0});
      }
    }
    // [film:end]
  }
  return r;
}

// Remove one edge at a time, BFS from one end. Returns bridges in edge order; counts adjacency entries scanned.
static std::vector<int> naiveBridges(int n, const std::vector<std::pair<int, int>>& edges, long long& scanned) {
  Adj adj = adjacency(n, edges);
  std::vector<int> found;
  scanned = 0;
  for (int cut = 0; cut < static_cast<int>(edges.size()); ++cut) {
    auto [a, b] = edges[cut];
    if (a == b) continue;
    std::vector<char> seen(n, 0);
    seen[a] = 1;
    std::deque<int> q{a};
    while (!q.empty()) {
      int v = q.front(); q.pop_front();
      for (auto [w, e] : adj[v]) {
        ++scanned;
        if (e != cut && !seen[w]) { seen[w] = 1; q.push_back(w); }
      }
    }
    if (!seen[b]) found.push_back(cut);
  }
  return found;
}

static std::vector<std::vector<int>> groupsWithout(int n, const std::vector<std::pair<int, int>>& edges, const std::set<int>& cut) {
  Adj adj = adjacency(n, edges);
  std::vector<int> comp(n, -1);
  std::vector<std::vector<int>> out;
  for (int s = 0; s < n; ++s) {
    if (comp[s] >= 0) continue;
    int id = static_cast<int>(out.size());
    comp[s] = id;
    std::vector<int> members{s};
    std::deque<int> q{s};
    while (!q.empty()) {
      int v = q.front(); q.pop_front();
      for (auto [w, e] : adj[v])
        if (!cut.count(e) && comp[w] < 0) { comp[w] = id; members.push_back(w); q.push_back(w); }
    }
    std::sort(members.begin(), members.end());
    out.push_back(members);
  }
  return out;
}

int main(int argc, char** argv) {
  if (argc < 2) { std::cerr << "usage: bridges <graph file>\n"; return 2; }
  std::ifstream in(argv[1]);
  if (!in) { std::cerr << "cannot open " << argv[1] << "\n"; return 2; }
  std::vector<std::string> nm;
  std::map<std::string, int> ix;
  std::vector<std::pair<int, int>> edges;
  for (std::string raw; std::getline(in, raw);) {
    std::istringstream ss(raw.substr(0, raw.find('#')));
    std::vector<std::string> w;
    for (std::string x; ss >> x;) w.push_back(x);
    if (w.empty()) continue;
    if (w[0] == "nodes") {
      for (size_t i = 1; i < w.size(); ++i) { ix[w[i]] = static_cast<int>(nm.size()); nm.push_back(w[i]); }
      continue;
    }
    edges.push_back({ix.at(w[0]), ix.at(w[1])});
  }
  const int n = static_cast<int>(nm.size()), m = static_cast<int>(edges.size());
  Adj adj = adjacency(n, edges);
  Result r = findBridges(adj, n);
  Result wrong = findBridges(adj, n, true);

  auto P = [&](int u, int v) { return nm[u] + "-" + nm[v]; };
  auto E = [&](int e) { return P(edges[e].first, edges[e].second); };
  std::vector<int> byTin(n);
  for (int v = 0; v < n; ++v) byTin[v] = v;
  std::sort(byTin.begin(), byTin.end(), [&](int a, int b) { return r.tin[a] < r.tin[b]; });

  // back edges in the order the DFS meets them: replay the same scan (same adjacency order, same skip rule) and keep
  // the non-tree edges that reach an ancestor (smaller tin), as the Python trace does.
  std::vector<int> back;
  {
    std::vector<size_t> pos(n, 0);
    std::vector<char> seen(n, 0);
    for (int root = 0; root < n; ++root) {
      if (seen[root]) continue;
      seen[root] = 1;
      std::vector<int> st{root};
      while (!st.empty()) {
        int v = st.back();
        if (pos[v] == adj[v].size()) { st.pop_back(); continue; }
        auto [w, e] = adj[v][pos[v]++];
        if (e == r.up[v]) continue;
        if (seen[w]) { if (r.tin[w] < r.tin[v]) back.push_back(e); }
        else { seen[w] = 1; st.push_back(w); }
      }
    }
  }
  // subtree sizes and component sizes
  std::vector<int> size(n, 1);
  for (int k = n - 1; k >= 0; --k) { int v = byTin[k]; if (r.parent[v] >= 0) size[r.parent[v]] += size[v]; }
  auto comps = groupsWithout(n, edges, {});
  std::vector<int> compSize(n);
  for (auto& c : comps) for (int v : c) compSize[v] = static_cast<int>(c.size());
  std::map<int, int> child;
  for (int v = 0; v < n; ++v) if (r.up[v] >= 0) child[r.up[v]] = v;

  std::ostringstream o;
  o << "graph: " << n << " nodes, " << m << " edges, " << comps.size() << " component(s)\n";
  o << "dfs order (tin):" << (n ? " " : "");
  for (int k = 0; k < n; ++k) o << (k ? ", " : "") << nm[byTin[k]] << " " << r.tin[byTin[k]];
  o << "\ntree edges:";
  for (int v : byTin) if (r.parent[v] >= 0) o << " " << P(r.parent[v], v);
  o << "\nback edges:";
  for (int e : back) o << " " << E(e);
  o << "\nlow:" << (n ? " " : "");
  for (int k = 0; k < n; ++k) o << (k ? ", " : "") << nm[byTin[k]] << " " << r.low[byTin[k]];
  o << "\nchecks (tree edge u-v: low[v] > tin[u]?):\n";
  for (int v : byTin) {
    if (r.parent[v] < 0) continue;
    int u = r.parent[v];
    o << "  " << P(u, v) << ": " << r.low[v] << " > " << r.tin[u] << (r.low[v] > r.tin[u] ? " yes -> bridge" : " no") << "\n";
  }
  o << "bridges (" << r.found.size() << "):";
  for (int e : r.found) o << " " << P(r.parent[child[e]], child[e]);
  o << "\n";
  for (int e : r.found) {
    int v = child[e];
    o << "  cut " << P(r.parent[v], v) << ": " << compSize[v] - size[v] << " | " << size[v] << " buildings\n";
  }
  auto groups = groupsWithout(n, edges, std::set<int>(r.found.begin(), r.found.end()));
  o << "groups without bridges (" << groups.size() << "):";
  for (auto& g : groups) {
    o << " {";
    for (size_t i = 0; i < g.size(); ++i) o << (i ? " " : "") << nm[g[i]];
    o << "}";
  }
  int removals = 0, dfsScanned = 0;
  for (auto [x, y] : edges) removals += x != y;
  for (auto& l : adj) dfsScanned += static_cast<int>(l.size());
  if (removals > kNaiveMaxEdges) {
    o << "\nnaive: skipped (" << removals << " > " << kNaiveMaxEdges << " edges)\n";
    o << "adjacency entries scanned: dfs " << dfsScanned << "\n";
  } else {
    long long scanned = 0;
    std::vector<int> naive = naiveBridges(n, edges, scanned);
    std::vector<int> a = naive, b = r.found;
    std::sort(a.begin(), a.end()); std::sort(b.begin(), b.end());
    o << "\nnaive: " << removals << " removals, " << naive.size() << " disconnect, same bridges: " << (a == b ? "yes" : "NO") << "\n";
    o << "adjacency entries scanned: dfs " << dfsScanned << ", naive " << scanned << "\n";
  }
  std::vector<int> extra;
  const std::set<int> right(r.found.begin(), r.found.end());
  for (int e : wrong.found) if (!right.count(e)) extra.push_back(e);
  o << "skip parent vertex (wrong): " << wrong.found.size() << " bridges, extra:";
  if (extra.empty()) o << " -";
  for (int e : extra) o << " " << E(e);
  o << "\n";
  std::fputs(o.str().c_str(), stdout);
  return 0;
}
