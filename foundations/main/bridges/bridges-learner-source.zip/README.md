# 단절선: 간선을 끊으면 연결이 나뉘는 곳 찾기 — 소스 패키지

AI 기본기 교육 영상, 트랙 algorithms · 강의 14(공개 패키징 메타데이터, 화면에는 쓰지 않음). **소스 단계**다. 녹음·음악·렌더는 아직 없다(아래 "다음 단계").

구성: **핵심 개념 요약 → 구체적 사용 상황(캠퍼스 네트워크) → 본 강의 8장(정의 · 하나씩 지워 보기 · DFS 트리 · low 값 · 판정 · 다중 간선 · 파이썬 코드 · C++17) → 정리·실습 → 엔드 카드**. 장면별 화면 카피와 발화는 [scenario.md](scenario.md), 컷 단위 계획은 [shotlist.md](shotlist.md), 연출 결정은 [direction.md](direction.md).

## 한 번의 실제 실행이 원천이다

화면의 방문 번호, low, 판정, 단절선, 덩어리, 탐색 횟수, 코드 줄, 출력 줄은 모두 `data/film-data.json`에서 읽는다. 이 파일은 `code/export.py`가 Python 예제를 실제로 돌려 만들고, 같은 입력으로 C++17 예제를 컴파일·실행해 출력이 한 글자도 다르지 않은지 확인한 뒤에만 쓴다. 화면 문자열은 `plan.py`가 같은 실행값으로 만들어 `shots.json`의 `screen`에 넣고, `film.js`는 그것만 그린다. 발화의 숫자·이름은 `voice/script.json`의 `claims` 36개로 같은 파일과 대조한다(테스트).

| 무엇 | 파일 |
|---|---|
| 예제 입력 | `code/fixtures/campus.graph` — 건물 9개(정점), 케이블 11가닥(간선), 기숙사–식당은 두 가닥 |
| Python 예제 | `code/python/bridges.py` — 반복 DFS + low(`find_bridges`, `[film:dfs]` 사이가 화면에 나오는 줄), 영상용 기록, 단순한 방법, 부모 정점을 건너뛰는 흔한 버그 |
| C++17 예제 | `code/cpp/bridges.cpp` — 같은 알고리즘, 같은 출력 (`-std=c++17 -O2 -Wall -Wextra -Werror`) |
| 실제 실행 결과 | `code/expected/python-stdout.txt`, `code/expected/cpp-stdout.txt` (22줄, 동일) |
| 영상 데이터 | `data/film-data.json` (생성물, 손대지 않음) — `facts`는 이름으로 적은 요약 |
| 대본·읽기·큐 | `voice/script.json` — `text`(원문·자막), `tts`(한글 읽기), `cues`(그림이 놓이는 단어), `readings`(승인 필요 읽기), `claims` |
| 전사 → 큐 시각 | `voice/cues.py` |
| 기획 | `plan.py` → `shots.json`(샷 25개 + `screen` 카피 + `voice` 시각), `scenario.md` · `shotlist.md`(shotlint 생성) |
| 연출(그림) | `film.js` — 엔진 `engine/*`, 컴포넌트 `system/components/*`, 토큰 `system/tokens.json`만 사용. 공유 파일은 바꾸지 않았다 |
| 실습 | `practice/exercise_bridges.py`(빈칸 3곳), `practice/solution_bridges.py`, `practice/check.py` |
| 소스 테스트 | `tests/test_bridges.py`, `tests/test_film_data.py`, `tests/test_practice.py`, `tests/film_smoke.mjs`, `tests/bundle_check.cjs` |
| 작성 기록 | `qa/author_check.py` → `qa/author-result.json` (파일 해시·명령·exit), `qa/shotlint.json` |

## 확인 명령 (저장소 루트에서)

```sh
python3 films/bridges-20261109/code/export.py --check        # Python·C++ 다시 실행 → 출력 동일, 데이터 최신
python3 films/bridges-20261109/plan.py --check               # shots.json·scenario.md 최신
python3 pipeline/shotlint.py bridges-20261109                # 샷리스트 검사(plan)
python3 -m unittest discover -s films/bridges-20261109/tests -p 'test_*.py' -v
node films/bridges-20261109/tests/film_smoke.mjs             # 렌더 없이 모든 장면을 모의 캔버스에 그려 검사(16:9, 9:16)
node films/bridges-20261109/tests/bundle_check.cjs           # engine/main.js + film.js 번들(메모리, 파일 안 씀)
python3 films/bridges-20261109/practice/check.py films/bridges-20261109/practice/solution_bridges.py   # 정답 → CHECK PASS
python3 films/bridges-20261109/practice/check.py films/bridges-20261109/practice/exercise_bridges.py   # 빈칸 → FAIL(정상)
python3 films/bridges-20261109/qa/author_check.py            # 위 전부 실행 → qa/author-result.json
```

예제를 바꾸면 `code/export.py` → `plan.py` 순서로 다시 만든다. 대본의 숫자를 바꾸면 `claims`도 고친다.

## 다음 단계 (승인 필요, 이 패키지에서는 하지 않음)

1. **독립 검수**: 알고리즘 설명(정의·low·판정·다중 간선)의 정확성, 대본·화면 값 ↔ 실행 결과, 요청 순서(요약 → 사용 상황 → 본 강의).
2. **읽기 승인**: `voice/script.json`의 `readings` 중 `approve: true`(low, u·v, C++17).
3. **목소리 고르기·녹음(유료)**: 후보 3–5개를 summary 첫 두 문장으로 비교 → 장면당 한 파일, `tts` 문장 그대로.
   `python3 pipeline/elevenlabs.py tts <voice_id> "<tts>" films/bridges-20261109/voice/<file> --model eleven_v4 --stability 0.55 --style 0.2 --speed 0.95`
   파일 이름은 `voice/script.json`의 `file`(seg-01-summary.mp3 … seg-12-end.mp3).
4. **전사**: 장면마다 Scribe 결과를 `voice/scribe/<scene>.json`(`{"words": [{"text","start","end","type"}]}`)으로 둔다 → `python3 films/bridges-20261109/plan.py`가 실측 단어 시각과 녹음 길이로 장면 길이·큐를 다시 쓴다.
5. **음악(유료)**: `shots.json` `music.brief`(100 BPM 차분한 베드) → `films/bridges-20261109/music/score.mp3` → `pipeline/measure_music.py`로 위상을 재서 `plan.py`의 `offset`에 적는다.
6. **스틸 게이트(사람 확인)**: `node pipeline/build.cjs bridges-20261109 && node pipeline/render.cjs bridges-20261109 --format 16x9 --stills` → `contact.py` 시트, 9:16도.
7. **제작·검증**: `sh pipeline/make.sh bridges-20261109 16x9 9x16` → `verify.py` PASS → `shotlint.py bridges-20261109 --video 16x9 9x16` → `REVIEW.md`. 기술 PASS는 승인이 아니다.

## 알려진 한계 (소스 단계)

- 단어 시각과 길이(약 478초)는 **추정값**(초당 5.6음절)이다. 실제 녹음 뒤 바뀐다.
- 레이아웃은 모의 캔버스(한글 0.95em·라틴 0.6em 근사)로만 검사했다. 실제 글자 폭·겹침·가독성, 9:16 그래프 배치는 스틸 게이트에서 눈으로 확인해야 한다.
- 녹음과 음악 파일이 없어서 지금은 `audio.py`가 이 영상을 섞을 수 없다(목소리 큐가 `voice/*.mp3`를 가리킴).
- 단순한 방법(간선마다 BFS)은 O(E·(V+E))라 간선 2000개를 넘으면 두 프로그램 모두 건너뛴다(같은 규칙, 출력에 표시).
- `.scope-brief/`는 작업 도구(훅)가 이 폴더에 남긴 상태 파일로, 패키지 내용이 아니다(해시에서 제외).
