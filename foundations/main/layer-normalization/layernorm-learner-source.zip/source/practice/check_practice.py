"""실습 확인: 내 레이어 정규화가 예제(example/results/*.py.json)와 칸마다 같은지 본다.

usage:
  python3 films/layer-normalization-20261112/practice/check_practice.py [내_파일.py]          # 기본: practice/layernorm_practice.py
  python3 films/layer-normalization-20261112/practice/check_practice.py --cpp [내_파일.cpp]   # 기본: practice/layernorm_practice.cpp
세 경우를 본다: 토큰 세 개(γ = 1, β = 0), 같은 토큰에 영상의 γ·β, 모든 값이 같은 토큰(ε이 필요한 경우).
처음 어긋나는 토큰·칸과, 흔한 실수(d − 1로 나눔, ε을 제곱근 밖에 더함, 토큰이 아니라 특징 칸으로 정규화, β를 먼저 더함)
중 어느 것과 같은지 알려 준다. 맞으면 exit 0, 아니면 exit 1.
"""
import importlib.util
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILM = HERE.parent
RES = FILM / 'example' / 'results'
TOKENS = FILM / 'example' / 'fixtures' / 'tokens.csv'
FLAT = FILM / 'example' / 'fixtures' / 'flat_token.csv'
EPS = 1e-5
AFF = json.loads((RES / 'ln_affine.py.json').read_text(encoding='utf-8'))
GAMMA, BETA = AFF['gamma'], AFF['beta']
CASES = [  # (이름, fixture, gamma, beta, 정답 결과 파일)
    ('토큰 세 개 · γ = 1, β = 0', TOKENS, None, None, 'ln.py.json'),
    (f'γ = {GAMMA}, β = {BETA}', TOKENS, GAMMA, BETA, 'ln_affine.py.json'),
    ('모든 값이 같은 토큰', FLAT, None, None, 'ln_flat.py.json'),
]


def rows_of(path):
    lines = [ln.strip() for ln in path.read_text(encoding='utf-8').splitlines() if ln.strip() and not ln.startswith('#')]
    return [(c[0], [float(v) for v in c[1:]]) for c in (ln.split(',') for ln in lines[1:])]


def close(a, b, tol=1e-9):
    return isinstance(a, (int, float)) and math.isfinite(a) and abs(a - b) <= tol * max(1.0, abs(b))


# ---- common mistakes, computed here so the hint can name the one the learner made ----
def _stats(x, ddof=0):
    mu = sum(x) / len(x)
    return mu, sum((v - mu) ** 2 for v in x) / (len(x) - ddof)


def wrong(rows, kind, gamma, beta):
    d = len(rows[0][1])
    gamma, beta = gamma or [1.0] * d, beta or [0.0] * d
    out = []
    for _, x in rows:
        try:
            if kind == 'unbiased':
                mu, var = _stats(x, 1)
                xh = [(v - mu) / math.sqrt(var + EPS) for v in x]
            elif kind == 'eps_outside':
                mu, var = _stats(x)
                xh = [(v - mu) / (math.sqrt(var) + EPS) for v in x]
            elif kind == 'feature_axis':
                cols = [_stats([r[1][j] for r in rows]) for j in range(d)]
                xh = [(x[j] - cols[j][0]) / math.sqrt(cols[j][1] + EPS) for j in range(d)]
            elif kind == 'no_affine':
                mu, var = _stats(x)
                out.append([(v - mu) / math.sqrt(var + EPS) for v in x])
                continue
            elif kind == 'beta_first':
                mu, var = _stats(x)
                out.append([g * ((v - mu) / math.sqrt(var + EPS) + b) for v, g, b in zip(x, gamma, beta)])
                continue
            out.append([g * h + b for h, g, b in zip(xh, gamma, beta)])
        except ZeroDivisionError:
            out.append([math.nan] * d)
    return out


HINTS = {
    'unbiased': 'TODO 1: 분산을 d − 1로 나눴습니다. 레이어 정규화는 d로 나눕니다(편향 분산).',
    'eps_outside': 'TODO 2: ε을 제곱근 밖에 더했습니다. √(σ² + ε)처럼 제곱근 안에 더합니다.',
    'feature_axis': 'TODO 1: 특징 칸마다 여러 토큰으로 통계를 냈습니다(배치 정규화 방식). 토큰 하나의 벡터 안에서 구합니다.',
    'no_affine': 'TODO 2: γ와 β를 쓰지 않았습니다. y = γ · x̂ + β입니다.',
    'beta_first': 'TODO 2: β를 먼저 더하고 γ를 곱했습니다. γ를 곱한 다음 β를 더합니다.',
}


def diagnose(rows, got, gamma, beta):
    for kind in HINTS:
        ref = wrong(rows, kind, gamma, beta)
        if all(close(a, b) for ga, rb in zip(got, ref) for a, b in zip(ga, rb)):
            return HINTS[kind]
    return 'TODO 1(μ, σ² = ÷ d)과 TODO 2(x̂ = (x − μ) / √(σ² + ε), y = γ · x̂ + β)를 다시 보세요.'


def compare(case, rows, got, gamma, beta):
    want = [t['y'] for t in json.loads((RES / case[4]).read_text(encoding='utf-8'))['tokens']]
    if len(got) != len(want):
        return f'{case[0]}: 토큰 {len(want)}개 결과가 필요합니다(받은 것 {len(got)}개).'
    for (name, _), g, w in zip(rows, got, want):
        for j, (a, b) in enumerate(zip(g, w)):
            if not close(a, b):
                return f'{case[0]}: 토큰 {name}, {j + 1}번째 칸 {a!r} (정답 {b!r}). {diagnose(rows, got, gamma, beta)}'
    return None


def check_py(path):
    spec = importlib.util.spec_from_file_location('learner', path)
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
        for case in CASES:
            rows = rows_of(case[1])
            try:
                got = [list(mod.layer_norm(x, case[2], case[3], EPS)) for _, x in rows]
            except ZeroDivisionError:
                return f'{case[0]}: 0으로 나눴습니다. ε을 분산에 더한 뒤 제곱근을 구하세요(TODO 2).'
            err = compare(case, rows, got, case[2], case[3])
            if err:
                return err
    except NotImplementedError as e:
        return f'아직 TODO가 남았습니다: {e}'
    return None


def check_cpp(path):
    cxx = shutil.which('c++') or shutil.which('clang++') or shutil.which('g++')
    if not cxx:
        return 'C++ 컴파일러(c++)가 없습니다.'
    with tempfile.TemporaryDirectory() as tmp:
        exe = Path(tmp) / 'learner'
        b = subprocess.run([cxx, '-std=c++17', '-O2', '-ffp-contract=off', '-Wall', '-Wextra', '-o', str(exe), str(path)], capture_output=True, text=True)
        if b.returncode:
            return '컴파일 실패:\n' + b.stderr[-1500:]
        for case in CASES:
            rows = rows_of(case[1])
            args = [str(exe), str(case[1])] + ([','.join(map(repr, case[2])), ','.join(map(repr, case[3]))] if case[2] else [])
            r = subprocess.run(args, capture_output=True, text=True)
            if r.returncode:
                return f'아직 TODO가 남았거나 실행이 실패했습니다(exit {r.returncode}): {r.stderr.strip()[-300:]}'
            got = [[float(v) for v in ln.split()[1:]] for ln in r.stdout.splitlines() if ln.strip()]
            err = compare(case, rows, got, case[2], case[3])
            if err:
                return err
    return None


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    cpp = '--cpp' in argv
    rest = [a for a in argv if a != '--cpp']
    path = Path(rest[0]) if rest else HERE / ('layernorm_practice.cpp' if cpp else 'layernorm_practice.py')
    err = check_cpp(path) if cpp else check_py(path)
    if err:
        print('FAIL', path.name, '—', err)
        return 1
    ln = json.loads((RES / 'ln.py.json').read_text(encoding='utf-8'))['tokens']
    print(f'PASS {path.name} — 세 경우 모두 예제와 같습니다. 오늘 → {[round(v, 2) for v in ln[0]["y"]]}, '
          f'날씨가 → {[round(v, 2) for v in ln[1]["y"]]}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
