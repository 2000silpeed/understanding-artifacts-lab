// 실습: 레이어 정규화를 직접 구현한다 (C++17, 표준 라이브러리만).
// TODO 두 곳을 채운 뒤 확인한다:
//   python3 films/layer-normalization-20261112/practice/check_practice.py --cpp
// 실행 형식: ./a.out <csv> [gamma] [beta]   (gamma·beta는 "1,1,2,1"처럼 쉼표로)
// 출력: 토큰마다 한 줄, "이름 y1 y2 y3 y4" (%.17g)
// 규칙: 통계는 토큰 하나의 벡터 안에서만, 분산은 ÷ d, ε(1e-5)은 제곱근 안에.
#include <cmath>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

using Vec = std::vector<double>;

// x의 평균 μ와 분산 σ²(÷ d).
std::pair<double, double> mean_var(const Vec& x) {
    // TODO 1: μ = (1/d) Σ x_j,  σ² = (1/d) Σ (x_j − μ)²
    (void)x;
    throw std::runtime_error("TODO 1: 평균과 분산(÷ d)을 구하세요");
}

// y_j = γ_j · (x_j − μ) / √(σ² + ε) + β_j
Vec layer_norm(const Vec& x, const Vec& gamma, const Vec& beta, double eps) {
    auto mv = mean_var(x);
    // TODO 2: 정규화하고 γ를 곱한 뒤 β를 더한다
    (void)mv; (void)gamma; (void)beta; (void)eps;
    throw std::runtime_error("TODO 2: 정규화하고 γ를 곱한 뒤 β를 더하세요");
}

static Vec floats(const std::string& s) {
    Vec v;
    std::istringstream in(s);
    std::string p;
    while (std::getline(in, p, ',')) v.push_back(std::stod(p));
    return v;
}

int main(int argc, char** argv) {
    try {
        if (argc < 2) throw std::runtime_error("usage: practice <csv> [gamma] [beta]");
        std::ifstream fh(argv[1]);
        std::string line;
        bool header = true;
        while (std::getline(fh, line)) {
            if (line.empty() || line[0] == '#') continue;
            if (header) { header = false; continue; }
            std::istringstream in(line);
            std::string name, cell;
            std::getline(in, name, ',');
            Vec x;
            while (std::getline(in, cell, ',')) x.push_back(std::stod(cell));
            Vec gamma = argc > 2 ? floats(argv[2]) : Vec(x.size(), 1.0);
            Vec beta = argc > 3 ? floats(argv[3]) : Vec(x.size(), 0.0);
            Vec y = layer_norm(x, gamma, beta, 1e-5);
            std::printf("%s", name.c_str());
            for (double v : y) std::printf(" %.17g", v);
            std::printf("\n");
        }
        return 0;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "%s\n", e.what());
        return 3;
    }
}
