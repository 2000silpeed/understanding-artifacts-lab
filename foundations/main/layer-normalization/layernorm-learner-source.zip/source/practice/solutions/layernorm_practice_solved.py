"""실습 정답: practice/layernorm_practice.py의 TODO 두 곳을 채운 것.

    python3 films/layer-normalization-20261112/practice/check_practice.py films/layer-normalization-20261112/practice/solutions/layernorm_practice_solved.py
"""
import math


def mean_var(x):
    """x의 평균 μ와 분산 σ²(÷ d)를 돌려준다."""
    d = len(x)
    mu = 0.0
    for v in x:
        mu += v
    mu /= d
    var = 0.0
    for v in x:
        var += (v - mu) * (v - mu)
    return mu, var / d


def layer_norm(x, gamma=None, beta=None, eps=1e-5):
    """토큰 하나의 벡터 x → y = γ · (x − μ) / √(σ² + ε) + β (칸마다)."""
    d = len(x)
    gamma = gamma or [1.0] * d
    beta = beta or [0.0] * d
    mu, var = mean_var(x)
    denom = math.sqrt(var + eps)
    return [g * ((v - mu) / denom) + b for v, g, b in zip(x, gamma, beta)]


if __name__ == '__main__':
    print(layer_norm([2.0, 4.0, 6.0, 8.0]))
    print(layer_norm([20.0, 40.0, 60.0, 80.0]))
    print(math.isclose(sum(layer_norm([1.0, 9.0, 5.0, 5.0])), 0.0, abs_tol=1e-12))
