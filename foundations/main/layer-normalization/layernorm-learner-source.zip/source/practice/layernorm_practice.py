"""실습: 레이어 정규화를 직접 구현한다 (Python 3, 표준 라이브러리만).

TODO 두 곳을 채운 뒤 확인한다:
    python3 films/layer-normalization-20261112/practice/check_practice.py

check_practice.py는 example/fixtures/tokens.csv의 세 토큰(오늘·날씨가·맑다)과 모든 값이 같은 토큰으로
layer_norm()을 부르고, 예제 실행 결과(example/results/ln.py.json 등)와 칸마다 비교한다.
기본 γ = 1, β = 0, ε = 1e-5 말고도 영상의 γ = [1, 1, 2, 1], β = [0, 0.5, 0, 0]으로도 확인한다.

규칙
- 통계는 토큰 하나의 벡터 x 안에서만 낸다(다른 토큰을 보지 않는다).
- 분산은 d로 나눈다(d − 1이 아니다).
- ε은 제곱근 안에 더한다: √(σ² + ε).
"""
import math


def mean_var(x):
    """x의 평균 μ와 분산 σ²(÷ d)를 돌려준다."""
    # TODO 1: μ = (1/d) Σ x_j,  σ² = (1/d) Σ (x_j − μ)²
    raise NotImplementedError('TODO 1: 평균과 분산(÷ d)을 구하세요')


def layer_norm(x, gamma=None, beta=None, eps=1e-5):
    """토큰 하나의 벡터 x → y = γ · (x − μ) / √(σ² + ε) + β (칸마다)."""
    d = len(x)
    gamma = gamma or [1.0] * d
    beta = beta or [0.0] * d
    mu, var = mean_var(x)
    # TODO 2: x̂_j = (x_j − μ) / √(σ² + ε), 그다음 y_j = γ_j · x̂_j + β_j
    raise NotImplementedError('TODO 2: 정규화하고 γ를 곱한 뒤 β를 더하세요')


if __name__ == '__main__':
    print(layer_norm([2.0, 4.0, 6.0, 8.0]))   # 기대: 약 [-1.34, -0.45, 0.45, 1.34]
    print(layer_norm([20.0, 40.0, 60.0, 80.0]))  # 열 배 큰 벡터도 거의 같은 결과
    print(math.isclose(sum(layer_norm([1.0, 9.0, 5.0, 5.0])), 0.0, abs_tol=1e-12))
