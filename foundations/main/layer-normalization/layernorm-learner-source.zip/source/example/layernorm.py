"""레이어 정규화 예제 (Python 3, 표준 라이브러리만). 영상의 모든 숫자는 이 파일의 실행 결과에서 온다.

토큰 하나의 은닉 벡터 x (d개 특징)에 대해
    μ = (1/d) Σ x_j                      평균: 그 토큰의 특징 축으로만
    σ² = (1/d) Σ (x_j − μ)²             분산: d로 나눈다 (d − 1이 아님, torch.nn.LayerNorm과 같은 편향 추정)
    x̂_j = (x_j − μ) / √(σ² + ε)         ε은 제곱근 안에 더한다 (기본 1e-5, torch 기본값과 같음)
    y_j = γ_j · x̂_j + β_j               γ, β는 특징마다 하나, 모든 토큰이 같은 값을 쓴다

비교용으로 두 가지를 더 계산한다.
  --mode batch  배치 정규화 방식(학습 모드의 배치 통계): 특징 칸 j마다 배치 안 모든 토큰으로 평균·분산을 낸다.
                그래서 한 토큰의 결과가 같은 배치에 있는 다른 토큰에 따라 바뀐다.
  --mode rms    RMSNorm: 평균을 빼지 않고 √(mean(x²) + ε)로만 나눈 뒤 γ를 곱한다 (β 없음).

usage:
  python3 layernorm.py run --data fixtures/tokens.csv [--mode layer|batch|rms] [--eps 1e-5]
                           [--gamma 1,1,2,1] [--beta 0,0.5,0,0] [--select 0,2]
출력은 JSON(stdout). 합은 왼쪽부터 차례로 더한다(C++ 구현 layernorm.cpp와 같은 순서, 그래서 두 구현의 숫자가 같다).
"""
import argparse
import json
import math
import sys


def load(path, select=None):
    """CSV(# 주석, 머리줄 token,x1,…) → [(이름, [float…])]."""
    rows = []
    with open(path, encoding='utf-8') as fh:
        lines = [ln.strip() for ln in fh if ln.strip() and not ln.startswith('#')]
    for ln in lines[1:]:
        name, *vals = ln.split(',')
        rows.append((name, [float(v) for v in vals]))
    if select is not None:
        rows = [rows[i] for i in select]
    if not rows or len({len(v) for _, v in rows}) != 1:
        raise ValueError('every token needs the same number of features')
    return rows


def total(xs):
    """Left-to-right sum (Python 3.12+ sum() of floats is compensated; the C++ loop is not)."""
    acc = 0.0
    for v in xs:
        acc += v
    return acc


def mean_var(xs):
    """Mean and biased variance (÷ n)."""
    n = len(xs)
    mu = total(xs) / n
    return mu, total([(v - mu) * (v - mu) for v in xs]) / n


def layer_norm(x, gamma, beta, eps):
    """One token's vector → its statistics and output. Uses nothing but x itself (and the shared γ, β)."""
    mu, var = mean_var(x)
    denom = math.sqrt(var + eps)
    xhat = [(v - mu) / denom for v in x]
    y = [g * h + b for g, h, b in zip(gamma, xhat, beta)]
    m2, v2 = mean_var(xhat)
    return {'mean': mu, 'var': var, 'denom': denom, 'xhat': xhat, 'y': y, 'xhatMean': m2, 'xhatVar': v2}


def batch_norm(rows, gamma, beta, eps):
    """Feature column j over every token of the batch (training-mode batch statistics)."""
    d = len(rows[0][1])
    feats = []
    for j in range(d):
        mu, var = mean_var([x[j] for _, x in rows])
        feats.append({'mean': mu, 'var': var, 'denom': math.sqrt(var + eps)})
    out = []
    for _, x in rows:
        xhat = [(x[j] - feats[j]['mean']) / feats[j]['denom'] for j in range(d)]
        out.append({'xhat': xhat, 'y': [gamma[j] * xhat[j] + beta[j] for j in range(d)]})
    return feats, out


def rms_norm(x, gamma, eps):
    ms = total([v * v for v in x]) / len(x)
    denom = math.sqrt(ms + eps)
    y = [g * v / denom for g, v in zip(gamma, x)]
    return {'meanSquare': ms, 'denom': denom, 'y': y, 'yMean': total(y) / len(y)}


def compute(rows, mode='layer', eps=1e-5, gamma=None, beta=None):
    d = len(rows[0][1])
    gamma = gamma or [1.0] * d
    beta = beta or [0.0] * d
    if len(gamma) != d or len(beta) != d:
        raise ValueError(f'gamma and beta need {d} values')
    res = {'mode': mode, 'eps': eps, 'd': d, 'gamma': gamma, 'beta': beta, 'tokens': []}
    if mode == 'layer':
        for name, x in rows:
            res['tokens'].append({'name': name, 'x': x, **layer_norm(x, gamma, beta, eps)})
    elif mode == 'batch':
        feats, out = batch_norm(rows, gamma, beta, eps)
        res['features'] = feats
        for (name, x), o in zip(rows, out):
            res['tokens'].append({'name': name, 'x': x, **o})
    elif mode == 'rms':
        if any(b != 0.0 for b in beta):
            raise ValueError('RMSNorm has no beta')
        for name, x in rows:
            res['tokens'].append({'name': name, 'x': x, **rms_norm(x, gamma, eps)})
    else:
        raise ValueError(f'unknown mode {mode}')
    return res


def floats(text):
    return [float(v) for v in text.split(',')] if text else None


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    sub = ap.add_subparsers(dest='cmd', required=True)
    r = sub.add_parser('run')
    r.add_argument('--data', required=True)
    r.add_argument('--mode', default='layer', choices=['layer', 'batch', 'rms'])
    r.add_argument('--eps', type=float, default=1e-5)
    r.add_argument('--gamma')
    r.add_argument('--beta')
    r.add_argument('--select', help='comma-separated token indices to put in the batch')
    a = ap.parse_args(argv)
    select = [int(i) for i in a.select.split(',')] if a.select else None
    res = compute(load(a.data, select), a.mode, a.eps, floats(a.gamma), floats(a.beta))
    json.dump(res, sys.stdout, ensure_ascii=False, indent=1)
    sys.stdout.write('\n')


if __name__ == '__main__':
    main()
