// 레이어 정규화 예제의 계산 (C++17, 표준 라이브러리만). layernorm.py와 같은 식, 같은 덧셈 순서.
//   μ = (1/d) Σ x_j,  σ² = (1/d) Σ (x_j − μ)²,  x̂_j = (x_j − μ) / √(σ² + ε),  y_j = γ_j · x̂_j + β_j
// batch_norm: 특징 칸 j마다 배치 안 모든 토큰으로 통계를 낸다(학습 모드 배치 통계, 비교용).
// rms_norm:   평균을 빼지 않고 √(mean(x²) + ε)로 나눈 뒤 γ를 곱한다.
#pragma once
#include <cmath>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace ln {

using Vec = std::vector<double>;

struct Token {
    std::string name;
    Vec x;
};

// 왼쪽부터 차례로 더한다 (Python 쪽 total()과 같은 순서).
inline double total(const Vec& xs) {
    double acc = 0.0;
    for (double v : xs) acc += v;
    return acc;
}

// 평균과 편향 분산(÷ n).
inline std::pair<double, double> mean_var(const Vec& xs) {
    const double n = static_cast<double>(xs.size());
    const double mu = total(xs) / n;
    Vec sq;
    sq.reserve(xs.size());
    for (double v : xs) sq.push_back((v - mu) * (v - mu));
    return {mu, total(sq) / n};
}

struct LayerOut {
    double mean, var, denom;
    Vec xhat, y;
    double xhatMean, xhatVar;
};

// 토큰 하나의 벡터만 쓴다 (공유하는 γ, β 말고는 다른 토큰을 보지 않는다).
inline LayerOut layer_norm(const Vec& x, const Vec& gamma, const Vec& beta, double eps) {
    LayerOut o{};
    auto mv = mean_var(x);
    o.mean = mv.first;
    o.var = mv.second;
    o.denom = std::sqrt(o.var + eps);
    for (double v : x) o.xhat.push_back((v - o.mean) / o.denom);
    for (std::size_t j = 0; j < x.size(); ++j) o.y.push_back(gamma[j] * o.xhat[j] + beta[j]);
    auto m2 = mean_var(o.xhat);
    o.xhatMean = m2.first;
    o.xhatVar = m2.second;
    return o;
}

struct Feature {
    double mean, var, denom;
};

struct BatchOut {
    std::vector<Feature> features;
    std::vector<Vec> xhat, y;
};

inline BatchOut batch_norm(const std::vector<Token>& rows, const Vec& gamma, const Vec& beta, double eps) {
    BatchOut o;
    const std::size_t d = rows.front().x.size();
    for (std::size_t j = 0; j < d; ++j) {
        Vec col;
        for (const auto& r : rows) col.push_back(r.x[j]);
        auto mv = mean_var(col);
        o.features.push_back({mv.first, mv.second, std::sqrt(mv.second + eps)});
    }
    for (const auto& r : rows) {
        Vec xh, yy;
        for (std::size_t j = 0; j < d; ++j) xh.push_back((r.x[j] - o.features[j].mean) / o.features[j].denom);
        for (std::size_t j = 0; j < d; ++j) yy.push_back(gamma[j] * xh[j] + beta[j]);
        o.xhat.push_back(xh);
        o.y.push_back(yy);
    }
    return o;
}

struct RmsOut {
    double meanSquare, denom;
    Vec y;
    double yMean;
};

inline RmsOut rms_norm(const Vec& x, const Vec& gamma, double eps) {
    RmsOut o{};
    Vec sq;
    for (double v : x) sq.push_back(v * v);
    o.meanSquare = total(sq) / static_cast<double>(x.size());
    o.denom = std::sqrt(o.meanSquare + eps);
    for (std::size_t j = 0; j < x.size(); ++j) o.y.push_back(gamma[j] * x[j] / o.denom);
    o.yMean = total(o.y) / static_cast<double>(o.y.size());
    return o;
}

}  // namespace ln
