// 레이어 정규화 예제 CLI (C++17). layernorm.py와 같은 인자, 같은 JSON 모양을 출력한다.
// build: c++ -std=c++17 -O2 -ffp-contract=off -Wall -Wextra -o build/layernorm layernorm.cpp
// usage: build/layernorm run --data fixtures/tokens.csv [--mode layer|batch|rms] [--eps 1e-5]
//                            [--gamma 1,1,2,1] [--beta 0,0.5,0,0] [--select 0,2]
#include <cstdio>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "layernorm_core.hpp"

using ln::Token;
using ln::Vec;

static std::vector<std::string> split(const std::string& s, char sep) {
    std::vector<std::string> out;
    std::string cur;
    std::istringstream in(s);
    while (std::getline(in, cur, sep)) out.push_back(cur);
    return out;
}

static std::string trim(const std::string& s) {
    const auto a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    const auto b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static Vec floats(const std::string& s) {
    Vec v;
    for (const auto& p : split(s, ',')) v.push_back(std::stod(p));
    return v;
}

static std::vector<Token> load(const std::string& path, const std::vector<int>& select) {
    std::ifstream fh(path);
    if (!fh) throw std::runtime_error("cannot open " + path);
    std::vector<std::string> lines;
    std::string line;
    while (std::getline(fh, line)) {
        line = trim(line);
        if (!line.empty() && line[0] != '#') lines.push_back(line);
    }
    std::vector<Token> rows;
    for (std::size_t i = 1; i < lines.size(); ++i) {
        auto cells = split(lines[i], ',');
        Token t{cells[0], {}};
        for (std::size_t j = 1; j < cells.size(); ++j) t.x.push_back(std::stod(cells[j]));
        rows.push_back(t);
    }
    if (!select.empty()) {
        std::vector<Token> picked;
        for (int i : select) picked.push_back(rows.at(static_cast<std::size_t>(i)));
        rows = picked;
    }
    if (rows.empty()) throw std::runtime_error("no tokens");
    for (const auto& r : rows)
        if (r.x.size() != rows.front().x.size()) throw std::runtime_error("every token needs the same number of features");
    return rows;
}

// ---- minimal JSON writer (numbers with 17 significant digits round-trip exactly) ----
static std::string num(double v) {
    char buf[40];
    std::snprintf(buf, sizeof buf, "%.17g", v);
    return buf;
}
static std::string arr(const Vec& v) {
    std::string s = "[";
    for (std::size_t i = 0; i < v.size(); ++i) s += (i ? ", " : "") + num(v[i]);
    return s + "]";
}
static std::string str(const std::string& v) { return "\"" + v + "\""; }  // token names carry no quotes or escapes

int main(int argc, char** argv) {
    try {
        std::vector<std::string> a(argv + 1, argv + argc);
        if (a.empty() || a[0] != "run") throw std::runtime_error("usage: layernorm run --data <csv> [...]");
        std::string data, mode = "layer";
        double eps = 1e-5;
        Vec gamma, beta;
        std::vector<int> select;
        for (std::size_t i = 1; i + 1 < a.size(); i += 2) {
            const auto& k = a[i];
            const auto& v = a[i + 1];
            if (k == "--data") data = v;
            else if (k == "--mode") mode = v;
            else if (k == "--eps") eps = std::stod(v);
            else if (k == "--gamma") gamma = floats(v);
            else if (k == "--beta") beta = floats(v);
            else if (k == "--select") for (const auto& p : split(v, ',')) select.push_back(std::stoi(p));
            else throw std::runtime_error("unknown option " + k);
        }
        auto rows = load(data, select);
        const std::size_t d = rows.front().x.size();
        if (gamma.empty()) gamma.assign(d, 1.0);
        if (beta.empty()) beta.assign(d, 0.0);
        if (gamma.size() != d || beta.size() != d) throw std::runtime_error("gamma and beta need d values");

        std::ostringstream o;
        o << "{\n \"mode\": " << str(mode) << ",\n \"eps\": " << num(eps) << ",\n \"d\": " << d
          << ",\n \"gamma\": " << arr(gamma) << ",\n \"beta\": " << arr(beta) << ",\n";
        std::vector<std::string> toks;
        if (mode == "layer") {
            for (const auto& r : rows) {
                auto L = ln::layer_norm(r.x, gamma, beta, eps);
                toks.push_back("{\"name\": " + str(r.name) + ", \"x\": " + arr(r.x) + ", \"mean\": " + num(L.mean) +
                               ", \"var\": " + num(L.var) + ", \"denom\": " + num(L.denom) + ", \"xhat\": " + arr(L.xhat) +
                               ", \"y\": " + arr(L.y) + ", \"xhatMean\": " + num(L.xhatMean) + ", \"xhatVar\": " + num(L.xhatVar) + "}");
            }
        } else if (mode == "batch") {
            auto B = ln::batch_norm(rows, gamma, beta, eps);
            o << " \"features\": [";
            for (std::size_t j = 0; j < B.features.size(); ++j)
                o << (j ? ", " : "") << "{\"mean\": " << num(B.features[j].mean) << ", \"var\": " << num(B.features[j].var)
                  << ", \"denom\": " << num(B.features[j].denom) << "}";
            o << "],\n";
            for (std::size_t i = 0; i < rows.size(); ++i)
                toks.push_back("{\"name\": " + str(rows[i].name) + ", \"x\": " + arr(rows[i].x) + ", \"xhat\": " + arr(B.xhat[i]) +
                               ", \"y\": " + arr(B.y[i]) + "}");
        } else if (mode == "rms") {
            for (double b : beta)
                if (b != 0.0) throw std::runtime_error("RMSNorm has no beta");
            for (const auto& r : rows) {
                auto R = ln::rms_norm(r.x, gamma, eps);
                toks.push_back("{\"name\": " + str(r.name) + ", \"x\": " + arr(r.x) + ", \"meanSquare\": " + num(R.meanSquare) +
                               ", \"denom\": " + num(R.denom) + ", \"y\": " + arr(R.y) + ", \"yMean\": " + num(R.yMean) + "}");
            }
        } else {
            throw std::runtime_error("unknown mode " + mode);
        }
        o << " \"tokens\": [\n";
        for (std::size_t i = 0; i < toks.size(); ++i) o << "  " << toks[i] << (i + 1 < toks.size() ? ",\n" : "\n");
        o << " ]\n}\n";
        std::cout << o.str();
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "error: " << e.what() << "\n";
        return 1;
    }
}
