"""Run every example the film shows, with both implementations, and write the numbers the film and narration use.

usage: python3 films/layer-normalization-20261112/example/run_examples.py [--check]
  writes  example/results/<run>.py.json, <run>.cpp.json   raw outputs of `layernorm.py run` / `build/layernorm run`
          example/results/run-log.json                      commands, exit codes, sha256 of each output, py-vs-C++ max diff
          example/results/film_numbers.json                 the only source of numbers for film.js and voice/script.json
  --check  re-run everything into memory and fail if a committed result differs (no files written)
C++ is built with `c++ -std=c++17 -O2 -ffp-contract=off -Wall -Wextra` into example/build/ (a local artefact). Both
implementations must agree on every number (max |py − C++| is logged; the run fails above 1e-12).
"""
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
RES = HERE / 'results'
TOKENS = HERE / 'fixtures' / 'tokens.csv'
FLAT = HERE / 'fixtures' / 'flat_token.csv'
BIN = HERE / 'build' / 'layernorm'
REL = lambda p: os.path.relpath(p, HERE.parents[2])  # paths relative to the repo root

EPS = 1e-5                       # torch.nn.LayerNorm default eps
GAMMA, BETA = '1,1,2,1', '0,0.5,0,0'   # a "learned" γ, β for lecture 3: feature 3 doubled, feature 2 lifted by 0.5
PAIR = '0,2'                     # 오늘 + 맑다 (날씨가 left out of the batch)
# Every run the film uses.
RUNS = {
    'ln': (TOKENS, ['--mode', 'layer']),
    'ln_pair': (TOKENS, ['--mode', 'layer', '--select', PAIR]),
    'bn': (TOKENS, ['--mode', 'batch']),
    'bn_pair': (TOKENS, ['--mode', 'batch', '--select', PAIR]),
    'ln_affine': (TOKENS, ['--mode', 'layer', '--gamma', GAMMA, '--beta', BETA]),
    'ln_flat': (FLAT, ['--mode', 'layer']),
    'rms': (TOKENS, ['--mode', 'rms']),
}
# Quoted, not run (checked 2026-11-12): PyTorch torch.nn.LayerNorm — normalizes over the last normalized_shape
# dimensions, eps default 1e-05, biased variance (torch.var(unbiased=False)), elementwise_affine weight init 1, bias
# init 0. GPT-2 small (Radford et al. 2019) d_model = 768, LayerNorm moved to the input of each sub-block plus one
# after the final block. Original Transformer (Vaswani et al. 2017): LayerNorm(x + Sublayer(x)). LLaMA (Touvron et al.
# 2023, §2.2): pre-normalization with RMSNorm (Zhang & Sennrich 2019).
QUOTED = {'torchEps': 1e-5, 'gpt2Dim': 768}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def build_cpp(log):
    cxx = os.environ.get('CXX') or shutil.which('c++') or shutil.which('clang++') or shutil.which('g++')
    if not cxx:
        raise SystemExit('no C++ compiler (set CXX)')
    BIN.parent.mkdir(exist_ok=True)
    cmd = [cxx, '-std=c++17', '-O2', '-ffp-contract=off', '-Wall', '-Wextra', '-o', str(BIN), str(HERE / 'layernorm.cpp')]
    p = subprocess.run(cmd, capture_output=True, text=True)
    log.append({'cmd': ' '.join([Path(cxx).name] + [REL(c) if c.startswith('/') else c for c in cmd[1:]]), 'exit': p.returncode, 'stderr': p.stderr.strip()[:2000]})
    if p.returncode or p.stderr.strip():
        raise SystemExit('C++ build failed or warned:\n' + p.stderr)


def run(log, name, impl):
    data, extra = RUNS[name]
    args = ['run', '--data', str(data)] + extra
    cmd = [sys.executable, str(HERE / 'layernorm.py')] + args if impl == 'py' else [str(BIN)] + args
    p = subprocess.run(cmd, capture_output=True, cwd=HERE)
    shown = ' '.join((['python3', REL(HERE / 'layernorm.py')] if impl == 'py' else [REL(BIN)]) + [REL(c) if c.startswith('/') else c for c in args])
    log.append({'run': name, 'impl': impl, 'cmd': shown, 'exit': p.returncode, 'stdout_sha256': sha(p.stdout), 'stderr': p.stderr.decode()[:2000]})
    if p.returncode:
        raise SystemExit(f'{name} ({impl}) failed: {p.stderr.decode()[:400]}')
    return p.stdout, json.loads(p.stdout)


def numbers_of(v):
    """Every number in a parsed result, in a fixed order (dict keys sorted), for the py-vs-C++ comparison."""
    if isinstance(v, bool) or isinstance(v, str):
        return []
    if isinstance(v, (int, float)):
        return [float(v)]
    if isinstance(v, list):
        return [x for e in v for x in numbers_of(e)]
    return [x for k in sorted(v) for x in numbers_of(v[k])]


def max_diff(a, b):
    na, nb = numbers_of(a), numbers_of(b)
    if len(na) != len(nb):
        raise SystemExit('Python and C++ results have different shapes')
    return max(abs(x - y) for x, y in zip(na, nb))


def r(x, n):
    v = round(float(x), n)
    return 0.0 if v == 0 else v  # no −0.0 on screen


def rv(xs, n):
    return [r(x, n) for x in xs]


def film_numbers(res):
    """Rounded display values. Everything on screen or in the narration comes from here."""
    ln, lnp, bn, bnp, aff, flat, rms = (res[k] for k in RUNS)
    t0, t1, t2 = ln['tokens']
    gpt2 = QUOTED['gpt2Dim']
    sd = max(abs(a - b) for a, b in zip(t0['xhat'], t1['xhat']))
    sd_exp = math.floor(math.log10(sd))
    return {
        '$doc': 'Generated by example/run_examples.py from results/*.py.json. Do not edit; film.js and voice/script.json read these values.',
        'zero': 0, 'one': 1, 'two': 2,
        'd': ln['d'], 'eps': EPS, 'epsExp10': -5,
        'tokens': {'names': [t['name'] for t in ln['tokens']], 'x': [[int(v) for v in t['x']] for t in ln['tokens']],
                   'scaleRatio': int(t1['x'][0] / t0['x'][0])},
        'ln': {
            'mean': [r(t['mean'], 6) for t in ln['tokens']],
            'var': [r(t['var'], 6) for t in ln['tokens']],
            'denom': [r(t['denom'], 6) for t in ln['tokens']],
            'denom2': [r(t['denom'], 2) for t in ln['tokens']],
            'dev': [[int(round(v - t['mean'])) if abs(v - t['mean'] - round(v - t['mean'])) < 1e-12 else r(v - t['mean'], 6) for v in t['x']] for t in ln['tokens']],
            'devSq': [[r((v - t['mean']) * (v - t['mean']), 6) for v in t['x']] for t in ln['tokens']],
            'xhat': [rv(t['xhat'], 6) for t in ln['tokens']],
            'xhat2': [rv(t['xhat'], 2) for t in ln['tokens']],
            'xhatMean': [r(t['xhatMean'], 12) for t in ln['tokens']],
            'xhatVar': [r(t['xhatVar'], 8) for t in ln['tokens']],
            'xhatVar2': [r(t['xhatVar'], 2) for t in ln['tokens']],
            'scaleDiff': sd, 'scaleDiffExp10': sd_exp, 'scaleDiffMantissa': r(sd / 10 ** sd_exp, 1),  # 오늘 vs 날씨가 (10×): ε only
        },
        'pair': {
            'lnSame': max(abs(a - b) for a, b in zip(t0['xhat'], lnp['tokens'][0]['xhat'])),  # 오늘 alone in another batch
            'bn': rv(bn['tokens'][0]['xhat'], 2), 'bnPair': rv(bnp['tokens'][0]['xhat'], 2),
            'bnFeature0': {'mean': r(bn['features'][0]['mean'], 3), 'meanPair': r(bnp['features'][0]['mean'], 3)},
        },
        'affine': {'gamma': aff['gamma'], 'beta': aff['beta'], 'y': rv(aff['tokens'][0]['y'], 6), 'y2': rv(aff['tokens'][0]['y'], 2)},
        'flat': {'x': [int(v) for v in flat['tokens'][0]['x']], 'var': flat['tokens'][0]['var'],
                 'dev': [r(v - flat['tokens'][0]['mean'], 12) for v in flat['tokens'][0]['x']],
                 'y': rv(flat['tokens'][0]['y'], 6), 'denom': r(flat['tokens'][0]['denom'], 6)},
        'rms': {'meanSquare': r(rms['tokens'][0]['meanSquare'], 6), 'denom2': r(rms['tokens'][0]['denom'], 2),
                'y2': rv(rms['tokens'][0]['y'], 2), 'yMean2': r(rms['tokens'][0]['yMean'], 2),
                'scaleSame': max(abs(a - b) for a, b in zip(rms['tokens'][0]['y'], rms['tokens'][1]['y']))},
        'params': {'perLayerNorm': 2 * gpt2},
        'quoted': QUOTED,
    }


def main():
    check = '--check' in sys.argv
    log = []
    build_cpp(log)
    raw, res, diffs = {}, {}, {}
    for name in RUNS:
        parsed = {}
        for impl in ('py', 'cpp'):
            raw[(name, impl)], parsed[impl] = run(log, name, impl)
        diffs[name] = max_diff(parsed['py'], parsed['cpp'])
        if diffs[name] > 1e-12:
            raise SystemExit(f'{name}: Python and C++ differ by {diffs[name]}')
        res[name] = parsed['py']
    nums = json.dumps(film_numbers(res), ensure_ascii=False, indent=1) + '\n'
    if check:
        bad = [f'{n}.{i}.json' for (n, i), b in raw.items() if (RES / f'{n}.{i}.json').read_bytes() != b]
        if (RES / 'film_numbers.json').read_text(encoding='utf-8') != nums:
            bad.append('film_numbers.json')
        print('CHECK', 'FAIL ' + ', '.join(bad) if bad else 'PASS (committed results match a fresh run; Python = C++ on every number)')
        sys.exit(1 if bad else 0)
    RES.mkdir(exist_ok=True)
    for (n, i), b in raw.items():
        (RES / f'{n}.{i}.json').write_bytes(b)
    (RES / 'film_numbers.json').write_text(nums, encoding='utf-8')
    files = sorted(RES.glob('*.json'))
    (RES / 'run-log.json').write_text(json.dumps({'commands': log, 'pyVsCppMaxAbsDiff': diffs,
                                                  'outputs': {f.name: sha(f.read_bytes()) for f in files if f.name != 'run-log.json'}},
                                                 ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
    print('wrote', len(raw) + 2, 'files to', REL(RES))


if __name__ == '__main__':
    main()
