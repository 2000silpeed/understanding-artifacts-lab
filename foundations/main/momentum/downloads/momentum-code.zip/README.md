# AI 기본기 14 · 모멘텀 — visual1 (native film + 입력 계약)

원본 source package `films/momentum-20261107/`(대본·예제 독립 검수 **SOURCE_PASS**)의 sibling. 기획·디자인·예제·학습 순서(요약 → 사용 상황 → 본 강의 1–7 → 정리)는 그대로 두고, 이 폴더에서 다음을 구현했다.

- **`film.js`**: direction.md 를 구현한 실행 가능한 native film. 14장면·23샷, 골짜기 지도(실제 손실 등고선 + 실행 궤적), 자막(대본 원문), 라이브러리 효과음, 음성·음악 큐.
- **입력 계약**: 최종 음성의 provider timestamps → `voice/voice.json`·`captions/captions.json`·`shots.json` 재배분, 기존 Suno 곡 → `music/score.wav`. 규칙은 [`CONTRACT.md`](CONTRACT.md).
- 상태: **음성 PENDING, 음악 PENDING** → 제작 BLOCKED(`tools/check_contract.py --production` 종료 코드 2). 렌더·스틸·TTS·음악 생성·업로드·커밋은 하지 않았다.

| 경로 | 내용 |
|---|---|
| `film.js`, `lib/figures.js` | 영화 본체, film-local 그림 부품(등고선·궤적·선 그래프·막대·코드 카드) |
| `plan/anchors.json` | 이벤트가 걸리는 발화 단어(장면별), 샷 시작 단어, lead/tail/홀드 |
| `plan/estimate-timing.json` | 녹음 전 추정(ESTIMATE, 제작 금지) — 오프라인 점검용 |
| `voice/`, `captions/`, `music/` | 계약 manifest 와 PENDING 상태 파일 |
| `tools/voice_timeline.py` | `status`·`map`·`estimate`·`build [--reflow]` |
| `tools/music_bed.py` | `plan`·`build` (기존 곡 → 영화 길이 베드) |
| `tools/check_contract.py` | 원본 보존·계약·상태 검사, `--production` 차단 |
| `tools/smoke_film.mjs` | 렌더 없는 film.js 실행 검사(esbuild + 가짜 캔버스) |
| `tests/test_timeline_tools.py` | 계약 도구 단위 테스트 |
| `BINDINGS.md` | 원본 대비 경로·binding 변경, direction 과 다르게 구현한 점 |
| `qa/author-result.json` | 이 작업의 명령·종료 코드·상태 기록 |
| 그 밖(`lesson.md`, `script/`, `examples/`, `data/`, `shots.json` …) | 원본과 같은 source (README 의 원래 설명은 원본 폴더 참고) |

## 확인 (워크트리 루트)

```sh
sh films/momentum-20261107-visual1/examples/run_all.sh
python3 pipeline/shotlint.py momentum-20261107-visual1
python3 -m unittest discover -s films/momentum-20261107-visual1/tests
python3 films/momentum-20261107-visual1/tools/voice_timeline.py map
node films/momentum-20261107-visual1/tools/smoke_film.mjs
python3 films/momentum-20261107-visual1/tools/check_contract.py
```
