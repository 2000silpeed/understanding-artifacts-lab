// 모멘텀: 이전 기울기의 방향을 이어 학습하기 — 수업 예제 (C++17, 표준 라이브러리만 사용).
//
// 갱신식:  v ← β·v + g,   w ← w − η·v   (β = 0 이면 보통 경사하강법)
// Python 예제(examples/python/momentum.py)와 같은 fixture를 같은 연산 순서로 계산한다.
// config.json 은 이 예제가 쓰는 숫자 키만 읽는 최소 파서로 읽는다(외부 라이브러리 없음).
//
// 빌드:  c++ -std=c++17 -O2 -o momentum momentum.cpp
// 실행:  ./momentum <fixtures 폴더>      → 결과를 JSON으로 표준출력에 쓴다
#include <array>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

using Vec = std::array<double, 2>;

struct Data {
  std::vector<Vec> X;
  std::vector<double> y;
};

static std::string slurp(const std::string& path) {
  std::ifstream f(path);
  if (!f) throw std::runtime_error("cannot open " + path);
  std::stringstream ss;
  ss << f.rdbuf();
  return ss.str();
}

// "key": <number> 또는 "key": [n, n, ...] 를 찾는다.
static std::vector<double> json_numbers(const std::string& text, const std::string& key) {
  auto pos = text.find("\"" + key + "\"");
  if (pos == std::string::npos) throw std::runtime_error("missing key " + key);
  pos = text.find(':', pos) + 1;
  while (text[pos] == ' ') ++pos;
  std::vector<double> out;
  if (text[pos] == '[') {
    auto end = text.find(']', pos);
    std::stringstream ss(text.substr(pos + 1, end - pos - 1));
    std::string item;
    while (std::getline(ss, item, ',')) out.push_back(std::stod(item));
  } else {
    out.push_back(std::stod(text.substr(pos)));
  }
  return out;
}

static Data load_centered(const std::string& csv_path) {
  std::ifstream f(csv_path);
  if (!f) throw std::runtime_error("cannot open " + csv_path);
  std::string line;
  std::vector<std::array<double, 3>> rows;
  bool header = true;
  while (std::getline(f, line)) {
    if (line.empty() || line[0] == '#') continue;
    if (header) { header = false; continue; }
    std::array<double, 3> r{};
    std::stringstream ss(line);
    std::string cell;
    for (int i = 0; i < 3 && std::getline(ss, cell, ','); ++i) r[i] = std::stod(cell);
    rows.push_back(r);
  }
  const double n = static_cast<double>(rows.size());
  double ma = 0, mr = 0, mp = 0;
  for (auto& r : rows) ma += r[0];
  for (auto& r : rows) mr += r[1];
  for (auto& r : rows) mp += r[2];
  ma /= n; mr /= n; mp /= n;
  Data d;
  for (auto& r : rows) {
    d.X.push_back({r[0] - ma, r[1] - mr});
    d.y.push_back(r[2] - mp);
  }
  return d;
}

static Vec gradient(const Vec& w, const Data& d) {
  double g0 = 0, g1 = 0;
  for (size_t i = 0; i < d.y.size(); ++i) {
    const double r = d.X[i][0] * w[0] + d.X[i][1] * w[1] - d.y[i];
    g0 += r * d.X[i][0];
    g1 += r * d.X[i][1];
  }
  const double n = static_cast<double>(d.y.size());
  return {g0 / n, g1 / n};
}

static Vec solve_optimum(const Data& d) {
  double h00 = 0, h01 = 0, h11 = 0, c0 = 0, c1 = 0;
  for (auto& x : d.X) h00 += x[0] * x[0];
  for (auto& x : d.X) h01 += x[0] * x[1];
  for (auto& x : d.X) h11 += x[1] * x[1];
  for (size_t i = 0; i < d.y.size(); ++i) c0 += d.X[i][0] * d.y[i];
  for (size_t i = 0; i < d.y.size(); ++i) c1 += d.X[i][1] * d.y[i];
  const double n = static_cast<double>(d.y.size());
  h00 /= n; h01 /= n; h11 /= n; c0 /= n; c1 /= n;
  const double det = h00 * h11 - h01 * h01;
  return {(c0 * h11 - h01 * c1) / det, (h00 * c1 - h01 * c0) / det};
}

static double dist(const Vec& p, const Vec& q) {
  return std::sqrt((p[0] - q[0]) * (p[0] - q[0]) + (p[1] - q[1]) * (p[1] - q[1]));
}

struct Run {
  std::optional<int> steps;
  Vec at100{};   // 100걸음 뒤 위치
  Vec at_keep{}; // trajectory_steps 걸음 뒤 위치
};

static Run train(const Data& d, const Vec& w_star, double beta, double lr, Vec w, double tol, int max_steps, int keep) {
  Vec v{0.0, 0.0};
  const double d0 = dist(w, w_star);
  Run run;
  for (int k = 1; k <= max_steps; ++k) {
    const Vec g = gradient(w, d);
    v = {beta * v[0] + g[0], beta * v[1] + g[1]};  // 속도: 지난 속도의 β배 + 이번 기울기
    w = {w[0] - lr * v[0], w[1] - lr * v[1]};      // 속도 방향으로 한 걸음
    if (k == 100) run.at100 = w;
    if (k == keep) run.at_keep = w;
    if (!run.steps && dist(w, w_star) < tol * d0) run.steps = k;
    if (run.steps && k >= keep && k >= 100) break;
  }
  return run;
}

int main(int argc, char** argv) {
  const std::string dir = argc > 1 ? argv[1] : "../fixtures";
  try {
    const std::string cfg = slurp(dir + "/config.json");
    const double lr = json_numbers(cfg, "learning_rate")[0];
    const auto start = json_numbers(cfg, "start");
    const double tol = json_numbers(cfg, "tolerance")[0];
    const int max_steps = static_cast<int>(json_numbers(cfg, "max_steps")[0]);
    const int keep = static_cast<int>(json_numbers(cfg, "trajectory_steps")[0]);
    const auto betas = json_numbers(cfg, "betas");
    const double toy_beta = json_numbers(cfg, "toy_beta")[0];
    const int toy_steps = static_cast<int>(json_numbers(cfg, "toy_steps")[0]);

    const Data d = load_centered(dir + "/houses.csv");
    const Vec w_star = solve_optimum(d);

    std::printf("{\n \"w_star\": [%.17g, %.17g],\n \"sweep\": [", w_star[0], w_star[1]);
    for (size_t i = 0; i < betas.size(); ++i) {
      const Run r = train(d, w_star, betas[i], lr, {start[0], start[1]}, tol, max_steps, keep);
      std::printf("%s\n  {\"beta\": %.17g, \"steps\": %d, \"at100\": [%.17g, %.17g], \"at_keep\": [%.17g, %.17g]}",
                  i ? "," : "", betas[i], r.steps ? *r.steps : -1, r.at100[0], r.at100[1], r.at_keep[0], r.at_keep[1]);
    }
    std::printf("\n ],\n \"toy_same\": [");
    double v = 0;
    for (int k = 0; k < toy_steps; ++k) {
      v = toy_beta * v + 1.0;
      std::printf("%s%.17g", k ? ", " : "", v);
    }
    std::printf("],\n \"toy_alternating\": [");
    v = 0;
    for (int k = 0; k < toy_steps; ++k) {
      v = toy_beta * v + (k % 2 == 0 ? 1.0 : -1.0);
      std::printf("%s%.17g", k ? ", " : "", v);
    }
    std::printf("]\n}\n");
  } catch (const std::exception& e) {
    std::cerr << "error: " << e.what() << "\n";
    return 2;
  }
  return 0;
}
