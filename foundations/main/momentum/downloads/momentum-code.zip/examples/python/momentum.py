"""모멘텀: 이전 기울기의 방향을 이어 학습하기 — 수업 예제 (Python 3, 표준 라이브러리만 사용).

갱신식 (PyTorch torch.optim.SGD, dampening=0, nesterov=False 와 같은 형태):
    v ← β·v + g        # 속도: 지난 속도의 β배 + 이번 기울기
    w ← w − η·v        # 가중치는 속도 방향으로 이동
β = 0 이면 v = g 이므로 보통 경사하강법과 같다.

예제 1 (장난감): 기울기가 계속 같은 방향(+1)일 때와 번갈아 바뀔 때(+1, −1, …) 속도가 어떻게 변하는가.
예제 2 (사용 상황): 예시 아파트 8채로 가격 = w면적·면적 + w방·방 수 를 학습한다(평균을 뺀 데이터).
    면적(평)과 방 수는 단위와 퍼짐이 달라 손실이 좁고 긴 골짜기가 된다.

사용:
    python3 momentum.py --fixtures ../fixtures --out ../results/python.json
"""
import argparse
import csv
import json
import math
from pathlib import Path


# ---------- 데이터 ----------
def load_houses(path):
    rows = []
    with open(path, encoding='utf-8') as f:
        lines = [ln for ln in f if not ln.startswith('#')]
    for r in csv.DictReader(lines):
        rows.append((float(r['area_pyeong']), float(r['rooms']), float(r['price_eok'])))
    return rows


def center(rows):
    """평균을 빼서 절편 없이 가중치 두 개(w면적, w방)만 학습하게 만든다."""
    n = len(rows)
    ma = sum(r[0] for r in rows) / n
    mr = sum(r[1] for r in rows) / n
    mp = sum(r[2] for r in rows) / n
    X = [(r[0] - ma, r[1] - mr) for r in rows]
    y = [r[2] - mp for r in rows]
    return X, y, {'area': ma, 'rooms': mr, 'price': mp}


# ---------- 손실과 기울기 (평균제곱오차의 절반) ----------
def loss(w, X, y):
    s = 0.0
    for (a, b), t in zip(X, y):
        r = a * w[0] + b * w[1] - t
        s += r * r
    return 0.5 * s / len(y)


def gradient(w, X, y):
    g0 = 0.0
    g1 = 0.0
    for (a, b), t in zip(X, y):
        r = a * w[0] + b * w[1] - t
        g0 += r * a
        g1 += r * b
    n = len(y)
    return [g0 / n, g1 / n]


def hessian(X):
    n = len(X)
    h00 = sum(a * a for a, _ in X) / n
    h01 = sum(a * b for a, b in X) / n
    h11 = sum(b * b for _, b in X) / n
    return h00, h01, h11


def solve_optimum(X, y):
    """정답 가중치 w* (2×2 정규방정식, 크라메르 공식). 비교 기준으로만 쓴다."""
    h00, h01, h11 = hessian(X)
    n = len(y)
    c0 = sum(a * t for (a, _), t in zip(X, y)) / n
    c1 = sum(b * t for (_, b), t in zip(X, y)) / n
    det = h00 * h11 - h01 * h01
    return [(c0 * h11 - h01 * c1) / det, (h00 * c1 - h01 * c0) / det]


def eigenvalues(h00, h01, h11):
    m = (h00 + h11) / 2
    d = math.sqrt(((h00 - h11) / 2) ** 2 + h01 * h01)
    return m - d, m + d


# ---------- 모멘텀 한 걸음 ----------
def momentum_step(w, v, g, beta, lr):
    v = [beta * v[0] + g[0], beta * v[1] + g[1]]
    w = [w[0] - lr * v[0], w[1] - lr * v[1]]
    return w, v


def dist(p, q):
    dx, dy = p[0] - q[0], p[1] - q[1]
    return math.sqrt(dx * dx + dy * dy)  # 곱셈은 발산해도 inf 가 될 뿐 예외를 내지 않는다(** 2 는 OverflowError)


def train(X, y, w_star, beta, lr, start, tol, max_steps, keep):
    """정답까지 거리가 출발 거리의 tol 배 아래로 줄어드는 첫 걸음 수를 센다."""
    w = list(start)
    v = [0.0, 0.0]
    d0 = dist(w, w_star)
    path = [list(w)]
    steps = None
    for k in range(1, max_steps + 1):
        g = gradient(w, X, y)
        w, v = momentum_step(w, v, g, beta, lr)
        if k <= keep:
            path.append(list(w))
        if steps is None and dist(w, w_star) < tol * d0:
            steps = k
        if steps is not None and k >= keep:
            break
    return steps, path


# ---------- 장난감 예제: 속도 v 만 본다 ----------
def toy_velocity(beta, grads):
    v = 0.0
    out = []
    for g in grads:
        v = beta * v + g
        out.append(v)
    return out


def run(fixtures):
    cfg = json.loads((fixtures / 'config.json').read_text(encoding='utf-8'))
    rows = load_houses(fixtures / 'houses.csv')
    X, y, means = center(rows)
    lr, start, tol, max_steps = cfg['learning_rate'], cfg['start'], cfg['tolerance'], cfg['max_steps']
    keep = cfg['trajectory_steps']

    h00, h01, h11 = hessian(X)
    lo, hi = eigenvalues(h00, h01, h11)
    w_star = solve_optimum(X, y)

    sweep = []
    paths = {}
    for beta in cfg['betas']:
        steps, path = train(X, y, w_star, beta, lr, start, tol, max_steps, keep)
        sweep.append({'beta': beta, 'steps': steps})
        paths[repr(beta)] = path
    by_beta = {s['beta']: s['steps'] for s in sweep}
    gd, mom = by_beta[0.0], by_beta[cfg['momentum_main']]

    d0 = dist(start, w_star)
    remain100 = {repr(b): dist(paths[repr(b)][100], w_star) / d0 for b in cfg['betas']}

    tb, tn = cfg['toy_beta'], cfg['toy_steps']
    same = toy_velocity(tb, [1.0] * tn)
    alt = toy_velocity(tb, [1.0 if k % 2 == 0 else -1.0 for k in range(tn)])

    return {
        'config': cfg,
        'data': {
            'n': len(rows), 'means': means, 'rows': rows,
            'area_range': [min(r[0] for r in rows), max(r[0] for r in rows)],
            'rooms_range': [min(r[1] for r in rows), max(r[1] for r in rows)],
        },
        'valley': {
            'hessian': [h00, h01, h11],
            'eig_small': lo, 'eig_large': hi, 'curvature_ratio': hi / lo,
            'lr_limit_gd': 2.0 / hi,
            'w_star': w_star, 'loss_star': loss(w_star, X, y), 'loss_start': loss(start, X, y),
        },
        'steps': {'gd': gd, 'momentum': mom, 'speedup': gd / mom if gd and mom else None},  # None = 발산 또는 max_steps 안에 도달 못 함
        'sweep': sweep,
        'remaining_after_100': remain100,
        'toy': {
            'beta': tb,
            'same_direction': same, 'alternating': alt,
            'limit_same': 1.0 / (1.0 - tb), 'limit_alternating': 1.0 / (1.0 + tb),
        },
        'trajectories': paths,
    }


def summary(r):
    s = r['steps']
    lines = [
        f"정답 가중치 w* = (면적 {r['valley']['w_star'][0]:.4f}, 방 {r['valley']['w_star'][1]:.4f})",
        f"휘는 정도 비율(큰 고윳값/작은 고윳값) = {r['valley']['curvature_ratio']:.1f}",
        f"경사하강법(β=0): {s['gd']}걸음, 모멘텀(β={r['config']['momentum_main']}): {s['momentum']}걸음, " + (f"{s['speedup']:.2f}배" if s['speedup'] else '비교 불가(도달 못 한 실행 있음)'),
        'β 비교: ' + ', '.join(f"{x['beta']}→{x['steps']}" for x in r['sweep']),
        'toy 같은 방향: ' + ', '.join(f'{v:.4f}' for v in r['toy']['same_direction'][:5]),
        'toy 번갈아:   ' + ', '.join(f'{v:.4f}' for v in r['toy']['alternating'][:5]),
    ]
    return '\n'.join(lines)


def main():
    here = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser()
    ap.add_argument('--fixtures', type=Path, default=here.parent / 'fixtures')
    ap.add_argument('--out', type=Path, default=here.parent / 'results' / 'python.json')
    args = ap.parse_args()
    r = run(args.fixtures)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(r, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
    print(summary(r))


if __name__ == '__main__':
    main()
