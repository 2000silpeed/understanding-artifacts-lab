#!/bin/sh
# 모멘텀 수업 source package 테스트 entrypoint.
#   sh films/momentum-20261107/examples/run_all.sh
# 순서: Python 예제 → C++17 빌드·실행 → 단위 테스트(파이썬·C++ 일치 포함) → 그림 데이터 → 대본 숫자 대조.
# 각 단계의 명령과 종료 코드를 results/run-log.tsv 에 남긴다. 하나라도 실패하면 종료 코드 1.
set -u
EX=$(cd "$(dirname "$0")" && pwd)
PKG=$(dirname "$EX")
LOG="$EX/results/run-log.tsv"
mkdir -p "$EX/results" "$EX/cpp/build"
printf 'step\texit\tcommand\n' > "$LOG"
FAIL=0

step() {
  name=$1; shift
  echo "== $name: $*"
  "$@"
  code=$?
  printf '%s\t%s\t%s\n' "$name" "$code" "$*" >> "$LOG"
  [ "$code" -eq 0 ] || FAIL=1
  return 0
}

CXX=${CXX:-c++}
step python python3 "$EX/python/momentum.py" --fixtures "$EX/fixtures" --out "$EX/results/python.json"
step cpp-build "$CXX" -std=c++17 -O2 -ffp-contract=off -Wall -Wextra -o "$EX/cpp/build/momentum" "$EX/cpp/momentum.cpp"
echo "== cpp-run: $EX/cpp/build/momentum $EX/fixtures > results/cpp.json"
"$EX/cpp/build/momentum" "$EX/fixtures" > "$EX/results/cpp.json"
code=$?
printf 'cpp-run\t%s\t%s\n' "$code" "$EX/cpp/build/momentum $EX/fixtures > $EX/results/cpp.json" >> "$LOG"
[ "$code" -eq 0 ] || FAIL=1
step unittest python3 -m unittest discover -s "$EX/tests" -v
step film-data python3 "$PKG/tools/build_film_data.py"
step script python3 "$PKG/tools/build_script.py"

if [ "$FAIL" -ne 0 ]; then
  echo "RESULT: FAIL (see $LOG)"
  exit 1
fi
echo "RESULT: PASS"
