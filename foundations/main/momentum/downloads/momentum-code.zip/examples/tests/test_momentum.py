"""모멘텀 예제 테스트. 실행: python3 -m unittest discover -s examples/tests -v (패키지 폴더에서)."""
import json
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
EX = HERE.parent
sys.path.insert(0, str(EX / 'python'))
import momentum as m  # noqa: E402

FIX = EX / 'fixtures'
RES = EX / 'results'


class UpdateRule(unittest.TestCase):
    def test_beta_zero_is_plain_gradient_descent(self):
        w, g, lr = [0.3, -0.2], [1.5, -4.0], 0.015
        w2, v2 = m.momentum_step(w, [9.0, 9.0], g, 0.0, lr)
        self.assertEqual(v2, g)
        self.assertEqual(w2, [w[0] - lr * g[0], w[1] - lr * g[1]])

    def test_first_step_equals_gradient_like_pytorch(self):
        # PyTorch SGD(dampening=0): 첫 걸음의 버퍼 b1 = g1. v0 = 0 에서 β·0 + g 와 같다.
        _, v = m.momentum_step([0.0, 0.0], [0.0, 0.0], [2.0, 3.0], 0.9, 0.1)
        self.assertEqual(v, [2.0, 3.0])


class Toy(unittest.TestCase):
    def test_same_direction_accumulates_toward_ten(self):
        v = m.toy_velocity(0.9, [1.0] * 60)
        for got, want in zip(v[:4], [1.0, 1.9, 2.71, 3.439]):
            self.assertAlmostEqual(got, want, places=12)
        self.assertTrue(all(b > a for a, b in zip(v, v[1:])))
        self.assertAlmostEqual(v[-1], 10.0, delta=0.02)

    def test_alternating_cancels(self):
        v = m.toy_velocity(0.9, [1.0 if k % 2 == 0 else -1.0 for k in range(60)])
        self.assertTrue(all(abs(x) <= 1.0 for x in v))
        self.assertAlmostEqual(abs(v[-1]), 1 / 1.9, delta=0.01)


class Houses(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r = m.run(FIX)

    def test_optimum_has_zero_gradient(self):
        X, y, _ = m.center(m.load_houses(FIX / 'houses.csv'))
        g = m.gradient(self.r['valley']['w_star'], X, y)
        self.assertLess(max(abs(g[0]), abs(g[1])), 1e-12)

    def test_learning_rate_is_stable_for_plain_gd(self):
        self.assertLess(self.r['config']['learning_rate'], self.r['valley']['lr_limit_gd'])

    def test_lesson_claims(self):
        s = self.r['steps']
        self.assertGreater(s['gd'], 10 * s['momentum'])
        by = {x['beta']: x['steps'] for x in self.r['sweep']}
        self.assertTrue(all(v is not None for v in by.values()))
        self.assertGreater(by[0.99], by[0.9])  # 너무 큰 β는 다시 느려진다
        rem = self.r['remaining_after_100']
        self.assertLess(rem['0.9'], rem['0.0'])

    def test_swing_across_the_valley(self):
        # 대본: 경사하강법은 첫 몇 걸음 벽 사이를 좌우로 튕긴다 / 모멘텀의 좌우 흔들림은 쌓이지 않고 줄어든다.
        h00, h01, h11 = self.r['valley']['hessian']
        hi = self.r['valley']['eig_large']
        ex, ey = h01, hi - h00  # 가파른 방향(큰 고윳값)의 고유벡터
        norm = (ex * ex + ey * ey) ** 0.5
        ws = self.r['valley']['w_star']

        def across(path):
            return [((p[0] - ws[0]) * ex + (p[1] - ws[1]) * ey) / norm for p in path]

        gd = across(self.r['trajectories']['0.0'])
        flips = sum(1 for a, b in zip(gd[1:10], gd[2:11]) if a * b < 0)
        self.assertGreaterEqual(flips, 5)
        mom = across(self.r['trajectories']['0.9'])
        self.assertGreater(max(map(abs, mom[1:21])), 5 * max(map(abs, mom[80:101])))

    def test_resetting_velocity_every_step_is_plain_gd(self):
        # 흔한 실수: v 를 매 걸음 0 으로 새로 만들면 모멘텀이 사라진다.
        X, y, _ = m.center(m.load_houses(FIX / 'houses.csv'))
        cfg, w_star = self.r['config'], self.r['valley']['w_star']
        w, d0 = list(cfg['start']), m.dist(cfg['start'], w_star)
        for k in range(1, cfg['max_steps'] + 1):
            w, _ = m.momentum_step(w, [0.0, 0.0], m.gradient(w, X, y), cfg['momentum_main'], cfg['learning_rate'])
            if m.dist(w, w_star) < cfg['tolerance'] * d0:
                break
        self.assertEqual(k, self.r['steps']['gd'])

    def test_saved_results_are_this_run(self):
        saved = json.loads((RES / 'python.json').read_text(encoding='utf-8'))
        fresh = json.loads(json.dumps(self.r, ensure_ascii=False))
        self.assertEqual(saved, fresh)


class CppMatchesPython(unittest.TestCase):
    def test_cpp_output(self):
        path = RES / 'cpp.json'
        if not path.exists():
            self.skipTest('results/cpp.json 없음: run_all.sh 가 C++ 를 먼저 실행해야 한다')
        c = json.loads(path.read_text(encoding='utf-8'))
        p = json.loads((RES / 'python.json').read_text(encoding='utf-8'))
        for a, b in zip(c['w_star'], p['valley']['w_star']):
            self.assertAlmostEqual(a, b, places=12)
        self.assertEqual([x['steps'] for x in c['sweep']], [x['steps'] for x in p['sweep']])
        keep = p['config']['trajectory_steps']
        for x in c['sweep']:
            path_py = p['trajectories'][repr(float(x['beta']))]  # C++ 는 0.0 을 0 으로 쓴다
            for got, want in ((x['at100'], path_py[100]), (x['at_keep'], path_py[keep])):
                self.assertAlmostEqual(got[0], want[0], places=12)
                self.assertAlmostEqual(got[1], want[1], places=12)
        for a, b in zip(c['toy_same'], p['toy']['same_direction']):
            self.assertAlmostEqual(a, b, places=12)
        for a, b in zip(c['toy_alternating'], p['toy']['alternating']):
            self.assertAlmostEqual(a, b, places=12)


if __name__ == '__main__':
    unittest.main()
